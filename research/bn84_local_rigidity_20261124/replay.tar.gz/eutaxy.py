exec(open('verify.py').read().split('for lab in sorted(set(labs)):')[0])
from fractions import Fraction as F
Snum=np.zeros((80,80),'i8')
for lab in sorted(set(labs)):
  goal=((lab>>np.arange(4)&1)@C)%2
  f=f'c{lab}.out' if lab in (1,2,4,8) else f'r{lab}.out'
  W=np.array([list(map(int,s.split()[1:]))for s in open(f)if s.startswith('contact')],'i8')
  assert W.shape==(80,80) and np.all(np.einsum('bi,bi->b',W,W)==49152)
  assert np.all((8*goal@B-W)@S%(16*den)==0)
  assert rk(W)==80
  Snum+=W.T@W
denMix=6*8192*80
assert np.trace(Snum)==12*denMix

R=np.array(open('input.txt').read().splitlines()[6].split(),'i8').reshape(240,9)
E8=R[:,:8]; lc=R[:,8]
assert len({tuple(u)for u in E8})==240
assert (np.einsum('ij,ij->i',E8,E8)==8).all()
J=np.array((4*Matrix(E.tolist()).inv()).tolist(),'i8')
assert np.all(E8@J%4==0)
I8=np.eye(8,dtype='i8')
assert np.array_equal(E8.T@E8,240*I8)
M4=np.einsum('ai,aj,ak,al->ijkl',E8,E8,E8,E8)
ref=192*(np.einsum('ij,kl->ijkl',I8,I8)+np.einsum('ik,jl->ijkl',I8,I8)+np.einsum('il,jk->ijkl',I8,I8))
assert np.array_equal(M4,ref)
for label in range(1,16):
  A=E8[lc==label]
  P=np.array([x for x in A if x[np.flatnonzero(x)[0]]>0])
  assert len(P)==8 and set(map(tuple,A))==set(map(tuple,np.vstack([P,-P])))
  assert np.array_equal(P@P.T,8*I8)
  # L generated in raw coordinates by B/4. Validate all possible pair contacts:
  # each doubled root in each block has the same order<=2 syndrome per carry.
  ss=(4*np.einsum('aj,bjk->abk',P,S.reshape(10,8,80)))%den
  assert np.all(ss==ss[0,0]) and np.all(2*ss%den==0)
  if label==9: Q=P

Z=E8@Q.T
P=np.kron(np.eye(10,dtype='i8'),Q)
T0=8*denMix*np.eye(80,dtype='i8')-P@Snum@P.T
# In the common carry-9 orthonormal coordinates, remove each cross entry
# by the appropriate signed matched-carry 2-block contact. Its two
# diagonal contributions are the absolute cross entry.
left=T0.copy()
for i,j in itertools.combinations(range(10),2):
  I=np.arange(i*8,i*8+8); J=np.arange(j*8,j*8+8)
  D=np.abs(T0[np.ix_(I,J)])
  left[I,I]-=D.sum(axis=1); left[J,J]-=D.sum(axis=0)
  left[np.ix_(I,J)]=left[np.ix_(J,I)]=0
weights=[]
traces=[]
for i in range(10):
  A=left[i*8:i*8+8,i*8:i*8+8]
  tr=int(np.trace(A)); traces.append(tr)
  w=10*np.einsum('ai,ai->a',Z@A,Z)-64*tr
  assert np.all(w>0)
  # Frame mass checked independently; scales w/(64·8·denMix·30)
  # sum to trace(A)/(8·denMix·15) per frame when taking one root sign.
  assert all(int(w[lc==label].sum())==256*tr for label in range(1,16))
  # Direct exact local-matrix replay including both signs.
  assert np.array_equal(np.einsum('a,ai,aj->ij',w,Z,Z),2*30*64*64*A)
  weights.extend(map(int,w))
assert sum(traces)>2*max(traces)
print('min positive local weight numerator / 64 / common denom',F(min(weights),64*8*denMix))
print('minimum block trace',F(min(traces),8*denMix),'maximum block trace',F(max(traces),8*denMix))
print('strict balancing slack',F(sum(traces)-2*max(traces),8*denMix))
print('PASS exact positive eutaxy certificate; all selected contact forms can have positive weight')
