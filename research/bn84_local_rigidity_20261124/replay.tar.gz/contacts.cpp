#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <tuple>
#include <vector>
using namespace std;
using U=array<int,8>;
int J[8][8],look[256],Z[16][8],S[256][8],M[5][5],P[32],I[32][80],B[80][80],top[10],R[240][9];
int A[10][8], f[10][256], cr[10][256], ord[5][256]; U y[10][256],res[10][256];
mt19937 gen(731875);
const int scale=8,D=8*scale,den=2*D*D;
int phase[32][80],vert[32][5];
int fdiv(int a,int b){return a/b-(a%b<0);}
pair<U,int> nearest(const U &a){U best;int bc=1<<30;
 for(int o:{0,D}){U z,r;int sum=0,c=0;for(int i=0;i<8;i++){z[i]=fdiv(a[i]-o+D,2*D);r[i]=a[i]-o-2*D*z[i];sum+=z[i];c+=r[i]*r[i];}
 if(sum&1){int k=0;for(int i=1;i<8;i++)if(abs(r[i])>abs(r[k]))k=i;c+=4*D*D-4*D*abs(r[k]);z[k]+=(r[k]>=0?1:-1);}
 if(c<bc){bc=c;for(int i=0;i<8;i++)best[i]=2*z[i]+o/D;}}
 return {best,bc};}
int carry(const U&u){int p=0;for(int j=0;j<8;j++){int x=0;for(int k=0;k<8;k++)x+=u[k]*J[k][j];assert(x%4==0);p|=((x/4)&1)<<j;}return look[p];}
void calc(const int*x,int z){for(int i=0;i<10;i++)for(int j=0;j<256;j++){
 U v;for(int k=0;k<8;k++)v[k]=x[8*i+k]-2*scale*Z[z][k]-4*scale*S[j][k];
 auto [p,c]=nearest(v);f[i][j]=c;y[i][j]=p;cr[i][j]=carry(p);
 for(int k=0;k<8;k++)res[i][j][k]=v[k]-D*p[k];
 }
 for(int i=0;i<5;i++){for(int j=0;j<256;j++)ord[i][j]=j; sort(ord[i],ord[i]+256,[i](int a,int b){return f[i][a]<f[i][b];});}}
struct W {int best=1<<30,z=-1,t=-1; array<int,10> state; array<U,10> q;};
void commit(W& w,int z,int t,const array<int,10>& cur, int base, int target){
 int curc=0;for(int j=0;j<10;j++)curc^=cr[j][cur[j]];
 if(base>=w.best)return;
 if(curc==target){w.best=base;w.z=z;w.t=t;w.state=cur;for(int j=0;j<10;j++)w.q[j]=y[j][cur[j]];return;}
 const int miss=curc^target;
 // Repair carry by one E8-root move, same explicit parent membership.
 int best=1<<30,bt=-1,rt=-1;
 for(int j=0;j<10;j++)for(int k=0;k<240;k++)if(R[k][8]==miss){
  int a=0;for(int b=0;b<8;b++)a+=res[j][cur[j]][b]*R[k][b];
  int dif=8*D*D-2*D*a;if(dif<best){best=dif;bt=j;rt=k;}}
 assert(bt>=0 && best>=0);
 if(base+best<w.best){w.best=base+best;w.z=z;w.t=t;w.state=cur;for(int j=0;j<10;j++)w.q[j]=y[j][cur[j]];for(int j=0;j<8;j++)w.q[bt][j]+=R[rt][j];
  int v=0;for(auto&a:w.q)v^=carry(a);assert(v==target);}
}

typedef array<int,85> V;
int vertdist(const V &x,int t,V &p){
 int a[5],r[5],c=0,sum=0;for(int i=0;i<5;i++){
  a[i]=x[80+i]-D*vert[t][i];r[i]=fdiv(a[i]+D,2*D);a[i]-=2*D*r[i];sum+=r[i];c+=a[i]*a[i];}
 if(sum&1){int k=0;for(int i=1;i<5;i++)if(abs(a[i])>abs(a[k]))k=i;c+=4*D*D-4*D*abs(a[k]);r[k]+=(a[k]>=0?1:-1);}
 for(int i=0;i<5;i++)p[80+i]=D*(vert[t][i]+2*r[i]);return 2*c;
}
pair<int,V> run(const V &a,int trials,int anytime){
 vector<tuple<int,int,V>> vs;for(int i=0;i<32;i++){V v={};int c=vertdist(a,i,v);vs.push_back({c,i,v});}
 sort(vs.begin(),vs.end());int best=1<<30;V win={};
 for(auto [v,tag,vv]:vs){
 if(v>=best)break;
 int x[80];for(int k=0;k<80;k++)x[k]=a[k]-phase[tag][k];
 W w;w.best=best-v;
 for(int z=0;z<16;z++){
  calc(x,z);
  for(int trial=0;trial<trials;trial++){
   array<int,10>s={};for(int j=0;j<5;j++){int b=trial==0?0:gen()%36;s[j]=ord[j][b];for(int h=0;h<5;h++)s[h+5]^=s[j]&M[j][h];}
   bool c=true;for(int round=0;round<5&&c;round++){c=false;for(int ii=0;ii<5;ii++){
    int i=(ii+trial)%5,bb=1<<30,j0=0;
    for(int j=0;j<256;j++){int q=f[i][j];for(int k=0;k<5;k++)q+=f[k+5][s[k+5]^((s[i]^j)&M[i][k])];if(q<bb){bb=q;j0=j;}}
    if(j0!=s[i]){for(int k=0;k<5;k++)s[k+5]^=(s[i]^j0)&M[i][k];s[i]=j0;c=true;}
   }}
   int val=0,tt=0;for(int j=0;j<10;j++)val+=f[j][s[j]];
   for(int h=0;h<4;h++){int a=0;for(int j=0;j<5;j++)a|=((s[j]>>(4+h))&1)<<j;tt|=P[a]<<h;}
   commit(w,z,tag,s,val,tt);
   if(w.z>=0 && w.best+v<=anytime)break;
  }
  if(w.z>=0 && w.best+v<=anytime)break;
 }
 if(w.z>=0){
  best=w.best+v;win=vv;
  for(int j=0;j<10;j++)for(int k=0;k<8;k++)win[8*j+k]=phase[tag][8*j+k]+2*scale*Z[w.z][k]+4*scale*S[w.state[j]][k]+D*w.q[j][k];
  int c=0;for(int i=0;i<85;i++)c+=(i>=80?2:1)*(win[i]-a[i])*(win[i]-a[i]);assert(c==best);
 }
 if(best<=anytime)break;
 }
 assert(best<1<<30);
 return {best,win};
}
int dist(const V&a,const V&b){int c=0;for(int i=0;i<85;i++)c+=(i>=80?2:1)*(a[i]-b[i])*(a[i]-b[i]);return c;}
constexpr int inf=100000000;
int distTab[10][256][16], lo[10][256],lb[6][5][256],part[5],ss[10];
U wit[10][256][16];vector<int>ord1[5];int mat[256],target[8],point[8],cut,nodes,lim=50000000,locali,curz;
bool stopFlag;
void ev(int i,int d,int sum,int off){
 if(i==8){
  if(sum&1)return;
  U p,q;int b=0;
  for(int j=0;j<8;j++){p[j]=2*point[j]+off;int k=0;
   for(int h=0;h<8;h++)k+=(2*point[h]+off)*J[h][j];
   assert(k%4==0);b|=((k/4)&1)<<j;
  }
  int s=mat[b];for(int j=0;j<8;j++)q[j]=(p[j]-S[s][j])/2;
  int c=carry(q);
  if(d<distTab[locali][s][c]){distTab[locali][s][c]=d;wit[locali][s][c]=q;}
  return;
 }
 int nearest0=fdiv(target[i]-off*D/2+D/2,D);
 for(int j=nearest0;;j++){
  int e=D*j+off*D/2-target[i],dd=d+e*e;if(dd>cut)break;
  point[i]=j;ev(i+1,dd,sum+j,off);
 }
 for(int j=nearest0-1;;j--){
  int e=D*j+off*D/2-target[i],dd=d+e*e;if(dd>cut)break;
  point[i]=j;ev(i+1,dd,sum+j,off);
 }
}
void tables_exact(const V &x,int tag,int z){
 for(int i=0;i<10;i++){
  locali=i;for(int j=0;j<8;j++)target[j]=x[8*i+j]-phase[tag][8*i+j]-2*scale*Z[z][j];
  for(int s=0;s<256;s++)fill(distTab[i][s],distTab[i][s]+16,inf);
  ev(0,0,0,0);ev(0,0,0,1);
  for(int s=0;s<256;s++)lo[i][s]=*min_element(distTab[i][s],distTab[i][s]+16);
 }
 for(int i=0;i<5;i++){
  ord1[i].clear();for(int s=0;s<256;s++)if(lo[i][s]<=cut)ord1[i].push_back(s);
  sort(ord1[i].begin(),ord1[i].end(),[&](int a,int b){return lo[i][a]<lo[i][b];});
 }
 for(int k=0;k<=5;k++)for(int j=0;j<5;j++){
  int unknown=0;for(int i=k;i<5;i++)unknown|=M[i][j];
  for(int s=0;s<256;s++){int b=inf;for(int t=0;t<256;t++)if((s&~unknown)==(t&~unknown))b=min(b,lo[j+5][t]);lb[k][j][s]=b;}
 }
}
V result; long long hits=0;
int nRank=0,bas[80][80];
int mp(int x){x%=101;return x<0?x+101:x;}
int inv101(int x){for(int j=1;j<101;j++)if(x*j%101==1)return j;abort();}
V aim;
void keep(){
 ++hits;
 int xx[80];for(int i=0;i<80;i++)xx[i]=mp(aim[i]-result[i]);
 for(int i=0;i<80;i++)if(xx[i]){
  if(!bas[i][i]){
   int z=inv101(xx[i]); for(int j=i;j<80;j++)bas[i][j]=mp(xx[j]*z);
   cout<<"contact";for(int j=0;j<80;j++)cout<<" "<<aim[j]-result[j];cout<<endl;
   ++nRank;return;
  }
  int z=xx[i];
  for(int j=i;j<80;j++)xx[j]=mp(xx[j]-z*bas[i][j]);
 }
}

bool dfs(int k,int spent,int tag,V &vvert,int z){
 if(++nodes>lim){stopFlag=true;return false;}
 int q=spent;for(int j=0;j<5;j++){if(ord1[j].empty())return false;if(j>=k)q+=lo[j][ord1[j][0]];q+=lb[k][j][part[j]];}
 if(q>cut)return false;
 if(k<5){
  for(int s:ord1[k]){
   if(q+lo[k][s]-lo[k][ord1[k][0]]>cut)break;
   ss[k]=s;for(int j=0;j<5;j++)part[j]^=s&M[k][j];
   auto b=dfs(k+1,spent+lo[k][s],tag,vvert,z);
   for(int j=0;j<5;j++)part[j]^=s&M[k][j];
   if(b)return true;if(stopFlag)return false;
  }
  return false;
 }
 int c0=0;for(int f=0;f<4;f++){int y=0;for(int j=0;j<5;j++)y|=((ss[j]>>(4+f))&1)<<j;c0|=P[y]<<f;}
 for(int j=0;j<5;j++)ss[j+5]=part[j];
 int dp[11][16],pick[11][16],prev[11][16];
 for(auto &a:dp)fill(a,a+16,inf);dp[0][0]=0;
 for(int i=0;i<10;i++)for(int a=0;a<16;a++)if(dp[i][a]<=cut)for(int b=0;b<16;b++)if(dp[i][a]+distTab[i][ss[i]][b]<dp[i+1][a^b]){
  dp[i+1][a^b]=dp[i][a]+distTab[i][ss[i]][b];pick[i+1][a^b]=b;prev[i+1][a^b]=a;
 }
 if(dp[10][c0]>cut)return false;
 result=vvert;
 for(int i=9;i>=0;i--){int b=pick[i+1][c0];c0=prev[i+1][c0];for(int j=0;j<8;j++)result[8*i+j]=phase[tag][8*i+j]+2*scale*Z[z][j]+4*scale*S[ss[i]][j]+D*wit[i][ss[i]][b][j];}
 keep(); return nRank==80;
}
tuple<int,V,bool> exact(const V &x,int goal){
 nodes=0;stopFlag=false;
 for(int s=0;s<256;s++){int b=0;for(int j=0;j<8;j++){int v=0;for(int h=0;h<8;h++)v+=S[s][h]*J[h][j];assert(v%4==0);b|=((v/4)&1)<<j;}mat[b]=s;}
 vector<tuple<int,int,V>> vs;for(int t=0;t<32;t++){V vt={};vs.push_back({vertdist(x,t,vt),t,vt});}sort(vs.begin(),vs.end());
 for(auto [v,tag,p]:vs){
  if(v>goal)continue;
  cut=goal-v;cerr<<"begin "<<tag<<" cutoff "<<cut<<" nodes "<<nodes<<endl;
  for(int z=0;z<16;z++){tables_exact(x,tag,z);fill(part,part+5,0);
   if(dfs(0,0,tag,p,z)){assert(dist(x,result)<=goal);return {dist(x,result),result,true};}
   if(stopFlag)return {0,{},false};
  }
 }
 return {goal+1,{},true};
}
int main(int argc,char**argv){
 ifstream f(argv[1]);for(auto&r:J)for(int&x:r)f>>x;for(int&x:look)f>>x;for(auto&r:Z)for(int&x:r)f>>x;for(auto&r:S)for(int&x:r)f>>x;
 for(auto&r:M)for(int&x:r)f>>x;for(int&x:P)f>>x;for(auto&r:R)for(int&x:r)f>>x;for(auto&r:B)for(int&x:r)f>>x;for(auto&r:I)for(int&x:r)f>>x;for(int&x:top)f>>x;
 for(int s=0;s<256;s++){int b=0;for(int j=0;j<8;j++){int v=0;for(int k=0;k<8;k++)v+=S[s][k]*J[k][j];assert(v%4==0);b|=((v/4)&1)<<j;}mat[b]=s;}
 ifstream g(argv[2]);for(int i=0;i<80;i++)g>>aim[i];assert(g);
 cut=argc>3?atoi(argv[3]):49152;lim=argc>4?atoi(argv[4]):120000000;
 V empty={};
 for(int z=0;z<16;z++){
   tables_exact(aim,0,z);fill(part,part+5,0);
   if(dfs(0,0,0,empty,z)||stopFlag)break;
   cerr<<"glue "<<z<<" rank "<<nRank<<" cumulative nodes "<<nodes<<" hits "<<hits<<endl;
 }
 cout<<"final rank "<<nRank<<" hits "<<hits<<" cap "<<stopFlag<<" nodes "<<nodes<<endl;
}
