import numpy as np,json,itertools
from sympy import Matrix, ilcm
R=json.load(open('gram_and_block_map.json'));D=json.load(open('c84.json'))
V=np.array(D['vertical_gram'],'i8')
M=np.array(R['twice_root_coordinate_basis'],'i8'); E=np.array(R['e8_twice_euclidean_basis'],'i8'); B=M@np.kron(np.eye(10,dtype='i8'),E)
G=np.array(R['gram'],'i8')
assert np.array_equal(B@B.T,32*G)
S=Matrix(B.tolist()).inv(method='DM');den=int(ilcm(*(x.q for x in S)));S=np.array((S*den).tolist(),'i8')
roots=[]; labs=[]
for u in itertools.product(range(-2,3),repeat=4):
    u=np.array(u,'i8')
    if u@V@u==2:
       roots.append(u);labs.append(int((u%2)@(1<<np.arange(4))))
assert len(roots)==24 and set(labs)==set(map(int,D['known']))
sym=[ [int(r[i]*r[j])for i in range(4)for j in range(i,4)]for r in roots]
assert Matrix(sym).rank()==10
assert Matrix(sum(np.outer(r,r)for r in roots).tolist())*Matrix(V.tolist())==12*Matrix.eye(4)
C=np.array([z['class']for z in D['generators']],'i8')
Y=np.array([list(map(int,x.split()[1:]))for x in open('c1.out')if x.startswith('contact')],'i8')
assert Y.shape==(80,80) and (np.einsum('bi,bi->b',Y,Y)==49152).all()
assert ( (8*C[0]@B-Y)@S%(16*den)==0 ).all()
def rk(A,p=101):
 A=A.copy()%p
 k=0
 for j in range(A.shape[1]):
   ii=np.flatnonzero(A[k:,j])
   if not len(ii):continue
   i=k+ii[0];A[[k,i]]=A[[i,k]]
   A[k]=A[k]*pow(int(A[k,j]),-1,p)%p
   A[k+1:]=(A[k+1:]-A[k+1:,j,None]*A[k])%p
   k+=1
   if k==len(A):break
 return k
assert rk(Y)==80
for lab in sorted(set(labs)):
  goal=((lab>>np.arange(4)&1)@C)%2
  W=np.array([list(map(int,s.split()[1:]))for s in open(f'c{lab}.out')if s.startswith('contact')],'i8')
  assert len(W) and np.all(np.einsum('bi,bi->b',W,W)==49152)
  assert np.all((8*goal@B-W)@S%(16*den)==0)
  if lab in (1,2,4,8): assert rk(W)==80
  print('root color',lab,'rank certified',rk(W))
for t in (5,9,12):
    y=np.array(list(map(int,open(f'depth{t}.log').readline().split()[1:])),'i8')
    goal=((t>>np.arange(4)&1)@C)%2
    assert int(y@y)<=49152 and ((8*goal@B-y)@S%(16*den)==0).all()
    print('non-root color',t,'verified norm²',int(y@y)/8192)
print('PASS: four simple root colors horizontal spans; all 15 depths <=6; D4 roots perfect and eutactic')

# Periodic rigidity lemma. Use one root from each ± pair.
import math
P=[x for x in roots if x[np.flatnonzero(x)[0]]>0]
pM=[Matrix([list(map(int,x))]) for x in P]
ns=set()
for i in itertools.combinations(range(len(P)),3):
    X=Matrix.vstack(*(pM[k] for k in i))
    if X.rank()!=3:continue
    v=X.nullspace()[0]; v=v*ilcm(*(x.q for x in v)); g=math.gcd(*map(int,v));v=tuple(int(x)//g for x in v)
    if next(x for x in v if x)<0:v=tuple(-x for x in v)
    ns.add(v)
assert len(ns)>0
det=lambda rows:round(np.linalg.det(np.array(rows,dtype=int)))
for v in sorted(ns):
    O=[r for r in P if sum(int(a)*b for a,b in zip(r,v))]
    # Short certificate of integral generation: some basis has determinant ±1.
    hit=False
    for ii in itertools.combinations(range(len(O)),4):
        rows=[list(map(int,O[j]))for j in ii]
        if abs(det(rows))!=1:continue
        assert abs(Matrix(rows).det())==1
        hit=True;break
    assert hit,(v,O)
print('PASS: Fourier rigidity for every finite-index supercell;',len(ns),'root hyperplanes')
