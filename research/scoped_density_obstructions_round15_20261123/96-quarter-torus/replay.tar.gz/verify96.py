"""Exact, finite arithmetic replay for the quarter-torus upper bounds."""
from itertools import combinations
from math import ceil, isqrt
from fractions import Fraction as Q
from sympy import Matrix, simplify, rf
from prior_scalar import ring, remaining

# The convention is t = exp(pi i tau) for the half-level block
# and t = exp(2 pi i tau) for the quarter-level block.
N = 14
c, add, mul, power = ring(N)
def scale(z, a):
    return tuple(a*x for x in z)

theta3 = tuple(1 if not k else (2 if isqrt(k)**2 == k else 0) for k in range(N))
theta4 = tuple(1 if not k else (2*(-1)**isqrt(k) if isqrt(k)**2 == k else 0) for k in range(N))
theta2_regular = tuple(2 if any(k==j*(j+1) for j in range(N)) else 0 for k in range(N))
X = (0,) + power(theta2_regular,4)[:-1]
Y = power(theta4,4)
W = add(X,Y)

def quarter(n,r,H,i):
    # The source-level form is P Y^i W^j times a homogeneous polynomial of degree d.
    # At M: (X,Y,W) -> (W,-Y,X); the t^alpha factor is omitted.
    k=n//24
    alpha=Q(4-r,4) if r else Q(0)
    j=ceil(H/2-alpha)
    d=n//4-(r>0)-i-j
    def seq(X,Y,W,P):
        return [mul(P,mul(power(Y,i),mul(power(W,j),mul(power(X,u),power(Y,d-u))))) for u in range(d+1)]
    P=mul(power(theta4,r),power(theta3,4-r)) if r else c(1)
    fam=seq(X,Y,W,P)
    a,p=Matrix([[f[t] for f in fam] for t in range(k+1)]).gauss_jordan_solve(Matrix([1]+[0]*k))
    PM=mul(power(theta4,r),power(theta2_regular,4-r)) if r else c(1)
    F=seq(W,scale(Y,-1),X,PM)
    return tuple(simplify(sum(b*f[jj] for b,f in zip(a,F))) for jj in range(N)),tuple(p),a[-1]

def half(n,H):
    # At S: (X,Y,W) -> (Y,X,W) after common signs cancel.
    # The t^.5 factor when h is half-integral is omitted.
    odd=int(H.denominator==2)
    e=int(H)
    d=n//4-odd-2*e
    k=n//24
    def seq(X,Y,W,P):
        Z=add(X,scale(Y,2))
        return [mul(P,mul(power(Y,e),mul(power(W,e),mul(power(Z,d-2*u),power(X,2*u))))) for u in range(d//2+1)]
    P=mul(power(theta3,2),power(theta4,2)) if odd else c(1)
    fam=seq(X,Y,W,P)
    a,p=Matrix([[f[2*t] for f in fam] for t in range(k+1)]).gauss_jordan_solve(Matrix([1]+[0]*k))
    PS=mul(power(theta3,2),power(theta2_regular,2)) if odd else c(1)
    F=seq(Y,X,W,PS)
    return tuple(simplify(sum(b*f[jj] for b,f in zip(a,F))) for jj in range(N)),tuple(p)

from prior_scalar import geom
import sympy as s
n=96
def rows(r,H,i):
 Q,P,L=quarter(n,r,H,i)
 M,V=half(n,H)
 dct={v:s.Symbol("half"+str(ii)) for ii,v in enumerate(V)}; M=tuple(h.subs(dct) for h in M); V=tuple(dct.values())
 alpha=s.Rational(4-r,4) if r else 0
 odd = int(H.denominator==2)
 pos = []
 for k,q in enumerate(Q[:N//2]):
  t=2*(alpha+k)-s.Rational(1,2)*odd
  assert t.denominator==1
  h=M[int(t)]
  pos.extend([h-q,h+q])
 for k,h in enumerate(M[:N]):
  d=k+s.Rational(1,2)*odd
  pos.append(h)
  if d<H or (H<5 and H<d<10-H):
    pos.append(-h)
  if d==H and H==5:
    pos.append(192-h)
  if d==H and H<5:
    pos.append(2-h);pos.append(h-2)
 pos.append(L)
 return pos, P+V
from pathlib import Path
data = {}
for line in Path(__file__).with_name('certificates.txt').read_text().splitlines():
    r,H,d=line.split(maxsplit=2)
    key=(int(r),Q(H))
    data[key]=None if d=='inconsistent before LP' else {
        int(i):Q(c) for t in d.split(',') for i,c in [t.split(':')]
    }
assert len(data)==22
seen=set()
for r in range(4):
    for h2 in range(5,17):
        H=Q(h2,2)
        if (H-Q(r,2)).denominator>1 or geom(96,r,H)<=8:
            continue
        key=(r,H)
        seen.add(key)
        cert=data[key]
        i=16+(r==0)
        if cert is None:
            try:
                rows(r,H,i)
            except ValueError as ex:
                assert 'no solution' in str(ex)
            else:
                raise AssertionError("claimed inconsistent modular system solved")
        else:
            pos,var=rows(r,H,i)
            assert all(v>=0 for v in cert.values())
            assert all(0<=j<len(pos) for j in cert)
            assert sum(w*pos[j] for j,w in cert.items()).expand()==-1, key
        print('PASS rank96',key)
assert set(data)==seen
print('PASS conditional on extremal even unimodular rank96, all quarter depths <=8')
