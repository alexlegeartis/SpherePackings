#!/usr/bin/env python3
from pathlib import Path
from fractions import Fraction as F
from math import prod
from tempfile import TemporaryDirectory
import json, subprocess, sys, os, hashlib
os.chdir(Path(__file__).resolve().parent)
def q(x):return (x&(x>>4)).bit_count()%2
def b(x,y):return q(x^y)^q(x)^q(y)
def dot(x,y):return sum(a*b for a,b in zip(x,y))
R=[tuple(map(int,l.split())) for l in Path('roots.in').read_text().splitlines()]
A=[x for x in range(256) if q(x)]
assert len(R)==256 and len(A)==120 and all(len(r)==8 for r in R)
for x,v in enumerate(R):
 if x not in A:
  assert not any(v)
  continue
 assert dot(v,v)==8 and len({k%2 for k in v})==1 and sum(v)%4==0
 for y in A:
  z=dot(v,R[y])
  assert z%4==0 and (z//4)%2==b(x,y)
span={0}
for x in A:
 span|={x^u for u in span}
assert len(span)==256
base=[1,16,2,32,4,64,8,128]
order=[135,64,35,16,9,4,2,1]
extra=[21,25,29,17]
assert all(x in A for x in extra)
def tr(x,r):return x^r if b(x,r) else x
def comp(x):
 for r in extra:x=tr(x,r)
 return x
assert all(comp(j)==j for j in base[:5])
for i, x in enumerate(base):
 ts=[r for r in A if all(not b(r,t) for t in base[:i])]
 orbit={x}; stack=[x]
 for u in stack:
  w=[tr(u,r) for r in ts]
  if i==5:w.append(comp(u))
  for v in w:
   if v not in orbit:orbit.add(v);stack.append(v)
 assert len(orbit)==order[i]
size=prod(order)
assert size==prod(((1<<(2*m-1))+(1<<(m-1))-1)*(1<<(2*m-2)) for m in range(1,5))==348364800
print('E8 root dictionary and surjectivity of liftable orthogonal group PASS',flush=True)
walsh_sha={name:digest for digest,name in (l.split() for l in Path("WALSH_SHA256SUMS").read_text().splitlines())}
DUAL=json.loads(Path('duals.json').read_text())
assert sorted(DUAL)==list('45678')
target=F(3,2)**24
trivial=F(2**48,2401)*F(3,8)**24
centers=[trivial]
with TemporaryDirectory() as tmp:
 exe=tmp+'/six'
 subprocess.run(['g++','-O3','-std=c++20','six.cpp','-o',exe],check=True)
 for g in range(4,9):
  with Path('roots.in').open() as f:
   out=subprocess.run([exe,str(g)],stdin=f,stdout=subprocess.PIPE,check=True).stdout
  data=out
  assert hashlib.sha256(data).hexdigest()==walsh_sha[f'gen{g}.tsv']
  N,*M=[list(map(int,l.split())) for l in data.splitlines()]
  assert len(M)==449 and len(N)==[447,441,433,396,347][g-4]
  v=DUAL[str(g)]; k={int(i):int(y) for i,y in v['numerators'].items()}
  assert min(k.values())>0 and all(0<=i<len(M) for i in k)
  z=F(v['divisor']); assert z>0
  assert all(F(sum(-c*M[i][j] for i,c in k.items()),a)>=z for j,a in enumerate(N))
  cap=1+F(sum(k.values()),z); assert cap==F(v['cap'])
  K=cap.numerator//cap.denominator
  center=F(256*K,2401)*F(g,8)**24
  centers.append(center)
  assert center<target
  if g==8:assert K==149399
  print(g,K,K*256,center,float(center),flush=True)
assert trivial<target
overall=max(centers)
print('scoped center-density cap',overall, float(overall), 'P48 comparator', float(target),flush=True)
assert overall==F(38246144,2401)
assert overall**2*F(20047,20000)**47<target**2
print('includes all simultaneous linear deformations with Gram condition number <=20047/20000',flush=True)
r=F(11,50)
assert 2**16*F(3,4)**24<4096
rank_one=F(4096)*((1+r)**6/(1+6*r))**4
assert rank_one<target
print('smallest diagonal weight <=11/50 of second smallest: cap',rank_one,float(rank_one),flush=True)
assert 3**24*2**7 < 4**24
r=F(29,100)
rank_one_add=F(2048)*((1+r)**6/(1+6*r))**4
assert rank_one_add<target
print('additive, smallest diagonal weight <=29/100 of second smallest: cap',rank_one_add,float(rank_one_add),flush=True)
