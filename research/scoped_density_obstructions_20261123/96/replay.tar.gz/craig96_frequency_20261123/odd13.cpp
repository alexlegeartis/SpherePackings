#include<bits/stdc++.h>
using namespace std;
constexpr int p=97,r=6,m=13;
int T[p][p],V[49][49], A[r]={1},w[49],n;
bool tryit(){
 int cnt[49]={};
 for(int x=1;x<=48;x++){
  int y=x;for(int j=0;j<r;j++) y=T[y][V[x][A[j]]];
  w[x]=y;int q=min(y,p-y);
  if(q&&++cnt[q]==m){
   for(int x=1;x<=48;x++){int y=x;for(int j=0;j<r;j++) y=T[y][V[x][A[j]]];w[x]=y;}
   set<int>X={0};for(int j:A){X.insert(j);X.insert(p-j);}
   for(int j:X)cout<<j<<' ';cout<<endl;
   for(int x=1;x<=48;x++)if(w[x]==q)cout<<x<<' ';else if(w[x]==p-q)cout<<p-x<<' ';cout<<endl;
   for(int x=1;x<=48;x++)if(w[x]==p-q)cout<<x<<' ';else if(w[x]==q)cout<<p-x<<' ';cout<<endl;
   cerr<<n<<endl;return true;
  }
 }
 return false;
}
bool DFS(int i,int u){
 if(i==r){++n;return tryit();}
 for(int j=u;j<=48-(r-1-i);j++){A[i]=j;if(DFS(i+1,j+1))return true;}
 return false;
}
int main(){
 for(int i=0;i<p;i++)for(int j=0;j<p;j++)T[i][j]=i*j%p;
 for(int x=1;x<=48;x++)for(int j=1;j<=48;j++)V[x][j]=(x*x-j*j+97*100)%97;
 if(!DFS(1,2))cerr<<"none "<<n<<endl;
}
