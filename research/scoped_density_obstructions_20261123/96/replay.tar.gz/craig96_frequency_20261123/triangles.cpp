#include <algorithm>
#include <array>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace std;
using U=__uint128_t;
struct V {U p=0,n=0;vector<int> a,b;};
V mk(vector<int>a, vector<int>b){V v;v.a=a;v.b=b;for(int x:a)v.p|=U(1)<<x;for(int x:b)v.n|=U(1)<<x;return v;}
V affine(const V&v,int a,int b){vector<int>A,B;for(int i:v.a)A.push_back((a*i+b)%97);for(int i:v.b)B.push_back((a*i+b)%97);return mk(A,B);}
int pc(U x){return __builtin_popcountll(x)+__builtin_popcountll(x>>64);}
int dot(const V&x,const V&y){return pc(x.p&y.p)+pc(x.n&y.n)-pc(x.p&y.n)-pc(x.n&y.p);}
uint64_t row(const V&x,const V&y){U a=x.p|x.n,b=y.p|y.n;uint64_t r=0;for(int i=0;i<97;i++)if((a>>i)&1)for(int j=0;j<97;j++)if((b>>j)&1){int d=abs(i-j);d=min(d,97-d);r^=1ULL<<d;}return r;}
void out(const V&v){for(int i:v.a)cout<<i<<' ';cout<<"/ ";for(int i:v.b)cout<<i<<' ';cout<<" | ";}
int main(){int m,k;while(cin>>m>>k){vector<V>s;for(int i=0;i<k;i++){vector<int>a(m),b(m);for(auto&x:a)cin>>x;for(auto&x:b)cin>>x;s.push_back(mk(a,b));}uint64_t B[50]={};int rank=0,ts=0;bool impossible=false;
auto insert=[&](uint64_t r){for(int j=0;j<49;j++)if((r>>j)&1){if(B[j])r^=B[j];else{B[j]=r;rank++;return true;}}if(r){impossible=true;return true;}return false;};
for(const auto&x:s){for(const auto&t:s){for(int a=1;a<97&&!impossible;a++)for(int b=0;b<97&&!impossible;b++){auto y=affine(t,a,b);int d=dot(x,y);if(abs(d)!=m)continue;if(d<0)y=mk(y.b,y.a);ts++;uint64_t r=row(x,y);for(int l=1;l<49&&!impossible;l++){uint64_t q=r&1;for(int k=1;k<49;k++)if((r>>k)&1){int i=l*k%97;i=min(i,97-i);q^=1ULL<<i;}if(insert(q|(1ULL<<49))){cout<<m<<' '<<l<<' '<<q<<' ';out(x);out(y);cout<<'\n';}}}if(impossible)break;}if(impossible)break;}cerr<<"m "<<m<<" rank "<<rank<<" triangles "<<ts<<" impossible "<<impossible<<'\n';}}
