"""Heuristic search of Craig one-parameter Legendre-frequency metrics."""
import numpy as np, json, math, sys
from pathlib import Path
p=97;n=96
ROOT=Path('/workspace/scratch/941a2e823e69/research/')
sq={i*i%p for i in range(1,p)}
Q0=np.array([0]+[1 if i in sq else -1 for i in range(1,p)],dtype='i8')
K=Q0[(np.arange(p)[:,None]-np.arange(p))%p]
assert np.array_equal(K@K,p*np.eye(p,dtype='i8')-np.ones((p,p),dtype='i8'))
e=5604+569*math.sqrt(p)
assert 5604**2-p*569**2==-1
s0=math.log(e)
J=K/math.sqrt(p);P=np.eye(p)
def basis(m):
    W=np.array([[pow(x,k,p)for x in range(1,p)]for k in range(1,m)],dtype='i8')
    for i in range(m-1):
        a=next(j for j in range(i,m-1)if W[j,i])
        W[[i,a]]=W[[a,i]];W[i]=W[i]*pow(int(W[i,i]),-1,p)%p
        v=W[:,i].copy();v[i]=0;W=(W-v[:,None]*W[i,None])%p
    assert np.array_equal(W[:,:m-1],np.eye(m-1,dtype='i8'))
    R=np.eye(n,dtype='i8');R[:m-1]*=p;R[m-1:,:m-1]=(((-W[:,m-1:].T+48)%p)-48)
    return np.column_stack((-R.sum(1),R))
def lll(raw,kappa=.99,cap=100000):
    raw=raw.copy();Q,R=np.linalg.qr((raw@Y).T,mode='reduced')
    B=np.diag(R)**2;M=(R/np.diag(R)[:,None]).T.copy()
    M-=np.eye(len(M))
    k=1;n=len(M);iters=0
    while k<n:
        iters+=1
        if iters>cap:break
        for j in range(k-1,-1,-1):
            z=int(np.rint(M[k,j]))
            if not z:continue
            M[k,:j]-=z*M[j,:j];M[k,j]-=z
            raw[k]-=z*raw[j]
        z=M[k,k-1]
        if B[k]<(kappa-z*z)*B[k-1]:
            A=float(B[k-1]);C=float(B[k]);d=C+z*z*A;f=z*A/d
            B[k-1]=d;B[k]=A*C/d
            raw[[k-1,k]]=raw[[k,k-1]]
            M[[k-1,k],:k-1]=M[[k,k-1],:k-1]
            M[k,k-1]=f
            h=M[k+1:,k-1]-z*M[k+1:,k]
            M[k+1:,k-1]=M[k+1:,k]+f*h
            M[k+1:,k]=h
            k=max(1,k-1)
        else:k+=1
    return raw,iters
def find(B,r,m,reps):
    global Y
    Y=(math.exp(r/2)+math.exp(-r/2))*P/2+(math.exp(r/2)-math.exp(-r/2))*J/2
    rng=np.random.default_rng(int(1e6*r+1447*m))
    res=[]
    for i in range(reps):
        V,k=lll(B if not i else B[rng.permutation(len(B))])
        # Pairwise difference/addition of first 32 reduced rows, not only row norms.
        W=np.vstack((V, (V[:32,None,:]+V[None,:32,:]).reshape(-1,p), (V[:32,None,:]-V[None,:32,:]).reshape(-1,p)))
        assert abs(W).max()<10000000
        q=np.einsum('ij,ij->i',W,W);g=np.einsum('ij,ij->i',W@K,W)
        norm=q*math.cosh(r)+g/math.sqrt(p)*math.sinh(r)
        norm[q==0]=1e5
        j=int(norm.argmin())
        res.append((norm[j],int(q[j]),int(g[j]),W[j].tolist(),k))
    return min(res)
def shell():
    S={m:[]for m in range(6,17)}
    for m in S:
        for z in (h for h in range(m,49)if 96%h==0):
            Cs={}
            for i in range(1,97):Cs.setdefault(pow(i,z,p),[]).append(i)
            V=list(Cs.values())
            for a in V:
                for b in V:
                    if a==b:continue
                    x=np.zeros(p,dtype='i8');x[a]=1;x[b]=-1;S[m].append(x)
    rec=json.load(open(ROOT/'craig96_affine_global_20261123/witness.json'))['vectors']
    for h,(a,b) in rec.items():
        for m in S:
            if int(h)<m:continue
            x=np.zeros(p,dtype='i8');x[a]=1;x[b]=-1;S[m].append(x)
    raw=list(map(int,(ROOT/'craig96_moment_glue_20261123/perfection.in').read_text().split()));i=0
    while i<len(raw):
        m,k=raw[i:i+2];i+=2
        for j in range(k):
            a=raw[i:i+m];i+=m;b=raw[i:i+m];i+=m
            for h in S:
                if h>m:continue
                x=np.zeros(p,dtype='i8');x[a]=1;x[b]=-1;S[h].append(x)
    return S
def mem(m,w):
    assert sum(w)==0 and all(sum(pow(i,k,p)*v for i,v in enumerate(w))%p==0 for k in range(1,m))
def target(m):return 4*2**((53.23938839915442+(m-.5)*math.log2(97))/48)
if __name__=='__main__':
    m=int(sys.argv[1]);B=basis(m);mem(m,B[0].tolist());S=shell()[m]
    # Produce a lattice basis by reducing once in ordinary metric,
    # then re-use it in all hinted distant metrics.
    Y=np.eye(p);B,_=lll(B,.999)
    print('M',m,'HIGHEST r',s0,'threshold',target(m),flush=True)
    with open(f'witness{m}.jsonl','w')as out:
        for r in np.linspace(0,s0,int(sys.argv[2])):
            V,q,g,x,k=find(B,float(r),m,1)
            mem(m,x)
            v=np.array(x,dtype='i8');assert int(v@v)==q and int(v@K@v)==g
            out.write(json.dumps([float(r),V,q,g,x,k])+'\n');out.flush()
            print('R',round(float(r),5),round(float(V),8),'Q',q,'G',g,'iters',k,'OVER',bool(V>target(m)),flush=True)
