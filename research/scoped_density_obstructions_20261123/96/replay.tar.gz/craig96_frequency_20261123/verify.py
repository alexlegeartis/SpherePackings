from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
p=97
sq={i*i%p for i in range(1,p)}
chi=lambda x: 0 if x%p==0 else (1 if x%p in sq else -1)
D=F(10950866250772257481,50625000000000000)
live=F(4**96,47**14)/D
def packing(q,m,k=1): return (F(q,4)**96)/97**(2*m-1)/k**2
def exact(A,B,m):
 d={x:0 for x in A+B}
 for a in A:d[a]+=1
 for b in B:d[b]-=1
 assert all(sum(c*pow(x,k,p) for x,c in d.items())%p==0 for k in range(m))
 q=sum(c*c for c in d.values()); K=sum(a*b*chi(i-j) for i,a in d.items() for j,b in d.items())
 return q,K
def reports(m):
 ls=Path(__file__).with_name(f'split{m}.log').read_text().splitlines()
 for i,s in enumerate(ls):
  if s.startswith('FIBRES'):
   yield tuple(map(int,ls[i+1].split())),tuple(map(int,ls[i+2].split()))
def metric_upper(q,K,u):
 # K <= 0. sqrt(97) < 197/20.
 return (q*(u+1/u)+F(20*K,197)*(u-1/u))/2
for m in range(8,13):
 q,K,A,B=min((q,-abs(K),A,B) for A,B in reports(m) for q,K in [exact(A,B,m)])
 ref=2*m
 assert q==ref and packing(q,m)<live
 if exact(A,B,m)[1]>0:
  a=next(x for x in range(2,p) if x not in sq)
  A=tuple(a*x%p for x in A); B=tuple(a*x%p for x in B)
 assert exact(A,B,m)==(q,K)
 u=max(F(i,100) for i in range(100,401) if packing(metric_upper(q,K,F(i,100)),m)<live)
 assert packing(metric_upper(q,K,u),m)<live
 print(m,'q',q,'K',K,'proved_u',str(u),'upper_endpoint',str(metric_upper(q,K,u)),'A',A,'B',B)
assert packing(22,11,2)<live
assert packing(24,11,3)<live
assert packing(24,12)<live
assert packing(16,8)<live
A=[4,9,24,43,50,60,63,64,71]
B=[1,22,26,34,35,37,61,81,91]
C=[2,23,25,29,45,46,58,70,90]
for X,Y in combinations([A,B,C],2): assert exact(X,Y,9)[0]==18
# Quotient G=F3, sum of 3 clique vectors reduces to polynomial below.
v=[(int(i in A)+int(i in B)+int(i in C))%3 for i in range(p)]
def clean(a):
 while a and not a[-1]:a.pop()
 return a
def rem(a,b):
 a=a.copy()
 while a and len(a)>=len(b):
  c=a[-1]*pow(b[-1],-1,3)%3
  for j,x in enumerate(b):a[len(a)-len(b)+j]=(a[len(a)-len(b)+j]-c*x)%3
  clean(a)
 return a
x=[2]+[0]*96+[1];y=clean(v)
while y:x,y=y,rem(x,y)
print('F3 clique sum polynomial gcd X^97-1 =',x)
assert x in ([2,1],[1,2])
assert packing(18,9,3)<live
def powers(A,B,j):return (sum(pow(x,j,p) for x in A)-sum(pow(x,j,p) for x in B))%p
A,B=next(reports(11)); assert exact(A,B,11)[0]==22
assert powers(A,B,11)!=0 and len({pow(a,11,p) for a in range(1,p)})==96
# Rank-2 quotient: after nonzero leading coefficient, any next coefficient
# results from translating, since M_(m+1) shifts by (m+1)t M_m.
assert 12%p and 13%p
image={powers(A,B,12)*pow(a,12,p)%p for A,B in reports(12) for a in range(1,p)}
assert image==set(range(1,p))
for A,B in reports(12):assert exact(A,B,12)[0]==24
assert packing(28,13)<live
print('L11/L13 all 9408 nonzero colors blocked by q22 or q24; L13 at q28 loses')
ls=Path(__file__).with_name('equiv13.log').read_text().splitlines()
i=next(i for i,line in enumerate(ls) if line.startswith('BEST 15 6 2'))
A,B=[tuple(map(int,ls[j].split())) for j in (i+1,i+2)]
assert exact(A,B,15)[0]==30
assert packing(30,14)<live
print('L14 and L15 contain a literal q30 upper witness; Euclidean density loses')
