#include<bits/stdc++.h>
using namespace std;
int P=97,mul[97][97],pw[97][97];
int main(){
 for(int x=0;x<P;x++)for(int y=0;y<P;y++)mul[x][y]=x*y%P;
 for(int x=0;x<P;x++){pw[x][0]=1;for(int a=1;a<P;a++)pw[x][a]=mul[pw[x][a-1]][x];}
 for(int m:{13,14,15})for(int d:{2,3,4,6,8,12}){
  int k=m/d,r=m%d;if(k==0||k>3)continue;
  int z=1;while(z<97&&(pw[z][d]!=1||[&]{for(int j=1;j<d;j++)if(pw[z][j]==1)return true;return false;}()))z++;
  assert(z<97);
  vector<int> R;int chk[97]={};int cls[97]{};
  for(int x=1;x<P;x++)if(!chk[x]){R.push_back(x);for(int j=0;j<d;j++)chk[mul[x][pw[z][j]]]=1;}
  assert((int)R.size()*d==96);
  for(int x=0;x<P;x++){cls[x]=x;for(int j=0;j<d;j++)cls[x]=min(cls[x],mul[x][pw[z][(j*r)%96]]);}
  int it=1;for(int j=0;j<k;j++)it*=P;
  int best=0,good=0;
  for(int q=0;q<it;q++){
   int co[3],a=q;for(int j=0;j<k;j++){co[j]=a%97;a/=97;}
   int hit[97]{};
   for(int x:R){int u=pw[x][d],v=1;
    for(int j=k-1;j>=0;j--)v=(mul[v][u]+co[j])%P;
    int f=mul[pw[x][r]][v];if(f)hit[cls[f]]+=gcd(r,d);else hit[0]+=d;
   }
   hit[0]+=(r>0);if(!r)hit[cls[co[0]]]++;
   int w=(hit[0]==m);
   for(int i=1;i<P;i++){assert(hit[i]<=m);if(hit[i]==m)w+=d/gcd(d,r);}
   if(w>best){
    best=w;cout<<"BEST "<<m<<' '<<d<<' '<<best<<" coefficients ";for(int j=0;j<k;j++)cout<<co[j]<<' ';cout<<endl;
    vector<int>T[97];
    for(int x=0;x<P;x++){int u=pw[x][d],v=1;for(int j=k-1;j>=0;j--)v=(mul[v][u]+co[j])%P;
     int f=mul[pw[x][r]][v];T[f].push_back(x);}
    int r0=0;for(int y=0;y<P;y++)if((int)T[y].size()==m){r0++;for(int v:T[y])cout<<v<<' ';cout<<endl;}
    assert(r0==w);
   }
   good+=w>=3;
  }
  cerr<<"DONE "<<m<<" "<<d<<" polys "<<it<<" best "<<best<<" at least3 "<<good<<endl;
 }
}
