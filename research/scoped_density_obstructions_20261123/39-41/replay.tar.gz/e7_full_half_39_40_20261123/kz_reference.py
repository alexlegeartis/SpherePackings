"""Exact branchwise Korkine-Zolotarev (KZ) covering/enumeration proof."""
from fractions import Fraction as F
from itertools import combinations
from math import lcm
from functools import lru_cache
U=F(53,100); a0,a1=F(75,100),F(118,100)
R=lambda a: 2-a if a<=1 else 2-1/a
B=lambda a: F(3,2)-(a-F(1,2))**2/(4*a)
G={2:F(4,3),3:F(2),4:F(4),5:F(8),6:F(64,3)}
# 41D prior chain complement of sqrt(3)*E7, determinant 2*3^7, min6:
target2=F(3**34,2**42)
assert target2>F(1024)/U**2
assert F(3)*F(3,4)**6>U**2 # Hermite6 when a≥3/2.
assert F(3,4)>U**2 # Constant color makes an integer pattern kernel of index≤2.
assert all(4*a*(R(a)/2)**5>U**2 for a in [a0,a1])
# q2>=.9*q1 is impossible in rank-one kernel, by the Hermite5 suffix.
assert F(2)**6*F(9,10)**5/G[5]>(4*U)**2

S=10**10
@lru_cache(None)
def ln_bounds(q):
    k=0
    while q<1:q*=2;k-=1
    while q>=2:q/=2;k+=1
    def atanh(w):
        z=(w-1)/(w+1)
        p=z; val=F(0)
        for i in range(15):
            val+=p/(2*i+1);p*=z*z
        return 2*val,2*(val+p/(31*(1-z*z)))
    a,b=atanh(q); c,d=atanh(F(2))
    a,b=a+k*(c if k>=0 else d),b+k*(d if k>=0 else c)
    return a*S//1,1+b*S//1

@lru_cache(None)
def exp_upper(up,denom):
    # up/(denom*S) is an exact rational upper logarithm. Use range reduction
    # and an outward Taylor tail, then rational upward ceil in 1e-7 units.
    x=F(up,denom*S)
    neg=x<0; x=abs(x); n=1
    while x>1:x/=2;n*=2
    t=F(1);s=t
    for j in range(1,13):
        t=t*x/j;s+=t
    if neg:u=(1/s)**n
    else:u=(s+t*x/13/(1-x/14))**n
    return F(1+u*10**7//1,10**7)

def inv(M):
    n=len(M); A=[list(map(F,r))+[F(i==j) for j in range(n)] for i,r in enumerate(M)]
    for j in range(n):
        i=next((i for i in range(j,n) if A[i][j]),None)
        if i is None:return
        A[i],A[j]=A[j],A[i]
        s=A[j][j];A[j]=[x/s for x in A[j]]
        for i in range(n):
            if i!=j and (s:=A[i][j]):
                A[i]=[x-s*y for x,y in zip(A[i],A[j])]
    T=[r[n:] for r in A]
    den=lcm(*(x.denominator for r in T for x in r))
    return den,tuple(tuple(int(x*den) for x in r) for r in T)

@lru_cache(None)
def template(n,branch):
    M=[(1,)+(0,)*(n-1),(-1,)*n]
    for i in range(n):
        for j in range(i+1,n):
            M.append((0,)*i+(i-j,)+(1,)*(j-i)+(0,)*(n-j-1))
    if branch:M.append((-branch,branch)+(0,)*(n-2))
    M=tuple(M)
    out=[]
    for inds in combinations(range(len(M)),n):
        A=tuple(M[i] for i in inds)
        o=inv(A)
        if o is None: continue
        den,H=o
        cull=[]
        for j,v in enumerate(M):
            if j in inds:continue
            co=tuple(sum(x*H[i][k] for i,x in enumerate(v))-(den if inds[k]==j else 0) for k in range(n))
            cull.append((j,co))
        out.append((inds,den,H,cull))
    return out
def upper_dot(coeff,L,H):
    return sum(c*(h if c>=0 else l) for c,l,h in zip(coeff,L,H))

def vertices(n,q,D,branch=0):
    Q=[q,1/D]+[1/G[j-i+1] for i in range(n) for j in range(i+1,n)]
    if branch:Q.append(F(9,10)**branch)
    b=list(map(ln_bounds,Q));L,H=zip(*b)
    for I,den,A,cul in template(n,branch):
        l=[L[i] for i in I];h=[H[i] for i in I]
        if any(upper_dot(co,l,h)<den*L[j] for j,co in cul):continue
        yield den,A,l,h

def gs_up(den,A,l,h):
    return [exp_upper(upper_dot(a,l,h),den) for a in A]

smax=F(0)
for den,A,l,h in vertices(6,F(2),(4*U)**2):
    smax=max(smax,sum(gs_up(den,A,l,h)))
assert smax/4-F(7,40)<2
print('PASS rank-one kernel',smax,'sum GS squares',flush=True)

max2=F(0); max0=F(0)
for j in range(75,118):
    a,b=F(j,100),F(j+1,100); q=min(R(a),R(b)); d=U**2/a; blu=B(b)
    for den,A,l,h in vertices(5,q,d):
        x=gs_up(den,A,l,h)
        for i in range(3):
            ratio=(x[i]+sum(x[:i])/4)/blu;max0=max(max0,ratio)
            assert ratio<1,(a,i,ratio)
    for branch in [-1,1]:
        lconst,hconst=ln_bounds(4*d/3)
        for den,A,l,h in vertices(5,q,d,branch):
            x=gs_up(den,A[:3],l,h)
            negsum=[-sum(w) for w in zip(*A[:3])]
            t=exp_upper(upper_dot(negsum,l,h)+hconst*den,2*den)
            # If x1/x0≤.9, the 2D cover improvement is ≥7*q/80.
            rhs=sum(x)/4+t-(F(7,80)*q if branch==-1 else 0)
            ratio=rhs/blu;max2=max(max2,ratio)
            assert ratio<1,(a,branch,ratio)
print('PASS red first-three size-reduced norms ratio',max0)
print('PASS impossible projected rank two ratio',max2)
print('PASS additive 41D vertical covolume >',U,'; center-density cap',32/U)
