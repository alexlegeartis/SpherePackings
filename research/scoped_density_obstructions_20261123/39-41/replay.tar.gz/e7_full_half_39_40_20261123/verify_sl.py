from pathlib import Path
from itertools import product
import numpy as np,json
Q=json.load(open('certificate.json'));M=Q['phase_isometry'];alpha=Q['alpha'];assert alpha==[0,1,14,15,22]
def mu(a,b):
 z=0
 while b:
  if b&1:z^=a
  b>>=1;a<<=1
  if a&64:a^=67
 return z
def pw(x,n):
 r=1
 while n:
  if n&1:r=mu(x,r)
  n>>=1;x=mu(x,x)
 return r
E=[i for i in range(64) if pw(i,8)==i];assert len(E)==8
XY={x^mu(2,y):(x,y)for x,y in product(E,repeat=2)};assert len(XY)==64
def qi(x):
 n=pw(x,9);v=n^pw(n,2)^pw(n,4);assert v in [0,1]
 return v
def mat(a,b,c,d):
 return [mu(a,x)^mu(b,y)^mu(2,mu(c,x)^mu(d,y)) for j,(x,y) in sorted(XY.items())]
D=np.loadtxt('local4.out',dtype=np.int32);assert len(D)==16384 and max(D)==24
B=np.array([sum((u>>i&1)<<(2*i)for i in range(7))for u in M]);X=np.arange(128);IX=X[:,None]^X[None,:]
V=D[B[:,None]^(2*B[None,:])]
S=[mat(0,1,1,0),mat(1,1,0,1),mat(14,0,0,pw(14,6)),[pw(j,2)for j in range(64)]]
for p in S:
 assert len(set(p))==64
 g=[qi(i)^qi(p[i])for i in range(64)]
 assert all(g[x^y]==g[x]^g[y]for x,y in product(range(64),repeat=2))
 u=np.array([p[j&63]|(((j>>6)^g[j&63])<<6)for j in range(128)])
 assert u[64]==64
 for j in range(128):
  assert (V[u[j],u][IX]==V[j]).all(1).any()
assert [alpha.index(mu(14,pw(a,2)))for a in alpha]==[0,2,3,1,4]
# Frobenius cubed is a genuine SL(2,F8) map; quotient semilinear order three.
a,b=XY[pw(1,8)];c,d=XY[pw(2,8)];assert mu(a,d)^mu(b,c)==1
assert [pw(i,8)for i in range(64)]==mat(a,c,b,d)
assert len({pw(14,i)for i in range(7)})==7
print('PASS all translated-cost identities for generators of common SL(2,8) and Frobenius; radical translations preserved')
