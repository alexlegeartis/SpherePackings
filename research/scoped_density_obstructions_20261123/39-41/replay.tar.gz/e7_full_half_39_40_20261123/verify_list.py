from pathlib import Path
from collections import Counter
from fractions import Fraction as F
sizes=[3,48,1806,52640,657139]
for k,n in enumerate(sizes,1):
 p=Path(f'deep{k}.out')
 lines=p.read_text().splitlines()
 orig=Path(f'reference{k}.out').read_text().splitlines()
 hist=[a for a in lines if a.startswith('HIST ')]
 allhist=[a for a in orig if a.startswith('HIST ')]
 if hist:assert hist==allhist,k
 hist=allhist
 C=Counter()
 tot=0
 for a in hist:
  _,i,j,c=a.split()
  i,j,c=map(int,(i,j,c))
  assert i<=24 and j<=28
  C.update({i:c}); C.update({j:c}); tot+=c
 assert tot==16*n
 deep=[tuple(map(int,a.split()[1:])) for a in lines if a.startswith('DEEP ')]
 assert len(deep)==len(set(deep))
 assert all(sum(bool(z) for z in a[2:])==k for a in deep)
 assert all(a[0] in (26,28) and 0<=a[1]<32 for a in deep)
 assert Counter(a[0] for a in deep)==Counter({d:c for d,c in C.items() if d>=26})
 if k==1:
  assert all(a[0]==26 or all((a[1]>>j)&1 for j,z in enumerate(a[2:]) if z==0) for a in deep)
 else:
  assert not C[28]
 print(k,n,len(deep), max(C))
all_deep='\n'.join(a.split(' ',1)[1] for k in range(1,6) for a in Path(f'deep{k}.out').read_text().splitlines() if a.startswith('DEEP '))+'\n'
assert all_deep==Path('deeplist.in').read_text()
print('PASS complete deep list and complementary maxima')
