from pathlib import Path
import numpy as np, json, hashlib
import itertools as it
P=Path(__file__).parent
Q=json.loads((P/'certificate.json').read_text())
M=Q['phase_isometry']; aa=Q['alpha']
assert aa==[0,1,14,15,22] and len(set(M))==128
def mul(a,b):
 c=0
 while b:
  if b&1:c^=a
  b>>=1;a<<=1
  if a&64:a^=67
 return c
def pow(a,n):
 c=1
 while n:
  if n&1:c=mul(a,c)
  a=mul(a,a);n>>=1
 return c
lam=6; assert pow(lam,9)==1 and pow(lam,3)!=1
assert [aa.index(mul(14,pow(x,2)))for x in aa]==[0,2,3,1,4]
def bit2(v):return sum(((v>>j)&1)<<(2*j)for j in range(7))
S=np.array([bit2(x)for x in M])
D=np.loadtxt(P/'local4.out',dtype=np.int32)
assert D.shape==(16384,) and D.max()==24
V=D[S[:,None]^2*S[None,:]]
assert np.array_equal(V.min(1),np.array([min(row)for row in V]))
U=np.arange(128);IX=U[:,None]^U[None,:]
for op in [lambda x:mul(lam,x),lambda x:pow(x,2)]:
 Hp=[op(x&63)|(x&64)for x in range(128)]
 for i in range(128):
  assert (V[Hp[i]][Hp][IX]==V[i]).all(1).any()
print('all 128x128 local translated-cost identities checked for both generators')
K=np.arange(8192)
sy=np.array([[(s&63)|(mul(x,s&63)<<6)|((s>>6)<<12)for s in range(128)]for x in aa])
best={}
for c in range(32):
 u=np.full(8192,100,dtype=np.int16);u[0]=0
 for j in range(5):
  u=(V[64*((c>>j)&1),:,None]+u[K[None,:]^sy[j,:,None]]).min(0)
 best[c]=int(max(u))
print('zero projected max-depth by mask:',best)
print('only above7:',[c for c,v in best.items()if v>28])
assert [c for c,v in best.items() if v>28]==[31]
assert best[31]==30
assert best[0]==24 and max(best.values())==30
assert max(min(best[x],best[31-x]) for x in best)==24
for x in range(1,64):assert sorted(int(V[y].min()) for y in (x,x^64))==[2,4]
print('PASS full support-0 phase bounds and unique exceptional radical bit')
