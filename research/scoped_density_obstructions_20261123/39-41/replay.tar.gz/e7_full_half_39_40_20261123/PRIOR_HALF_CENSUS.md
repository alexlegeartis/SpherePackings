# Full half-phase census for five-E7, planar closure and 40/41D nonadditive scopes

No improved density lower bound. This packet extends the exact phase
census of L35 (five-E7, squared minimum 8, covolume 2^(31/2)), and the
earlier projected-Selling/KZ no-gain results in repository archive
e7_halfphase39_41_20261123. It does not rule out general 39–41D
packings, or all half-phase vertical shapes in dimensions 39–41.

## The complete half-integral phase census

A horizontal half phase is z/2+p, where z is a binary pattern on the
five E7 blocks and p is an integer shift. Every local pattern has
an F64 projected symbol and a radical bit. The mod-four local
costs come from local4.cpp/local4.in; each depth DP minimizes
over the five local 128-choice symbol sets with XOR syndrome.
We take the maximum over all 8192 integer syndromes, independently
for both the phase and its blanket radical twist. Exact results:

| Nonzero projected slots | Projected orbits | Max squared depth | Max paired minimum |
|---|---:|---:|---:|
| 1 | 3 | 7 | 5 |
| 2 | 48 | 6.5 | 5.5 |
| 3 | 1806 | 6 | 5.5 |
| 4 | 52640 | 6.5 | 6 |
| 5 | 657139 | 6.5 | 6 |

Each projected orbit has 32 radical assignments inspected in
16 complementary pairs. The support-zero 32 cases are separately
verified by verify_tables.py: only the blanket (all five radical,
zero projected) reaches 7.5 and every other case is at most 6.5.
The actual integer torus classes have maximum 6. The ONLY
nonblanket profiles of depth >6.5 have projected support 1,
with radicals at all four other positions and a local type-two
(minimum residue cost 4 in quarter-units) at the occupied slot.
Such profiles can reach 7 and their complement with the blanket
has depth at most 5; using the looser bound 5.5 is sufficient below.

### Exact symmetry and replay

Write F64=F8 + theta F8 with theta=2. Common SL(2,8) acts on every
slot's projected symbol, updating the radical bit by the linear
difference q0(x)+q0(Sx), where q0(x)=Tr(x^9). The two projected
syndrome lines transform equivariantly, and radical parity changes
by a linear function of the first projected syndrome. It is
therefore an invertible relabeling also for NONZERO projected
syndrome. For each of three explicit SL generators plus field
squaring, verify_sl.py checks the translated-cost identity on all
128x128 local entries. The generators (swap, upper unit shear,
and diagonal with primitive 14) generate SL because diagonals
conjugate upper shear to every nonzero shear and swap gives lower
shears. Cubed squaring lies in SL; field squaring with the
simultaneous slope permutation has order three modulo SL.

Every projected tuple is SL-normalized by placing its first nonzero
symbol at 1; if not collinear, place its first independent symbol at
theta * delta for their F8 determinant delta. The two choices form a
basis, giving one normal form for the full tuple. Keep the smallest
packed normalized tuple among its three semilinear images.
The first-two-slot DP is decoded directly (two choices per full
syndrome); fourth-prefix arrays are cached and the final min-plus
convolutions use independent bytes, with all quantities in their
stated ranges. No floating input follows the exact local table.

Compile global.cpp and sparse_class.cpp with g++ -O3 -mavx2 -std=c++17.
Run global 4 and global 5 on table.in; sparse_class 1/2/3 verifies lower
supports and logs all depth >6.5 nonblanket profiles. Regenerate the
integer table from local4.cpp/local4.in and compare to local4.out.
Run verify_sl.py and verify_tables.py with NumPy.

## 37D: exact entire half phase carrier

Put whole translates of L35 at the sites of any full planar
vertical lattice, with ANY half-integral labels. If vertical
shortest squared length a>=1, planar Hermite gives area at
least sqrt(3)/2. Otherwise 1/2<=a<1, and every edge in one
shortest-axis direction forces blanket fractional difference.
Project orthogonally to that axis. For any difference of two
distinct projected sites, one of two complementary longitudinal
lift parities gives horizontal depth <=6, by the full census.
Its nearest offset has longitudinal squared length <=a because
the period of that parity is twice the shortest vector. Therefore
the projected spacing squared is at least 2-a. Area >=sqrt(a(2-a))
>=sqrt(3)/2. Consequently no lift, including nonadditive labeling
in this full planar carrier, beats the existing 16/sqrt(3).

## 39–41D vertical geometry follows on the stated scopes

For 39–41D the earlier Selling/KZ arguments apply when nonblanket
depths are <=6.5; this now includes any phase assignment whose
differences avoid the particular SINGLE-DEFECT exceptional d=7
profile above, without needing zero projected syndrome. Moreover,
if shortest vertical squared length a<1, they apply to ALL half
phases: shortest-axis increments are forced blanket, and special
single-defect pairs have shallow member <=5.5, so the projected
different-color lower bound >=2.5-a>1.5 is no weaker than B(a).
The genuinely unclosed exceptional possibility for 39–41 involves
a>=1 and those high sparse profiles. No full all-half 39–41 upper
bound is asserted.

**No additivity is needed in 40D, at stronger covolume cutoff .635.**
Assuming covol(V)<=127/200, the old projected Hermite argument gives
a in [.813,1.109] when the usual blanket-axis hypotheses hold.
Exact KZ log-polytope evaluation (tune_nonadd.py 4 635, recorded
tune40.log) bounds size-reduced basis squared lengths / B(a) by
.808,.843,.894,.984 (exact rational ratios in the log). Each
of the four projected translations therefore preserves all colors.
The projected color is constant. The five-dimensional site set
has only two original fractional labels, each with spacing >=sqrt(2).
The classical Blichfeldt occupied-density upper bound (n+2)/2^((n+2)/2)
gives combined point intensity <= (n+2)/vol(B_n). At n=5 this is
7/vol(B5)<1/(127/200), contradiction. No linear map or index-two
color kernel needed.

**No additivity is needed in 41D at covolume cutoff .53.**
With the same permitted depth hypotheses use the earlier exact
KZ certificate (kz_reference.py, unchanged) up through its first
three short projected generators and the short lift of a shortest
vector in the remaining rank-two projected quotient. Their lengths
are <B(a), independently of coloring and additivity. Thus they
generate a four-dimensional projected subgroup preserving the
colors. The four red generators with the original short axis form
a five-dimensional slice supporting only two original labels.
By Blichfeldt its covolume is >=vol(B5)/7>3/4. In the projected
GS squares this gives prefix product x0*x1*x2*x3>=(3/4)^2/a.
Add that inequality to the exact existing log polytope. The last
basis vector can be shortened by translation in the red subgroup.
Using the earlier triangle-improved covering radius in the branch
x1<=.9*x0, and ordinary nearest-plane in the other branch,
nonadd41.py 3/4 proves the squared length/B(a) at most
.911425 and .974620 respectively, exact logs included. Thus the
projected color is constant, and Blichfeldt in n=6 bounds site
intensity <=8/vol(B6)<1/.53. It follows that the earlier .53
exclusion extends to arbitrary nonadditive half labeling in the
stated scopes. All Blichfeldt numerical constants follow from
pi>3.14. The test above uses outward rational logarithms and
exponentials, not numerical optimizers.

## Constructive control (below benchmark)

d4_control.py verifies a 39D periodic density 16 using both parity
cosets of integer four-space Z^4 (vertical), period 2D4, and a rank-four quadratic
embedding D4/2D4 -> F64. The constructive phase labels on a D4
simple-root basis are 1,34,9,16, all phase syndromes (x,23*x,0)
with beta=23 a missing slope. D4 root labels have depth >=6, all
nonzero labels >=4, and the opposite parity translates by blanket
radical depth 7.5. This is a useful control, not a gain over the
pinned 18.3592594841895.
