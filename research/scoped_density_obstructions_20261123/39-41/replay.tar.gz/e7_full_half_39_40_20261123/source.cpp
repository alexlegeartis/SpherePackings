#include <bits/stdc++.h>
#include <immintrin.h>
using namespace std;
using A=array<int,5>;using W=array<uint8_t,8192>;using U=uint32_t;
constexpr int N=8192;
int C[128][128],alpha[5],M[128],mul[64][64],S[5][128],D[16384];
int perm[]={0,2,3,1,4};
int gx[6][9][64];
int gp[6][5];
int pairdec[5][5][N][2];
int lookup[5][128];
int pow8(int a,int p){int r=1;while(p--)r=mul[r][a];return r;}
int field(int a,int b){int v=0;while(b){if(b&1)v^=a;b>>=1;a<<=1;if(a&64)a^=67;}return v;}
int pack(int x){int p=0;for(int j=0;j<7;j++)p|=((x>>j&1)<<(2*j));return p;}
void setup(){
 for(int x=0;x<64;x++)for(int y=0;y<64;y++)mul[x][y]=field(x,y);
 for(int i=0;i<5;i++)for(int x=0;x<128;x++)S[i][x]=(x&63)|(mul[alpha[i]][x&63]<<6)|(x&64)*64;
 for(int ai=0;ai<128;ai++)for(int j=0;j<128;j++)C[ai][j]=D[pack(M[ai])^2*pack(M[j])];
 for(int i=0;i<5;i++)for(int j=i+1;j<5;j++){
  for(int a=0;a<128;a++)for(int b=0;b<128;b++)pairdec[i][j][S[i][a]^S[j][b]][a>>6]=128*a+b;
  for(int s=0;s<N;s++)for(int e=0;e<2;e++){int a=pairdec[i][j][s][e]>>7,b=pairdec[i][j][s][e]&127;assert((a>>6)==e&&(S[i][a]^S[j][b])==s);}
 }
 for(int j=0;j<5;j++)gp[0][j]=j;
 for(int i=1;i<6;i++)for(int j=0;j<5;j++)gp[i][j]=perm[gp[i-1][j]];
 for(int k=0;k<6;k++)for(int i=0;i<9;i++)for(int x=0;x<64;x++)gx[k][i][x]=mul[pow8(6,i)][pow8(x,1<<k)];
}
inline U enc(A a){U o=0;for(int j=0;j<5;j++)o=o*64+a[j];return o;}
bool canonical(const A&a){
 U z=enc(a);
 for(int k=0;k<6;k++)for(int i=0;i<9;i++){
  if(!(k|i))continue;
  U v=0;
  for(int j=0;j<5;j++)v|=U(gx[k][i][a[j]])<<(6*(4-gp[k][j]));
  if(v<z)return false;
 }
 return true;
}
__m256i masks[16]; 
void initmask(){for(int s=0;s<16;s++){alignas(32) uint8_t a[32];for(int i=0;i<32;i++)a[i]=(i^s)&15;masks[s]=_mm256_load_si256((__m256i*)a);}}
void step(int j,const int*cost,const uint8_t*b,uint8_t*out){
 memset(out,100,N);
 for(int a=0;a<128;a++){
  int k=S[j][a],kk=k&~31,h=cost[a];
  __m256i m=masks[k&15],v=_mm256_set1_epi8(h);
  if(k&16){
   for(int i=0;i<N;i+=32){
    __m256i l=_mm256_loadu_si256((__m256i*)(b+(i^kk)));
    l=_mm256_permute2x128_si256(l,l,1);
    l=_mm256_add_epi8(_mm256_shuffle_epi8(l,m),v);
    _mm256_storeu_si256((__m256i*)(out+i),_mm256_min_epu8(l,_mm256_loadu_si256((__m256i*)(out+i))));
   }
  }else{
   for(int i=0;i<N;i+=32){
    __m256i l=_mm256_loadu_si256((__m256i*)(b+(i^kk)));
    l=_mm256_add_epi8(_mm256_shuffle_epi8(l,m),v);
    _mm256_storeu_si256((__m256i*)(out+i),_mm256_min_epu8(l,_mm256_loadu_si256((__m256i*)(out+i))));
   }
  }
 }
}
static uint8_t prep[5][5][4][N];
void pref(){
 for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)for(int z=0;z<4;z++)for(int k=0;k<N;k++){
  int a=z&1?64:0,b=z&2?64:0,p=pairdec[i][j][k][0],q=pairdec[i][j][k][1];
  prep[i][j][z][k]=min(C[a][p>>7]+C[b][p&127],C[a][q>>7]+C[b][q&127]);
 }
}
int dp(A&a,int i,int j,int e,int r){
 const uint8_t* src;
 alignas(32) uint8_t b[N],c[N];
 if((a[i]&63)==0&&(a[j]&63)==0){
  int z=(a[i]>>6)|((a[j]>>6)*2);
  src=prep[i][j][z];
 }else{
  for(int k=0;k<N;k++){
   int p=pairdec[i][j][k][0],q=pairdec[i][j][k][1];
   c[k]=min(C[a[i]][p>>7]+C[a[j]][p&127],C[a[i]][q>>7]+C[a[j]][q&127]);
  }
  src=c;
 }
 int q=0;
 for(int k=0;k<5;k++)if(k!=i&&k!=j){
  auto out=(q%2==0?b:c);
  step(k,C[a[k]],src,out);src=out;q++;
 }
 return *max_element(src,src+N);
}

int ON[64],TW[64],inv8[8],F8[8],iv[64];
A norm(A x){
 int fst=-1,snd=-1;
 for(int i=0;i<5;i++)if(x[i]){fst=i;break;}
 if(fst<0)return x;
 int a=ON[x[fst]],b=TW[x[fst]];
 for(int i=fst+1;i<5;i++)if(mul[a][TW[x[i]]]^mul[b][ON[x[i]]]){snd=i;break;}
 if(snd<0){
  if(a)for(int &q:x)q=mul[ON[q]][iv[a]];
  else for(int &q:x)q=mul[TW[q]][iv[b]];
 }else{
  int c=ON[x[snd]],d=TW[x[snd]],t=mul[a][d]^mul[b][c];
  for(int &q:x){
   int p=ON[q],r=TW[q];
   q=mul[mul[d][p]^mul[c][r]][iv[t]]^mul[2][mul[b][p]^mul[a][r]];
  }
 }
 return x;
}
vector<U> words;
void rec(A &x,int i,int left,int stage){
 if(i==5){
  if(left)return;
  U z=enc(x);
  for(int k=1;k<=2;k++){
   A y;for(int j=0;j<5;j++)y[gp[k][j]]=gx[k][0][x[j]];
   if(enc(norm(y))<z)return;
  }
  words.push_back(z);return;
 }
 if(5-i>left){x[i]=0;rec(x,i+1,left,stage);}
 if(!left)return;
 if(!stage){x[i]=1;rec(x,i+1,left-1,1);return;}
 for(int j=1;j<64;j++){
  if(stage==1&&TW[j]&&ON[j])continue;
  x[i]=j;rec(x,i+1,left-1,stage==2||TW[j]?2:1);
 }
}
alignas(32) static unsigned char f[16][N];
alignas(32) static unsigned char v0[N],tmp[N],out[N];
int maxz(const unsigned char*o){
 __m256i a=_mm256_setzero_si256();
 for(int i=0;i<N;i+=32)a=_mm256_max_epu8(a,_mm256_loadu_si256((const __m256i*)(o+i)));
 alignas(32) unsigned char z[32];_mm256_store_si256((__m256i*)z,a);
 return *max_element(z,z+32);
}
int main(int argc,char**argv){
 for(int&a:alpha)cin>>a;for(int&a:M)cin>>a;for(auto&x:D)cin>>x;assert(cin);
 setup();initmask();
 vector<int> K;for(int i=0;i<64;i++)if(pow8(i,8)==i)K.push_back(i);assert(K.size()==8);
 memset(ON,255,sizeof ON);
 for(int a:K)for(int b:K){int x=a^mul[2][b];assert(ON[x]<0);ON[x]=a;TW[x]=b;}
 for(int a:K)if(a)iv[a]=pow8(a,6);
 A x{};
 int k=argc>1?atoi(argv[1]):4;rec(x,0,k,0);
 cerr<<"PROJECTED "<<k<<" "<<words.size()<<endl;
 sort(words.begin(),words.end());assert(adjacent_find(words.begin(),words.end())==words.end());

 pref();
 int maxima[2]={};
 for(U q:words){
    U p=q; vector<int> occupied,free;
    for(int j=4;j>=0;j--){x[j]=p&63;p>>=6;if(x[j])occupied.push_back(j);else free.push_back(j);}
    int i=free.size()>=2?free[0]:0,j=free.size()>=2?free[1]:1;
    if(i>j) swap(i,j);
    for(int e=0;e<(1<<k);e++) for(int off=0;off<2;off++){
      A a=x;
      for(int u=0;u<k;u++)a[occupied[u]]|=((e>>u)&1)*64;
      for(int u:free)a[u]|=64*off;
      int y=dp(a,i,j,0,0);
      maxima[off]=max(maxima[off],y);
      if(k<=2)cout<<q<<" "<<e<<" "<<off<<" "<<y<<"\n";
    }
 }
 cerr<<"EXACT_MAX "<<k<<" OUTSIDE0 "<<maxima[0]<<" OUTSIDE1 "<<maxima[1]<<endl;
}
