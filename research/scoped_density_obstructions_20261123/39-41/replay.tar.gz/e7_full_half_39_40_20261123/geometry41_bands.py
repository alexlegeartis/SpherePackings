from pathlib import Path
from fractions import Fraction as F
s=Path(__file__).with_name('kz_reference.py').read_text()
exec(s[:s.index('smax=F(0)')])
U=F(13,25)
B0=lambda a:F(3,2)-(a-F(1,2))**2/(4*a)
B=lambda a:min(B0(a),F(5,2)-a)
assert F(3,2)**6/F(64,3)>U**2
ratios=[F(0)]*5
lastlo=None; Pmax=F(0)
for j in range(500,1500,5):
 a,b=F(j,1000),F(j+5,1000)
 red=min(R(a),R(b)); blue=B(b);q=min(red,blue);D=U**2/a
 if a*q**5/8>U**2:continue
 local=[F(0)]*5
 for den,A,l,h in vertices(5,q,D):
  x=gs_up(den,A,l,h)
  neg=tuple(-v for v in A[4]); Pmax=max(Pmax,U**2*exp_upper(upper_dot(neg,l,h),den))
  for i in range(5):
   ratio=(x[i]+sum(x[:i],F(0))/4)/blue
   ratios[i]=max(ratios[i],ratio)
   local[i]=max(local[i],ratio)
 print(j,*(float(v) for v in local),flush=True)
print('max length over B',ratios,[float(t)for t in ratios],flush=True)
print('max first four slice squared covolume',Pmax,float(Pmax),flush=True)
