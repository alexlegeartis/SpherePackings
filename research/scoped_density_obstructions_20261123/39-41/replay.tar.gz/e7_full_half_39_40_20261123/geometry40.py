from pathlib import Path
from fractions import Fraction as F
s=Path(__file__).with_name('kz_reference.py').read_text()
exec(s[:s.index('smax=F(0)')])
U=F(61,100)
B0=lambda a:F(3,2)-(a-F(1,2))**2/(4*a)
B=lambda a:min(B0(a),F(5,2)-a)
assert F(3,2)**5/8>U**2
ratios=[F(0)]*4
for j in range(500,1500,2):
 a,b=F(j,1000),F(j+2,1000)
 red=min(R(a),R(b)); blue=B(b);q=min(red,blue);D=U**2/a
 if a*q**4/4>U**2:continue
 for den,A,l,h in vertices(4,q,D):
  x=gs_up(den,A,l,h)
  for i in range(4):
   ratio=(x[i]+sum(x[:i],F(0))/4)/blue
   ratios[i]=max(ratios[i],ratio)
print('max length over B',ratios,[float(t)for t in ratios],flush=True)
assert max(ratios)<1
pmax=32+2*U**2
for p in [F(4),pmax]:
 assert (F(15,2)+p/F(5,2)**3)/4+4*U**2/p<F(5,2)
target2=F(3**32,2**40)
assert 512/U**2<target2
print('PASS all half phases arbitrary nonadditive 40D conditional on horizontal lemmas')
