#!/bin/bash
set -euo pipefail
export OPENBLAS_NUM_THREADS=1
python verify35.py
g++ -O3 -std=c++17 local4.cpp -o local4
./local4 < local4.in > local4.replayed
cmp local4.replayed local4.out
python verify_sl.py
python verify_tables.py
g++ -O3 -std=c++17 -mavx2 deep.cpp -o deep
g++ -O3 -std=c++17 -mavx2 pair_exact.cpp -o pair_exact
g++ -O3 -std=c++17 -mavx2 source.cpp -o support_bounds
for case in 1 2 3 4 5; do
 ./deep "$case" < table.in > "deep${case}.replayed"
 diff -u <(sed -n '/^DEEP /p' "deep${case}.out") <(sed -n '/^DEEP /p' "deep${case}.replayed")
 diff -u <(sed -n '/^HIST /p' "reference${case}.out") <(sed -n '/^HIST /p' "deep${case}.replayed")
done
for case in 1 2; do
 ./support_bounds "$case" < table.in > "support${case}.replayed" 2>"support${case}.replayed.log"
 cmp "support${case}.out" "support${case}.replayed"
 cmp "support${case}.log" "support${case}.replayed.log"
done
python verify_list.py
./pair_exact deeplist.in < table.in > pair_final.replayed
cmp pair_final.replayed pair_final.out
grep -q 'PASSED 0$' pair_final.out
python geometry_final.py
python geometry40.py
python geometry41_pruned.py >/dev/null
python fourth41.py
python escape41.py
