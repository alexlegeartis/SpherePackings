s=open('geometry41_pruned.py').read()
s=s[:s.index('ratios=')]
exec(s)
m=F(0); witness=None
for j in range(500,1500,5):
 a,b=F(j,1000),F(j+5,1000)
 red=min(R(a),R(b));blue=B(b);q=min(red,blue);D=U**2/a
 if max(a*q**5/8,a**6/F(64,3))>U**2:continue
 for branch in [-1,1]:
  lc,hc=ln_bounds(4*D/3)
  for den,A,l,h in vertices(5,q,D,branch):
   x=gs_up(den,A[:3],l,h);ng=[-sum(z) for z in zip(*A[:3])]
   r=exp_upper(upper_dot(ng,l,h)+hc*den,2*den)+sum(x,F(0))/4-(F(7,80)*q if branch==-1 else 0)
   if r/blue>m:m=r/blue;witness=(j,branch)
print('fourth-lift ratio',m,float(m),witness,flush=True)
assert m<1
