"""Exact Selling-cut enumeration and 39D density comparisons."""
import numpy as np
from itertools import combinations,product
from fractions import Fraction as F
from math import prod,lcm
e=list(combinations(range(4),2))
s=[tuple(int(((m>>i)&1)!=((m>>j)&1)) for i,j in e)for m in range(1,8)]
sites=[[int(i==j)for i in range(6)]for j in range(6)]+s
def basis(A):
 M=[list(map(F,a))+[F(i==j)for j in range(6)]for i,a in enumerate(A)]
 for k in range(6):
  u=next((i for i in range(k,6)if M[i][k]),None)
  if u is None:return
  M[k],M[u]=M[u],M[k]
  v=M[k][k];M[k]=[x/v for x in M[k]]
  for j in range(6):
   if j==k:continue
   q=M[j][k]
   if q:M[j]=[a-q*b for a,b in zip(M[j],M[k])]
 return [a[6:]for a in M]
B=[(I,H)for I in combinations(range(13),6) if (H:=basis([sites[i]for i in I]))]
TT=[]
for I in combinations(range(6),3):
 c={0}
 while 1:
  D=c|{b if a in c else a for i in I for a,b in [e[i]]if a in c or b in c}
  if c==D:break
  c=D
 if len(c)==4:TT.append(I)
assert len(TT)==16
den=lcm(*(q.denominator for _,m in B for row in m for q in row))
assert den<=12
groups={}
for j in range(1,8):
 desc=np.array([[sum(int(den*q)for q,i in zip(row,inds)if i>=6 and not ((i-5)&j).bit_count()%2)
                 for row in h]for inds,h in B],dtype='int64')
 prim=np.array([[sum(int(den*q)for q,i in zip(row,inds)if i>=6 and ((i-5)&j).bit_count()%2)
                 for row in h]for inds,h in B],dtype='int64')
 groups[j]=desc,prim,np.array([(den if ((t&j).bit_count()&1) else 0) for t in range(1,8)],dtype='int64')
cuts=np.array(s,dtype='int64').T
tt=np.array(TT,dtype='int64')
D=100000
scale=den*D
assert all(np.max(abs(x))<=12 for pair in groups.values() for x in pair[:2])
def det(l,h):
 best=None
 for j,(A,B,M) in groups.items():
  pts=A*l+B*h
  ww=pts[(pts>=0).all(axis=1)]
  vv=ww[((ww@cuts)>=(den*l+(h-l)*M)[None,:]).all(axis=1)]
  assert vv.size
  assert vv.max()<5000000
  weights=np.prod(vv[:,tt].astype(object),axis=2).sum(axis=1)
  val=int(min(weights))
  if best is None or val<best[0]:best=val,j,vv[int(np.argmin(weights))]
 return F(best[0],scale**3),best[1:]

def verify():
 target2=F(3**32,5*2**40)
 needed=F(100,121)
 assert F(256)/needed<target2
 print('needed det2',needed, float(needed),flush=True)
 best=None
 for X in range(500,1500):
  a,b=F(X,1000),F(X+1,1000)
  if a**4/4 > needed: continue
  red=2-b if b<=1 else 2-1/a
  blue=min(F(3,2)-(b-F(1,2))**2/(4*b),F(5,2)-b)
  lo,hi=min(red,blue),blue
  basic=a*lo**3/2
  if blue < red and basic>needed:
   value=basic
  else:
   floor=lambda u:D*u.numerator//u.denominator
   K,att=det(floor(lo),floor(hi))
   value=max(a*K,basic)
  if best is None or value<best[0]:best=value,X
  assert value>needed,(X,value,needed)
 print('minimum exact lower bound',best, float(best[0]),flush=True)
verify()
# Upper bound on displacement 2v+W as a convex function of det(W)^2.
for p in (F(4),F(125,8)):
    assert (5+F(4,25)*p)/4+4*F(100,121)/p<F(5,2)
print('PASS nonadditive escape lift < 2.5')
