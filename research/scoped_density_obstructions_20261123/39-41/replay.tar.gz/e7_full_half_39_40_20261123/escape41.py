from pathlib import Path
s=Path('kz_reference.py').read_text();exec(s[:s.index('smax=F(0)')])
n=4
M=[(1,0,0,0)]
b=[F(2)]
for i in range(4):
 M.append(tuple(-int(i==j)for j in range(4)));b.append(F(2,5))
for i in range(3):
 M.append(tuple(int(j==i+1)-int(j==i)for j in range(4)));b.append(F(3,4))
M.extend([(1,)*4,(-1,)*4]);b.extend([F(4),F(1,34)])
L,H=zip(*map(ln_bounds,b))
pcap=F(331,500) # 0.662
best=F(0);vals=None
for I in combinations(range(len(M)),4):
 P=inv([M[i]for i in I])
 if not P:continue
 den,A=P;l=[L[i]for i in I];h=[H[i]for i in I]
 if any(upper_dot([sum(M[j][i]*A[i][k]for i in range(4))for k in range(4)],l,h)<den*L[j]for j in range(len(M))if j not in I):continue
 x=gs_up(den,A,l,h);ng=[-sum(z)for z in zip(*A)]
 f=sum(x)/4+4*pcap*exp_upper(upper_dot(ng,l,h),den)
 if f>best:best=f;vals=x
print(best,float(best),vals)
assert best<F(5,2)
