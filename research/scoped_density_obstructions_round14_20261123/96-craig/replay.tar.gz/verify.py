"""Exact finite replay: read README.md for the geometric deductions."""
from collections import Counter
from fractions import Fraction as F
from itertools import combinations
from pathlib import Path
from perfect import calc
P=97
H=Path(__file__).parent
S={i*i%P for i in range(1,P)}
assert 5 not in S and 96 in S and len(S)==48
def moments(A,B,m,stop=13):
    assert len(A)==len(set(A))==len(B)==len(set(B))
    assert set(A).isdisjoint(B)
    assert all(0<=x<P for x in A+B)
    out=[(sum(pow(x,k,P) for x in A)-sum(pow(x,k,P) for x in B))%P for k in range(stop)]
    assert out[:m]==[0]*m
    return out[m:]
def evencert(name,n):
    classes=set()
    for line in (H/name).read_text().splitlines():
        ij,a,b,st=[tuple(map(int,x.split())) for x in line.split(':')]
        assert len(a)==len(b)==n
        s,t=st; assert s in (1,96) and 1<=t<P
        A=tuple(t*x%P for i in a for x in [i,-i])
        B=tuple(t*x%P for i in b for x in [i,-i])
        if s==96:A,B=B,A
        d10,d11,d12=moments(A,B,10)
        u,v=ij
        assert u in (0,1) and d10==(1 if not u else 5) and d11==0 and d12==v
        assert ij not in classes
        classes.add(ij)
    return classes
R20=evencert('even10.log',5); R24=evencert('even12.log',6)
assert len(R20)==168 and len(R24)==26 and len(R20|R24)==194
assert Counter(k for k,v in R20)=={0:77,1:91}
assert set(pow(a,10,P)for a in range(1,P))==S
assert {5*a%P for a in S}==set(range(1,P))-S
assert (11%P)!=0
print('M10 nonzero: all 194 normalized differences have q<=24; q20 deficits 20/6.')
def reports(name):
    l=(H/name).read_text().splitlines()
    for i,s in enumerate(l):
        if s.startswith('FIBRES'):
            yield tuple(map(int,l[i+1].split())),tuple(map(int,l[i+2].split()))
A,B=next(reports('l11.log'))
assert len(A)==11
d11,d12=moments(A,B,11)
assert d11 and len({pow(a,11,P) for a in range(1,P)})==P-1 and 12%P!=0
found=set()
for A,B in reports('l12.log'):
    assert len(A)==12
    (d12,)=moments(A,B,12)
    found.update(d12*pow(a,12,P)%P for a in range(1,P))
assert set(range(1,P))<=found
print('M10 zero: full nonzero M11 obstruction q22, remaining M12 obstruction q24.')
a2=[a*a%P for a in range(P)]
a3=[a*a*a%P for a in range(P)]
def projective_orbit(U,V):
    return min((U*a2[x]%P)*P + V*a3[x]%P for x in range(1,P))
wanted={projective_orbit(U,V)for U in range(P)for V in range(P)}
seen=set()
for l in (H/'generic9.log').read_text().splitlines():
    k,a,b=l.split(':')
    A=tuple(map(int,a.split()));B=tuple(map(int,b.split()));assert len(A)==9
    a,b,c,d=moments(A,B,9);assert a
    s=pow(a,-1,P);t=-b*s*pow(10,-1,P)%P
    u=s*(c+11*t*b+55*t*t*a)%P
    v=s*(d+12*t*c+66*t*t*b+220*t*t*t*a)%P
    key=projective_orbit(u,v)
    assert key==int(k) and key not in seen
    seen.add(key)
assert seen==wanted and len(seen)==102
print('M9 nonzero: all 102 projective-affine directions contain q18 difference.')
A,B=[tuple(map(int,l.split())) for l in (H/'witness28.txt').read_text().splitlines()]
assert len(A)==14 and moments(A,B,13)==[]
c={x:1 for x in A}|{x:-1 for x in B}
chi=lambda z: int(z%P in S)-int(z%P not in S and z%P!=0)
K=sum(cx*cy*chi(x-y) for x,cx in c.items()for y,cy in c.items())
assert K==-100
assert calc(A+B)==[48,48]
print('q28 affine orbit has Paley correlation -100 and full symmetric rank.')
# Paley clique max (normalizing an edge to 0,1).
adj=[sum(1<<j for j in range(P) if (i-j)%P in S) for i in range(P)]
def clique(b,need):
    if not need:return True
    while b.bit_count()>=need:
        k=b&-b;b^=k
        if clique(b&adj[k.bit_length()-1],need-1):return True
    return False
b=adj[0]&adj[1]
assert clique(b,4) and not clique(b,5)
for t in range(2,98):
    for hypothetical_max in range(1,21):
        # At most 6 large maxima (>=4), since all their differences are squares.
        n=t*3+min(6,t)*max(0,hypothetical_max-3)
        if hypothetical_max>=7:
            # A large vertex excludes all 48 nonsquare neighbors.
            if t>49:continue
        assert n<=309
print('Paley clique number 6; sum of per-M10 M12-group maxima <=309 for multiple M10 groups.')
# Density compared to pinned independent lattice and periodic constructions.
periodic=F(4**96,47**14)/F(10950866250772257481,50625000000000000)
lattice=F(9,2)**96/(4*47**18)
assert lattice<periodic
lmax=F(26,25)
# Condition ratio <=4/3 -> trace/(96 det^(1/96)) <= r.
r=F(7,6)/(1+F(1,7)+F(1,2*7**2)+F(1,6*7**3))
def pack(q,k):
    return F(q,4)**96*k*k/97**25
for q,k,stretch in [(18,97**4,lmax),(20,97**3,lmax),
                    (22,309*97,lmax),(24,309,lmax),(28,1,r)]:
    actual=pack(q*stretch,k)
    assert actual<lattice
    print('q',q,'count',k,'Euclidean ratio vs lattice',float(pack(q,k)/lattice)**.5,
          'deformed ratio vs lattice',float(actual/lattice)**.5)
# Stronger singleton-only Legendre metric interval; compare sqrt(97) <197/20.
def g(u):
    return (28*(u+1/u)-F(2000,197)*(u-1/u))/2
u=F(77,50)
assert pack(g(F(1)),1)<lattice and pack(g(u),1)<lattice
print('PASS: both family exclusions strictly below pinned lattice (thus periodic) densities.')
# All index <=3 sublattices of L13 have a q28 witness.
tri=[tuple(map(int,l.split()))for l in (H/'tri28.txt').read_text().splitlines()]
assert len(tri)==3 and all(len(x)==14 for x in tri)
for a,b in combinations(tri,2):assert moments(a,b,13)==[]
def trim(a):
    while a and not a[-1]:a.pop()
    return a
def rem(a,b):
    a=a.copy()
    while a and len(a)>=len(b):
        coeff=a[-1]*pow(b[-1],-1,3)
        for i,x in enumerate(b):a[len(a)-len(b)+i]=(a[len(a)-len(b)+i]-coeff*x)%3
        trim(a)
    return a
f=[int(any(x in a for a in tri)) for x in range(P)]
a=[2]+[0]*(P-1)+[1];b=trim(f.copy())
while b:a,b=b,rem(a,b)
assert a in ([2,1],[1,2])
print('PASS: q28 triple; its cyclic incidence sum spans the mod-3 augmentation.')
# Exact full Legendre-frequency exclusion of L13.
import json
Pell=F(9848857802,10**9)
assert Pell*Pell>P and 5604**2-P*569**2==-1
assert 5604+569*Pell < 11209
target=F(2837,100)
assert pack(target,1)<lattice
J=[[chi(i-j) for j in range(P)] for i in range(P)]
assert all(sum(J[i][k]*J[k][j]for k in range(P))==P*int(i==j)-1 for i in range(P) for j in range(P))
prev=1
for lo,hi,q,g,v in json.loads((H/'frequency13.json').read_text()):
    assert lo==prev and lo<hi and len(v)==P and all(isinstance(x,int)for x in v)
    assert sum(v)==0 and all(sum(v[i]*pow(i,k,P)for i in range(P))%P==0 for k in range(1,13))
    assert sum(x*x for x in v)==q
    assert sum(a*b*J[i][j]for i,a in enumerate(v)for j,b in enumerate(v))==g<0
    a=(q+F(g)/Pell)/2;b=(q-F(g)/Pell)/2
    assert a>0 and b>0
    assert max(a*u+b/u for u in [F(lo),F(hi)])<target
    prev=hi
    print('Legendre L13 interval',lo,hi,'q,K',q,g)
assert prev==11209
print('PASS: every L13 Legendre metric loses, including arbitrary scale and all Pell periods.')
# Additional whole-continuum closures use shared integer vectors.
data=json.loads((H/'frequency_all.json').read_text())
vpool=[]
for v in data['vectors']:
    assert len(v)==P and all(isinstance(x,int) for x in v) and sum(v)==0
    q=sum(x*x for x in v)
    g=sum(a*b*J[i][j] for i,a in enumerate(v) for j,b in enumerate(v))
    assert q>0 and g<=0
    first=next(k for k in range(1,P) if sum(v[i]*pow(i,k,P) for i in range(P))%P)
    vpool.append((q,g,first))
for m0,(cap,cells) in data['chains'].items():
    m=int(m0);cap=F(cap);assert 1<=m<=48
    assert (cap/4)**96/P**(2*m-1) < lattice
    prev=F(1)
    for lo,hi,i in cells:
        lo,hi=F(lo),F(hi)
        assert lo==prev and lo<hi and 0<=i<len(vpool)
        q,g,first=vpool[i]
        assert first>=m
        a=(q+F(g)/Pell)/2; b=(q-F(g)/Pell)/2
        assert a>0 and b>0 and max(a*u+b/u for u in [lo,hi])<cap
        prev=hi
    assert prev==11209
closed={int(i) for i in data['chains']}
assert len(closed)>=38 and set(range(13,17))<=closed
print('Additional full-frequency closure:',len(closed),'of 48 classes.')
print('Not certified:',','.join(str(m)for m in range(1,49)if m not in closed))
