P=97; L=389
omega=next(a for a in range(2,L) if pow(a,P,L)==1)
table=[[pow(omega,i*j,L) for j in range(P)] for i in range(P)]
pairs={s:[(a,b)for a in range(1,P)for b in range(a,P)if (a+b)%P==s]for s in [0,1]}
assert all(len(x)==48 for x in pairs.values())
def rank(M):
 i=0
 for c in range(len(M[0])):
  j=next((j for j in range(i,len(M)) if M[j][c]),None)
  if j is None:continue
  M[i],M[j]=M[j],M[i];v=pow(M[i][c],-1,L)
  M[i]=[(v*x)%L for x in M[i]]
  for j in range(i+1,len(M)):
   f=M[j][c]
   if f:M[j]=[(x-f*y)%L for x,y in zip(M[j],M[i])]
  i+=1
 return i
def calc(xs):
 a,b=xs[:14],xs[14:]
 z=[(sum(row[j] for j in a)-sum(row[j] for j in b))%L for row in table]
 return [rank([[z[x*d%P]*z[y*d%P]%L for x,y in pairs[s]] for d in range(1,49)]) for s in [0,1]]
if __name__=='__main__':
 seen=set()
 for line in open('even14_all.txt'):
  k,*xs=map(int,line.split())
  if abs(k) in seen:continue
  seen.add(abs(k));a,b=calc(xs);print(k,a,b)
  if a==b==48: print(xs);break
