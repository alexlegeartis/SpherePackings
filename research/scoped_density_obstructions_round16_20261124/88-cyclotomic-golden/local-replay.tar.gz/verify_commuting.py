"""Standard-library replay; pass the seven-parent inputs.bin.gz as argv[1]."""
import gzip, hashlib, struct, sys
from pathlib import Path
P=Path(__file__).resolve().parent
raw=Path(sys.argv[1]).read_bytes()
vec=(P/'vec.bin.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='8741db7e6453bfeb445b3a5722359745ab1145be3e44985f0a51b42d2f4846c1'
assert hashlib.sha256(vec).hexdigest()=='df9d85e14110b22ce3a131b528387ab96a84bbd3110a4cb52e434adb80dcac69'
it=iter(x for x, in struct.iter_unpack('<h',gzip.decompress(raw)))
vt=iter(x for x, in struct.iter_unpack('<h',gzip.decompress(vec)))
p=1009
N=88
for name in ('L0','L','139','599','4049','4969','X1151s24'):
    G=[[0]*N for _ in range(N)]
    for i in range(N):
        for j in range(i+1):
            G[i][j]=G[j][i]=next(it)
    U=[[next(it) for _ in range(N)] for _ in range(N)]
    if name not in ('4049','4969'):
        continue
    Ut=list(zip(*U))
    piv={}
    for _ in range(44):
        x=[next(vt) for i in range(N)]
        z=[sum(a*b for a,b in zip(x,r)) for r in G]
        assert sum(a*b for a,b in zip(x,z))==8
        y=x
        c=[]
        for _ in range(44):
            c.append(sum(a*b for a,b in zip(y,z))%p)
            y=[sum(a*b for a,b in zip(y,r))%p for r in Ut]
        for j,r in sorted(piv.items()):
            c=[(a-c[j]*b)%p for a,b in zip(c,r)]
        i=next(i for i,a in enumerate(c) if a)
        piv[i]=[a*pow(c[i],-1,p)%p for a in c]
    assert len(piv)==44
    print(f'X{name}: all 44 probes have norm 8; observed 44 × 44 invariant moment rank 44 over F_{p}')
assert next(it,None) is None and next(vt,None) is None
