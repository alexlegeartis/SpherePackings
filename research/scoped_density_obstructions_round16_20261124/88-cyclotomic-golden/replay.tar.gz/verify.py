import gzip, hashlib, json, math, struct
from fractions import Fraction as F
from pathlib import Path

P = Path(__file__).resolve().parent
N = 88
I = [[int(i==j) for j in range(N)] for i in range(N)]

def T(a):
    return list(map(list,zip(*a)))

def mul(a,b):
    b=T(b)
    return [[sum(x*y for x,y in zip(u,v) if x and y) for v in b] for u in a]

def power(a,k):
    r=I
    while k:
        if k&1:
            r=mul(r,a)
        a=mul(a,a)
        k//=2
    return r

def det_pd(a):
    """Leading-principal Bareiss elimination, checking definiteness."""
    c=[r[:] for r in a]; d=1
    for k in range(N-1):
        q=c[k][k]
        assert q>0
        for i in range(k+1,N):
            for j in range(i,N):
                y,r=divmod(c[i][j]*q-c[i][k]*c[k][j],d)
                assert r==0
                c[i][j]=c[j][i]=y
        d=q
    assert c[-1][-1]>0
    return c[-1][-1]

def form(z,a):
    return sum(z[i]*a[i][j]*z[j] for i in range(N) for j in range(N))

raw=(P/'inputs.bin.gz').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='8741db7e6453bfeb445b3a5722359745ab1145be3e44985f0a51b42d2f4846c1'
vals=iter(x for (x,) in struct.iter_unpack('<h',gzip.decompress(raw)))
W=json.loads((P/'witnesses.json').read_text())
names=['L0','L','139','599','4049','4969','X1151s24']
assert set(names)==set(W)
for n in names:
    G=[[0]*N for _ in range(N)]
    for i in range(N):
        for j in range(i+1):
            G[i][j]=G[j][i]=next(vals)
    U=[[next(vals) for j in range(N)] for i in range(N)]
    assert all(G[i][i]%2==0 for i in range(N))
    assert det_pd(G)==1
    assert mul(mul(U,G),T(U))==G
    assert W[n]['power']==46
    Q=power(U,46)
    assert power(Q,5)==I
    qp=[power(Q,i) for i in range(5)]
    assert all(sum(q[i][j] for q in qp)==0 for i in range(N) for j in range(N))
    S=[[I[i][j]+2*(Q[i][j]+qp[4][i][j]) for j in range(N)] for i in range(N)]
    assert mul(S,S)==[[5*x for x in r] for r in I]
    SG=mul(S,G)
    assert SG==T(SG)
    Fm=[[(5*G[i][j]+SG[i][j])//2 for j in range(N)] for i in range(N)]
    assert all(2*Fm[i][j]==5*G[i][j]+SG[i][j] for i in range(N) for j in range(N))
    assert det_pd(Fm)==5**44
    x=W[n]['coordinates']
    assert len(x)==88 and all(type(z) is int for z in x)
    assert (form(x,G),form(x,SG))==(8,-8)
    assert form(x,Fm)==16
    y=[(x[j]+sum(x[i]*S[i][j] for i in range(N)))//2 for j in range(N)]
    assert (form(y,G),form(y,SG))==(8,8)
    print(f'{n}: det endpoint = 5^44; literal original norm-8 pairings +/-8; both endpoints norm <=16')
assert next(vals,None) is None
# pi < 355/113; compare to the pinned rounded benchmark facts with ample slack.
up=F(355,113)**44/F(math.factorial(44))*2**44
assert up < F('4.959e-20') < F('1.85e-19')
print('Golden family Hermite invariant <=8, sphere fraction < 4.959e-20, for all seven parents')
