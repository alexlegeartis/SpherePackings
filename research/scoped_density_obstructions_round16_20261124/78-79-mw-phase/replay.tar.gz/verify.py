#!/usr/bin/env python3
"""Exact replay: positive contact weights, span, and all inherited projected losses."""
import gzip,json
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path
from math import lcm
import numpy as np
import sympy as S
HERE=Path(__file__).resolve().parent
P=(HERE/'parent_frontier80.npz')
if not P.exists():
    P=HERE.parents[1]/'cm58_20261116/frontier/parent80.npz'
raw=P.read_bytes()
assert sha256(raw).hexdigest()=='4fe7254711e903de8d9d5a0996dfb83e19267b660ee09929d0fceff24ae12f73'
G=np.load(P,allow_pickle=False)['G']
G=np.asarray(G,dtype=object)
setups=json.loads((HERE/'sections.json').read_bytes())['rows']
W=json.loads(gzip.decompress((HERE/'witness.json.gz').read_bytes()))
assert [s['dimension'] for s in setups]==[78,79]==[w['dimension'] for w in W]
# An approximate inverse is merely a proposal for an exact integral identity.
D=np.asarray(np.rint(41*np.linalg.inv(G.astype(float))).astype('int64'),dtype=object)
assert np.array_equal(G@D,41*np.eye(80,dtype=object))
def rank(A,p):
    Q=np.array(A%p,dtype='i8');col=0
    for j in range(Q.shape[1]):
        ids=np.flatnonzero(Q[col:,j])
        if not len(ids):continue
        k=col+int(ids[0]);Q[[col,k]]=Q[[k,col]]
        Q[col]=Q[col]*pow(int(Q[col,j]),-1,p)%p
        Q[col+1:]=(Q[col+1:]-Q[col+1:,j,None]*Q[col])%p;col+=1
    return col
for s,w in zip(setups,W):
    n=s['dimension'];B=np.array(s['normal_labels'],dtype=object);K=B@D@B.T
    K=S.Matrix(K.tolist())
    L=np.asarray(s['cluster_labels'],dtype=object);i,j=s['attainment_label_pair']
    assert w['pair']==[i,j]
    dp=L[i]-L[j]
    den=int(K.det()); adj=np.array(K.adjugate().tolist(),dtype=object)
    m=dp@adj@B@D
    assert den==w['projection_denom'] and list(m)==w['projection_num']
    beta=F(int(41*dp@adj@dp),den);assert beta=={78:F(779,2572),79:F(41,234)}[n]
    losses=[F(int(41*(x-y)@adj@(x-y)),den) for x in L for y in L]
    assert max(losses)==beta and 0<beta<14
    X=np.asarray(w['contact'],dtype=object); assert len(X)=={78:240,79:220}[n]
    assert all(type(t) is int for row in w['contact'] for t in row)
    assert np.array_equal(X@B.T,np.tile(dp,(len(X),1)))
    assert all(q==14 for q in np.sum((X@G)*X,axis=1))
    V=X*den-m
    assert not np.any(V@B.T)
    assert all(v==F(14)-beta for v in map(lambda q:F(int(q),den**2),np.sum((V@G)*V,axis=1)))
    assert rank(V,101)==n
    # Fix one uniform positive weight on the full contact set and additional
    # weights on a small chosen support. Solve the literal system exactly.
    nV=len(V); idx=w['support']; assert len(idx)==n and len(set(idx))==n
    A=np.c_[V,np.ones(nV,dtype=object)].T
    H=S.Matrix(np.c_[nV*A[:,idx],A.sum(axis=1)].tolist())
    rhs=S.Matrix([0]*80+[1]); x,p=H.gauss_jordan_solve(rhs)
    assert not p and H*x==rhs and min(x)>0
    a=[F(x[-1])]*nV
    for i,u in zip(idx,x[:-1]):a[i]+=nV*F(u)
    assert len(a)==nV and min(a)>0 and sum(a)==1
    den0=lcm(*(t.denominator for t in a));weights=np.array([int(t*den0) for t in a],dtype=object)
    assert np.all(weights@V==0)
    print(f'PASS: {n}D, {len(X)} exact critical contacts, tangent rank {n}; positive convex stress')
