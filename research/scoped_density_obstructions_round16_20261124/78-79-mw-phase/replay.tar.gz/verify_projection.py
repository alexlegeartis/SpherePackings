from fractions import Fraction as F

def f(x):
    assert 0<x<14
    return x*(14-x)**79
peak=F(7,40)
balance=41/peak
assert 234<balance<235
winner=4*f(F(41,234))
assert winner>4*f(F(41,235))
assert winner>F(9,4)*f(peak)
assert winner>f(peak)
print("PASS: MW80 79D worst-loss formula optimizes over every normal and finite label cluster with >= 2 labels.")
