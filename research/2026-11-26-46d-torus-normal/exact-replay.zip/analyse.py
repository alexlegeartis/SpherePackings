from mixed import F
from itertools import combinations
from fractions import Fraction as F
import json,sys
from math import sqrt
def vertices(aff):
 n=len(aff[0])-1
 if n==0:return [()]
 if n==1:return [(q,) for a,b in aff if b and all(c+d*(q:=-a/b)>=0 for c,d in aff)]
 if n==2:
  vs=[]
  for (a,b,c),(d,e,f) in combinations(aff,2):
   det=b*f-c*e
   if not det:continue
   x=(c*d-a*f)/det;y=(a*e-b*d)/det
   if all(z+h*x+k*y>=0 for z,h,k in aff):vs.append((x,y))
  return list(set(vs))
 raise Exception(n)
def clique(adj):
 n=len(adj);best=[]
 def dfs(R,P):
  nonlocal best
  if len(R)+P.bit_count()<=len(best):return
  if not P:
   best=R;return
  order=[];bounds=[];left=P;i=0
  while left:
   i+=1;av=left
   while av:
    b=av&-av;v=b.bit_length()-1
    order.append(v);bounds.append(i)
    left^=b;av&=~(adj[v]|b)
  for v,b in zip(order[::-1],bounds[::-1]):
   if len(R)+b<=len(best):return
   dfs(R+[v],P&adj[v]);P^=1<<v
 # transitive includes zero
 dfs([0],adj[0]);return best
def analyse(path):
 o=json.load(open(path));A,B,g=(o[k] for k in ['A','B','g']);D=A*B-g*g
 keys=list(map(tuple,o['keys']));n=len(keys);q=list(map(F,o['minima']));aff=[list(map(F,r)) for r in o['aff']];vs=vertices(aff);assert vs
 inv=lambda k:tuple((-v)%D for v in k)
 G=sorted(set(keys)|set(map(inv,keys)));assert len(G)==D
 def ev(r,v):return r[0]+sum(a*b for a,b in zip(v,r[1:]))
 best=(F(0),);worst=[]
 for v in vs:
  vals=[ev(r,v) for r in aff]
  costs={k:max(F(0),h-(0 if vals[i]>0 else 2 if vals[n+i]>0 else 9)) for i,(k,h) in enumerate(zip(keys,q))}
  costs.update({inv(k):c for k,c in list(costs.items())})
  for i,(k,h) in enumerate(zip(keys,q)):
   if vals[i]==vals[n+i]==0:worst.append((k,str(h)))
  for b in sorted(set(costs.values())):
   if b>=6:continue
   adj=[sum(1<<j for j,(u,w) in enumerate(G) if i!=j and costs[(u-x)%D,(w-y)%D]<=b) for i,(x,y) in enumerate(G)]
   C=clique(adj);s=len(C);val=F(s*s,D)*((6-b)/4)**46
   if val>best[0]:best=(val,s,b,[G[c] for c in C],v)
 print('BEST',A,B,g,'vs',len(vs),'density',sqrt(best[0]),'s,b',best[1:3],'doubleempty',len(set(worst)),list(set(worst))[:7],flush=True)
 return best,vs
if __name__=='__main__':
 for path in sys.argv[1:]:analyse(path)
