from fractions import Fraction as F
from analyse import clique
from math import sqrt
import json,sys
def run(path):
 o=json.load(open(path));r=json.load(open('lp_'+path));A,B,g=[o[k] for k in ('A','B','g')];D=A*B-g*g
 costs={tuple(k):F(t[2]) for k,t in zip(o['keys'],r['rows'])}
 costs.update({((-u)%D,(-v)%D):t for (u,v),t in list(costs.items())})
 G=sorted(costs);best=(F(0),)
 for b in sorted(set(costs.values())):
  if b>=6:continue
  adj=[sum(1<<j for j,(u,w) in enumerate(G) if i!=j and costs[(u-x)%D,(w-y)%D]<=b) for i,(x,y) in enumerate(G)]
  C=clique(adj);s=len(C);val=F(s*s,D)*((6-b)/4)**46
  if val>best[0]:best=(val,b,s,[G[c] for c in C])
 print('all',A,B,g,'δ',sqrt(best[0]),'beta',best[1],'k',best[2],flush=True)
 return best
if __name__=='__main__':
 for p in sys.argv[1:]:run(p)
