"""Delsarte in each ternary translation quotient of the good mask."""
import numpy as np
from itertools import product
from collections import Counter
from fractions import Fraction as F
import json
from pathlib import Path
cert=json.loads(Path(__file__).with_name("period1.json").read_text())
V=np.array(list(product(range(3),repeat=5)),dtype=np.int64)
k=3**np.arange(4,-1,-1)
G=2*np.eye(5,dtype=np.int64)
for i,j in [(0,1),(1,2),(2,3),(1,4)]:G[i,j]=G[j,i]=-1
def tp(v):
    q=np.sum((v@G)*v,axis=-1)//2%3
    return np.where(q,q,np.where((v==0).all(-1),0,3))
ty=tp(V);
assert tuple(np.bincount(ty))==(1,72,90,80)
R=[V[np.where(ty==i)[0][0]] for i in range(4)]
def good(x,y):return (x>0)&(y>0)&(x+y>=4)
for a,b in [(1,3),(2,2),(2,3),(3,3)]:
    u,v=R[a],R[b]
    x=[tp((V+i*u)%3) for i in range(3)];y=[tp((V+i*v)%3) for i in range(3)]
    c=[16*x0[:,None]+y0 for x0,y0 in zip(x,y)]
    key=np.min([c[i]*4096+c[(i+1)%3]*64+c[(i+2)%3]for i in range(3)],axis=0)
    usable=np.all([good(x0[:,None],y0) for x0,y0 in zip(x,y)],axis=0)
    origin=np.min([c[i][0,0]*4096+c[(i+1)%3][0,0]*64+c[(i+2)%3][0,0]for i in range(3)])
    usable|=(key==origin)
    dkey, gid=np.unique(key[usable],return_inverse=True)
    dkey=dkey.tolist();j0=dkey.index(origin)
    ii,jj=np.where(usable)
    sh=np.bincount(gid);assert all(sh%3==0) and sh[j0]==3
    sh=sh//3
    t=(64*x[0]+4*x[1]+x[2])[:,None]*256+(64*y[0]+4*y[1]+y[2])
    allowed=(V@G@u)[:,None]+(V@G@v)
    mask=(allowed%3)==0
    ids=np.flatnonzero(mask.ravel());l, ix=np.unique(t.ravel()[ids],return_index=True)
    rr,cc=np.divmod(ids[ix],243)
    C=V@G@V.T%3
    Q=[]
    for p,q in zip(rr,cc):
     z=(C[p,ii]+C[q,jj])%3==0
     xi=3*np.bincount(gid,weights=z).astype(int)//3-sh
     Q.append(xi)
    A=np.array(sorted(set(map(tuple,Q))),dtype=np.int64)
    ref=cert[f'{a},{b}']
    dd=[F(0)]*len(A)
    for i,p in ref['lambda']:
        dd[i]=F(p)
    assert min(dd)>=0
    w=[F(int(s))+sum(f*int(t)for f,t in zip(dd,r))for r,s in zip(A.T,sh)]
    cap=F(ref['cap'])
    assert w[j0]==cap and all(q<=0 for i,q in enumerate(w) if i!=j0)
    print('PASS period',a,b,'quotient count <=',cap)
