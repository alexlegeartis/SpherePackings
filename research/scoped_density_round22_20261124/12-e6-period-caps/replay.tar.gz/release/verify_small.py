"""Exact small-dimensional checks used in the isotropic-period proof."""
from itertools import product,combinations
from fractions import Fraction as F
import numpy as np
V=np.array(list(product(range(3),repeat=3)),dtype=np.int64)
q=(V[:,0]*V[:,1]-V[:,2]**2)%3
T=np.where(q,q,np.where((V==0).all(1),0,3))
M=np.bincount(T)
assert tuple(M)==(1,6,12,8)
W=np.array(sorted({tuple(3*sum(((V@x)%3==0)&(T==j))-M[j]for j in range(4))for x in V}))
S=[0,7,10,11,13,14,15]; W=np.kron(W,W)[:,S]; g=np.kron(M,M)[S]
Y={4:F(4,3),7:F(1,6),10:F(1),11:F(1,2),13:F(1,2),14:F(3,4)}
assert [int(g[k])+sum(v*int(W[i,k])for i,v in Y.items())for k in range(7)]==[18,0,0,0,0,0,0]
print('PASS residual rank-three product good code cap 18')
# A full 3D additive good code cannot project with both forms nondegenerate.
mon=np.array([V[:,i]*V[:,j]for i in range(3) for j in range(i,3)]).T
coef=np.array(list(product(range(3),repeat=6)))
P=coef@mon.T%3
for c in [1,2]:
    a=(V[:,0]**2+V[:,1]**2+c*V[:,2]**2)%3
    ok=(P[:,a==1]==0).all(1)&(P[:,a==2]!=1).all(1)
    assert np.sum(ok)==1 and ok[0]
print('PASS full rank-three additive incompatibility')
# All allowed affine lines in the quadratic-value table.
g={(0,0),(0,1),(0,2),(1,0),(2,0),(2,2)}
V2=list(product(range(3),repeat=2))
lines={tuple(sorted(((x+k*a)%3,(y+k*b)%3)for k in range(3)))
       for x,y in g for a,b in V2[1:] if all(((x+k*a)%3,(y+k*b)%3)in g for k in range(3))}
assert lines=={((0,0),(0,1),(0,2)),((0,0),(1,0),(2,0)),((0,1),(1,0),(2,2))}
B={(a,b)for a,b in V2[1:] if not a or not b or (a+b)%3==0}
ds=lambda x,y:((x[0]-y[0])%3,(x[1]-y[1])%3)
K=[S for S in combinations(V2,3) if all(ds(x,y)in B for x,y in combinations(S,2))]
assert not any(all(ds(x,y)in B for x,y in combinations(S,2)) for S in combinations(V2,4))
for S in K:
    edges=[ds(x,y)for x,y in combinations(S,2)]
    if any(not (a and b) for a,b in edges):
        assert all(any(i!=j and not all(ds(S[i],S[j])) for j in range(3)) for i in range(3))
print('PASS covector seven-angle table, cap of three fibres, and axis incidence')
# A literal 63-label witness reaching the analytic rank-two period cap.
from pathlib import Path
S=np.loadtxt(Path(__file__).with_name('rank2-63.txt'),dtype=np.int64)
assert S.shape==(63,2) and (S>=0).all() and (S<243).all()
X=np.array(list(product(range(3),repeat=5)),dtype=np.int64)
G=2*np.eye(5,dtype=np.int64)
for i,j in [(0,1),(1,2),(2,3),(1,4)]:G[i,j]=G[j,i]=-1
C=X[S]
D=(C[:,None,:,:]-C[None,:,:,:])%3
q=np.sum((D@G)*D,axis=-1)//2%3
t=np.where(q,q,np.where((D==0).all(-1),0,3))
z=~np.eye(len(S),dtype=bool)
assert (t[z]>0).all() and (t[z].sum(-1)>=4).all()
S0={tuple(x.ravel()) for x in C}
P=[u for u in (C-C[0])%3 if all(tuple(x.ravel()) in S0 for x in (C+u)%3)]
assert len(P)==9
for p in P:
    assert not (np.sum((p@G)*p,axis=-1)//2%3).any()
print('PASS literal 63-label good clique with exact isotropic rank-two period')
S=np.loadtxt(Path(__file__).with_name('residue-18.txt'),dtype=np.int64)
assert S.shape==(18,2) and len(set(map(tuple,S)))==18
for a,b in combinations(S,2):
    d=(V[a]-V[b])%3
    q=(d[:,0]*d[:,1]-d[:,2]**2)%3
    t=np.where(q,q,np.where((d==0).all(-1),0,3))
    assert (t>0).all() and t.sum()>=4
print('PASS rank-three product cap 18 is also attained.')
