def lb(k):
    if k==0:return 0
    if k<=2:return 1
    if k<=5:return 2
    if k<=8:return 3
    return 4
open_cases=[]
for A in range(103,110):
    for J in range((923-4*A+4)//5,min(A,108)+1):
        if J+lb(A-J)<103:open_cases.append((A,J))
assert open_cases==[(107,99),(109,98)]
assert 4*107+5*99==923 and 4*109+5*98-923==3
print('PASS: two exceptional zero-five count profiles after the all-good reduction')
