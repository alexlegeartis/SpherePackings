"""Exact 96D tail and comparator verifier. The MW92 half bound is separate."""
from decimal import Decimal,localcontext
from fractions import Fraction as F
from itertools import product
from math import factorial, prod,isqrt

def arctan_bounds(n,L=60):
    terms=[F((-1)**i,(2*i+1)*n**(2*i+1)) for i in range(L)]
    s=sum(terms)
    return s,s+F(1,(2*L+1)*n**(2*L+1))
a0,a1=arctan_bounds(5);b0,b1=arctan_bounds(239);pi0=16*a0-4*b1;pi1=16*a1-4*b0
n=92;a=46;N=13
A=[F(factorial(2*i),factorial(i)) for i in range(N+1)]
P=[F(1)]+[F(0)]*N
for _ in range(n):
    P=[sum(P[i]*A[j-i] for i in range(j+1)) for j in range(N+1)]
S=[F(factorial(j)*P[j],prod(range(n,n+2*j))) for j in range(N+1)]
from math import comb
mu=F(2,n+1)
M=[sum(comb(j,i)*(-mu)**(j-i)*S[i] for i in range(j+1)) for j in range(N+1)]
expect=sum((-1)**j*comb(a+j-1,j)*M[j]/(1+mu)**(a+j) for j in range(N+1))
cfr=(n+1)*F(n,n+1)**a*expect
d4=F(106743,10000)
assert 4*pi1**46*d4**46 < factorial(46)*47**7*cfr
assert d4>F(32,3)

def quad(z):
    a,b,c,d=z
    return F(65*(a*a+b*b+c*c)+63*d*d-2*(a*b+a*c+b*c),24)
def color(z):
    a,b,c,d=z
    assert sum(z)%2==0
    return (a+b+c)%3,a%2,(b+sum(z)//2)%2
assert len({color((a,-a+b,-b+c,-c+2*d)) for a,b,c,d in product(range(6),repeat=4)})==12
counts={}
for z in product(range(-2,3),repeat=4):
    r=sum(x*x for x in z)
    if not 0<r<=6 or sum(z)%2:continue
    t,a,b=color(z)
    q=quad(z)
    have=d4 if t else F(21,2) if a or b else F(0)
    assert q+have>=16
    counts[t,a,b]=min(counts.get((t,a,b),F(100)),q)
assert quad((1,-1,0,0))==F(11,2)
assert F(21,8)*7>16
D=4*F(11,4)**2*F(21,8)**2
D0=F(10950866250772257481,50625000000000000)
assert D==F(53361,256) and D<D0
C=F(4**96,47**14*D)
VOL0=pi0**48/factorial(48)
WITH_VOL2=C*VOL0**2
# Exact safe decimal floor, not rounding the new density upwards.
unit=F(1,10**37)
A=WITH_VOL2/unit**2
K=isqrt(A.numerator//A.denominator)
assert (K*unit)**2<=WITH_VOL2<((K+1)*unit)**2
with localcontext() as ctx:
    ctx.prec=48
    ratio=Decimal(D0.numerator*D.denominator)/Decimal(D0.denominator*D.numerator)
    print('PASS four-ball CFR, 12-color tail, exact corrected determinant',D)
    print('exact decimal occupied density floor', Decimal(K)/Decimal(10)**37)
    print('gain percent from exact determinants',100*(ctx.sqrt(ratio)-1))
    print('color minima for short vectors', {str(k):str(c) for k,c in counts.items()})
