from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
from fractions import Fraction as F
import numpy as np,sys,random,math,itertools
P=47; N=46; D=1<<24
qr={pow(i,2,P) for i in range(1,P)}
seedA=[0,1,0,0,1,3,3,1,0,3,0,0,0,3,0,2,0,2,1,1,0,0,3,0,0,0,0,0,1,0,0,0,3,0,0,2,3,1,3,2,0,0,0,1,0,0,0]
seedB=[0,0,0,1,0,3,1,1,1,3,0,2,0,0,0,2,0,0,3,1,0,0,0,1,3,0,0,0,3,1,2,0,1,1,3,0,0,1,1,0,1,0,3,0,1,0,0]
def roll(x,i): return x[-i:]+x[:-i] if i else x[:]
def data(which):
    seq=seedA if which=='A' else seedB
    residues=(1,4,5) if which=='A' else (4,6,6)
    res=[residues[0]]+[residues[1 if x in qr else 2] for x in range(1,P)]
    off=[-x%8 for x in res]
    assert sum(off)%8==0
    off[-1]-=sum(off)
    y0=[P*x for x in off]; assert sum(y0)==0 and all(a%8==b for a,b in zip(y0,res))
    # explicit simultaneous systematic CRT basis, then exact LLL
    gb=[roll(seq,j) for j in range(23)]
    gb=[[v%2 for v in r] for r in gb]
    for j in range(23):
        t=next(i for i in range(j,23) if gb[i][j]); gb[j],gb[t]=gb[t],gb[j]
        for i in range(23):
            if i!=j and gb[i][j]: gb[i]=[u^v for u,v in zip(gb[i],gb[j])]
    # polynomial of degree <=19 interpolating one on a selected first-20 point
    rb=[]
    for j in range(20):
        den=math.prod(j-i for i in range(20) if i!=j)%47
        rb.append([math.prod(k-i for i in range(20) if i!=j)*pow(den,-1,47)%47 for k in range(47)])
    rows=[]
    for j in range(46):
        if j<23:
            rp=rb[j] if j<20 else [0]*47
            row=[v+47*((v^g)&1) for v,g in zip(rp,gb[j])]
            row=row[:46]
        else: row=[94*(i==j) for i in range(46)]
        rows.append(row)
    L=Matrix(rows)
    assert all(L[i,j]==0 for i in range(46) for j in range(i)) and math.prod(L[i,i] for i in range(46))==47**26*2**23
    basis=[list(map(int,r))+[-sum(r)] for r in L.tolist()]
    return basis,L,y0
def analyze(B,y0,prefix,rad):
    A=np.array(B,dtype=np.int64)
    M=A @ A.T
    m=len(B)
    mu=[[F(0) for _ in range(m)] for _ in range(m)]
    d=[None]*m
    for i in range(m):
        for j in range(i):
            mu[i][j]=(int(M[i,j])-sum(mu[i][k]*mu[j][k]*d[k] for k in range(j)))/d[j]
        d[i]=F(int(M[i,i]))-sum(mu[i][k]**2*d[k] for k in range(i))
    def coords(v):
        p=[None]*m
        for i in range(m):
            p[i]=(sum(F(a)*b for a,b in zip(v,B[i]))-sum(mu[i][k]*p[k]*d[k] for k in range(i)))/d[i]
        return p
    offset=[F(a,2) for a in y0]
    pr=coords(offset)
    for j in reversed(range(m)):
        z=-round(pr[j]); offset=[a+z*b for a,b in zip(offset,B[j])]
        for i in range(j): pr[i]+=z*mu[j][i]
        pr[j]+=z
    assert pr==coords(offset)
    assert 2*sum(offset)==0
    with open(prefix,'w') as f:
        print(m,rad,file=f)
        print(*[math.floor(a*D) for a in d],file=f)
        print(*[math.floor(a*D) for a in pr],file=f)
        for i in range(m): print(*[math.floor(a*D) for a in mu[i]],file=f)
        print(*[int(2*a) for a in offset],file=f)
        for b in B: print(*b,file=f)
    print(prefix,'gs length min max',round(math.sqrt(float(min(d))),3),round(math.sqrt(float(max(d))),3),'babai norm2',float(sum(a*a for a in offset)),flush=True)
if __name__=='__main__':
    wh=sys.argv[1]; prefix=sys.argv[2]; rad=int(sys.argv[3])
    B,L,y0=data(wh)
    print('constructed HNF',wh,flush=True)
    R=Matrix(B).lll(delta=F(99,100))
    analyze([list(map(int,row)) for row in R.tolist()],y0,prefix,rad)
