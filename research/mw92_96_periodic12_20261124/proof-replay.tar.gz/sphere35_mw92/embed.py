"""Exact modular-lift replay; modular solves merely propose integral matrices."""
from pathlib import Path
import hashlib,json,math
import numpy as np
from sympy import Matrix
from sympy.matrices.normalforms import hermite_normal_form
from basis import seedA,seedB
pins={"parent.npz":"56e2a6f803556a84009b517956960080710610e9","maps.npz":"d92c3ab31b37ba0253282d9bb65f20cdeecd0a70","unitaries.json":"dcae2bb66dfd4feac2566bc3391ccbd8b6eca1ca","forms.npz":"48e9478bb923a59169a2f2c341a0ad6332781380"}
for name,oid in pins.items():
    data=Path(name).read_bytes()
    assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==oid
n=92; p=65537; small=47
z=np.load('parent.npz'); G=z['G']; sec=z['section_coordinates']; S,T=np.load('maps.npz')['maps']
I=np.eye(n,dtype='i8')
FF=[[i%47,i//47] for i in range(2209)]
def add(a,b):return (a%47+b%47)%47+47*((a//47+b//47)%47)
def sub(a,b):return (a%47-b%47)%47+47*((a//47-b//47)%47)
def mul(a,b):
    ar,ai=FF[a];br,bi=FF[b]
    return (ar*br-ai*bi)%47+47*((ar*bi+ai*br)%47)
def pw(a,k):
    x=1
    while k:
      if k&1:x=mul(x,a)
      a=mul(a,a);k//=2
    return x
def trim(x):
    while x and not x[-1]:x.pop()
    return x
def dp(a,b):
    x=[sub(u,v)for u,v in zip(a,b)]
    return trim(x)
inv=[0]+[pw(a,2207)for a in range(1,2209)]
def neg(a):return (-a%47)+47*((- (a//47))%47)
def conj(a):return a%47+47*((-(a//47))%47)
def power_form(a,b,k):return [mul(math.comb(k,i)%47,mul(pw(a,i),pw(b,k-i)))for i in range(k+1)]
def gcddeg(a,b):
    a,b=list(a),list(b)
    while b:
      if len(a)<len(b):a,b=b,a
      if len(b)==1:return 0
      bi=inv[b[-1]]
      while len(a)>=len(b):
        off=len(a)-len(b); f=mul(a[-1],bi)
        a.pop()
        if f:
          for i in range(len(b)-1):a[i+off]=sub(a[i+off],mul(f,b[i]))
        trim(a)
      a,b=b,a
    return len(a)-1
def calc(X,Y,x,y):
    a,b=dp(X,x),dp(Y,y)
    if not a and not b:return 16
    if not a and Y==[neg(e)for e in y]:return -16
    ideg=min(([17-len(a)] if a else [])+([25-len(b)] if b else []))
    return 8-gcddeg(a,b)-ideg
def independent(A,p):
    R={}; ids=[]
    for i,row in enumerate(A):
      row=row.copy()%p
      for j,k in R.items():row=(row-row[j]*k)%p
      pos=np.flatnonzero(row)
      if len(pos):
        j=int(pos[0]);R[j]=row*pow(int(row[j]),-1,p)%p;ids.append(i)
        if len(ids)==A.shape[1]:break
    return ids
def solve(A,B,p=p):
    m=len(A); assert A.shape==(m,m)
    A=np.c_[A,B].astype('i8')%p
    for j in range(m):
      ix=j+int(np.flatnonzero(A[j:,j])[0]); A[[j,ix]]=A[[ix,j]]
      A[j]=A[j]*pow(int(A[j,j]),-1,p)%p
      c=A[:,j].copy(); c[j]=0
      A=(A-c[:,None]*A[j])%p
    assert np.array_equal(A[:,:m],np.eye(m,dtype='i8'))
    return A[:,m:]
def signed(a):return (a+p//2)%p-p//2
F=sec[independent(sec,p)]
assert len(F)==n
U=json.loads(Path('unitaries.json').read_text())['unitaries']
P=[([neg(v)for v in power_form(a,b,16)],power_form(c,d,24))for a,b,c,d in (U[i] for i in independent(sec,p))]
H=np.array([[calc([conj(e)for e in X],[conj(e)for e in Y],x,y) for x,y in P] for X,Y in P],dtype='i8')
C=signed((solve(F, H)@solve((G@F.T).T,I).T)%p)
assert np.array_equal(F@C@G@F.T,H) and np.array_equal(C@G@C.T,G) and np.array_equal(C@C,I)
A1,A2=np.load('forms.npz')['H'][:2]
Gi=solve(G,I)
J=signed(Gi*0+(A1@Gi%p)@(A2@Gi%p)%p*pow(3,-1,p)%p)
# Prove integral J equals H1*G^-1*H2*G^-1/3 via exact inverse scaled by 47.
assert np.array_equal(J@J+J+I,0*I) and np.array_equal(J@G@J.T,G) and np.array_equal(J@T,T@J)
assert np.array_equal(S@G@S.T,G) and np.array_equal(T@G@T.T,G)
mp=np.linalg.matrix_power
assert np.array_equal(mp(S,276),I) and np.array_equal(mp(T,23),I)
SI=mp(S,275)
R=S@C@mp(S@T@SI@T,39)@C@SI
P=[I]
for i in range(47):P.append(P[-1]@R)
assert np.array_equal(P[-1],I) and not np.any(sum(P[:-1]))
assert np.array_equal(T@R@mp(T,22),mp(R,7))
U=sum(mp(T,j)for j in range(23))
E0=hermite_normal_form(Matrix(U.T.tolist())).T
M=Matrix([[-3,-2,4,1],[-3,3,2,-1],[14,-8,-5,-6],[-19,15,-1,14]])
assert abs(M.det())==1
E=np.array((M*E0).tolist(),dtype='i8')
assert E.shape==(4,92) and np.array_equal(E@T,E) and hermite_normal_form(Matrix(E.tolist()))==Matrix.eye(4)
eg=E@G@E.T
assert np.array_equal(eg,23*np.array([[8,4,1,-1],[4,8,1,0],[1,1,8,-4],[-1,0,-4,8]]))
F=np.r_[[E[0]@P[j] for j in range(46)],[E[2]@P[j]for j in range(46)]]
cols=range(47)
def chi(x):return 1 if pow(x%47,23,47)==1 else -1
Vref=np.r_[[[188*int(i==j)-4 for i in cols]+[0]*47 for j in range(46)],
    [[23 if i==j or chi(j-i)==1 else -24 for i in cols]+[94*int(i==j)-2 for i in cols] for j in range(46)]]
V=signed(solve(F,Vref))
assert np.array_equal(F@V,Vref) and np.array_equal(V@V.T,188*G)
assert not np.any(V[:,:47].sum(axis=1)) and not np.any(V[:,47:].sum(axis=1))
for i in (0,47):
    mods=np.array([[pow(j,k,47)for k in range(27)]for j in cols],dtype='i8')
    assert not np.any((V[:,i:i+47]@mods)%47)
jlist=[(7*q)%47 for q in cols]
assert np.array_equal(T@V,V[:,jlist+[47+j for j in jlist]])
def ord4(B):
    B=np.array(B,dtype='i8')%4; r=0
    for j in range(B.shape[1]):
      a=np.flatnonzero(B[r:,j]&1)
      if len(a):
        t=r+int(a[0]);B[[r,t]]=B[[t,r]]
        B[r]=B[r]*int(B[r,j])%4
        c=B[:,j].copy();c[r]=0;B=(B-c[:,None]*B[r])%4
        r+=1
    assert not np.any(B[r:]&1)
    return 2*r+len(independent(B[r:]//2,2))
seed=np.array([np.r_[np.roll(seedA,j),np.roll(seedB,j)] for j in cols],dtype='i8')
assert ord4(seed)==ord4(np.r_[seed,V])==92
assert ord4(seed[:,:47])==ord4(seed[:,47:])==69
assert len(independent(seed%2,2))==46
assert len(independent(seed[:,:47]%2,2))==len(independent(seed[:,47:]%2,2))==23
assert Matrix(G.tolist()).det(method='domain-ge')==47**14
h2=E[0]+E[3]
assert h2@G@h2==322 and np.any(h2%2)
pat=(h2@V)%8
assert list(pat[:47])==[1]+[4 if chi(j)==1 else 5 for j in range(1,47)]
assert list(pat[47:])==[4]+[6]*46
print('PASS parent identities, signed modular-lift embedding, all RS and C4 inclusions, lattice index, class and 23-fold symmetry.',flush=True)
print('h2 =',list(map(int,h2)),flush=True)
np.savez('embedding.npz',V=V,E=E,J=J)
