from pathlib import Path
from sympy import Matrix
import sys
base=Path(sys.argv[1])
for side in 'AB':
 lines=(base/(side+'.in')).read_text().splitlines()
 off=list(map(int,lines[49].split()))
 B=[list(map(int,x.split())) for x in lines[50:96]]
 z=Matrix([off[:-1]])*Matrix([r[:-1] for r in B]).inv(method='DM')
 assert all(v.q==1 for v in z)
 assert (z*Matrix(B)).tolist()==[off]
 Path(side+'.neg').write_text(' '.join(str(v) for v in z)+'\n')

