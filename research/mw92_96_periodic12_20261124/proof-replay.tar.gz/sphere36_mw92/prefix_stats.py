from pathlib import Path
from collections import Counter
from math import log,exp,pi,lgamma
import sys
base=Path(sys.argv[1]); current=Path(sys.argv[2]); D=2**24; n=46; cut=39
mask=(1<<64)-1
for side in 'AB':
 f=iter(map(int,(base/(side+'.in')).read_text().split()))
 assert next(f)==n; next(f); d=[next(f) for _ in range(n)]; t=[next(f) for _ in range(n)]; mu=[[next(f) for _ in range(n)] for _ in range(n)]
 paths=[]; outputs={};remains=Counter(); total=Counter(); complete=Counter(); weight=Counter(); nweight=Counter(); seen=Counter(); last={}
 for w in range(4):
  h=(current/f'{side}.{w}.cover').read_text().split()
  assert h[0]=='mw92-cover-v1' and h[3:6]==[str(w),'4','39']
  paths.append(None if h[1]=='EXHAUSTED' else tuple(map(int,h[9:15])))
 x=[0]*n
 # heuristic operation count of a projected sphere from continuous volumes; never a proof receipt
 leads=[0]*(cut+1)
 s=0
 for k in range(1,cut+2):
  s+=0.5*log(d[cut+1-k]/D)
  leads[k-1]=exp(k/2*log(pi)-lgamma(k/2+1)-s)
 def dfs(i,rem,err):
  if i==cut:
   a=tuple(x[j] for j in range(n-1,i,-1));h=14695981039346656037
   for v in a:
    v &= mask
    for _ in range(8):h=((h^(v&255))*1099511628211)&mask;v>>=8
   w=h%4
   rr=rem/D
   ss=rr**0.5
   p=1.0;c=0.0
   for value in leads:
    p*=ss;c+=value*p
   total[w]+=1;weight[w]+=c
   if a==paths[w]: seen[w]+=1
   if not seen[w]:
    complete[w]+=1;nweight[w]+=c
   else:
    q=((h>>32)^h)>>2
    remains[(w,q%4)]+=c
   return
  c=t[i]+sum(mu[j][i]*x[j] for j in range(i+1,n))
  m=-((c+D//2)//D) if c>=0 else (-c+D//2)//D
  a=0
  while True:
   any_ok=False
   for s in ((1,) if a==0 else (-1,1)):
    z=m+s*a; u=max(0,abs(c+D*z)-err); e=d[i]*u*u//D**2
    if e>rem:continue
    any_ok=True; x[i]=z; dfs(i-1,rem-e,err+abs(z))
   if not any_ok:break
   a+=1
 dfs(45,846*D,1)
 for j in range(4): assert seen[j]==(paths[j]!=None)
 for j in range(4):
  print(side,j,'exact completed whole prefixes',complete[j],'/',total[j],'weighted estimate total/done bn',round(weight[j]/1e9,3),round(nweight[j]/1e9,3),'rem subshards',{i:round(remains[j,i]/1e9,3) for i in range(4)})

