from pathlib import Path
from math import isqrt
import sys
D=1<<24;n=46;N=47
base=Path(sys.argv[1])
for side in ('A','B'):
 for complement in ('','d'):
  path=base/(side+complement+'.in')
  a=iter(map(int,path.read_text().split()))
  assert next(a)==n;next(a)
  d=[next(a)for i in range(n)];t=[abs(next(a))for i in range(n)]
  mu=[[abs(next(a))for j in range(n)]for i in range(n)]
  off=[abs(next(a))for j in range(N)]
  B=[[abs(next(a))for j in range(N)]for i in range(n)]
  if complement:
   U=[[abs(next(a))for j in range(N)]for i in range(n)]
   vmax=47*12;off=[vmax]*N;t=[sum(row)*vmax for row in U];e0=N*vmax
   for i in reversed(range(n)):
    z=(t[i]+D//2)//D
    e0+=z
    for j in range(i+1):t[j]+=(D if j==i else mu[i][j])*z
    off=[x+4*z*y for x,y in zip(off,B[i])]
   assert max(t)<1<<62 and max(off)<1<<62
   t=[D//2]*n
  else:e0=1
  cap=447 if complement else 846
  M=[0]*n;err=e0; maxce=0; maxproduct=0; true_sum_bound=0
  for i in reversed(range(n)):
   ce=t[i]+sum(mu[j][i]*M[j]for j in range(i+1,n))
   rad=isqrt((cap*D+1)*D**2//d[i])+1
   assert (d[i]*rad*rad)>(cap*D+1)*D**2
   M[i]=(ce+err+rad+2*D)//D
   assert ce+D*M[i]<1<<62
   maxce=max(maxce,ce+D*M[i])
   maxproduct=max(maxproduct,d[i]*(rad+2*D)**2)
   true_sum_bound+=(d[i]+1)*(rad+2*err)**2
   err+=M[i]
  assert maxproduct<1<<126
  factor=4 if complement else 2
  assert max(off[j]+factor*sum(M[i]*B[i][j]for i in range(n)) for j in range(N))<1<<62
  lim=(true_sum_bound*factor*factor)//D**3+1
  assert lim<1<<61
  print(path.name,'PASS arithmetic ranges: max c+D*x',maxce,'max d*u*u',maxproduct,'norm bound',lim)

