#include <bits/stdc++.h>
using namespace std; using ll=long long;using I=__int128_t;
const ll D=1LL<<24; const int n=46,N=47; using V=array<ll,N>;
using Row=array<int,N>;
ll ab(ll x){return x<0?-x:x;}
ll mid(ll c){return c>0? -(c+D/2)/D : (-c+D/2)/D;}
#include "add.inc"
struct LL {
 ll d[n],t[n],mu[n][n],B[n][N],U[n][N]; V off; ll x[n]; uint64_t cnt[n]={};
 LL()=default;
 LL(const char *p,bool dual) {ifstream f(p); int m,rad; f>>m>>rad; assert(m==n);
   for(ll &z:d)f>>z;for(ll &z:t)f>>z;
   for(auto &r:mu)for(ll &z:r)f>>z;
   for(ll &z:off)f>>z;
   for(auto&r:B)for(ll&z:r)f>>z;
   if(dual)for(auto&r:U)for(ll&z:r)f>>z;
   assert(f && all_of(d,d+n,[](ll z){return z>0;}));
 }
 template<class F> bool dfs(int i,ll rem,ll err,F &test){
   if(i<0)return test();
   ++cnt[i];
   ll c=t[i];for(int j=i+1;j<n;j++)c+=mu[j][i]*x[j];
   const ll m=mid(c);
   for(ll a=0;;a++){
     bool any=false;
     for(ll s=a?-1:1;s<=1;s+=2){
       ll xx=m+s*a, u=max(0LL,ab(c+D*xx)-err);
       I e=I(d[i])*u*u/(I(D)*D);
       if(e>rem)continue;
       any=true; x[i]=xx;
       if(dfs(i-1,rem-(ll)e,err+ab(xx),test))return true;
     }
     if(!any)return false;
    }
 }
 V reconstruct(int factor){V y=off;for(int i=0;i<n;i++)for(int j=0;j<N;j++)y[j]+=factor*x[i]*B[i][j];return y;}
 ll origin(const V &v) {
   off=v; fill(t,t+n,0); ll err=0;
   for(ll a:v)err+=ab(a);
   for(int i=0;i<n;i++)for(int j=0;j<N;j++)t[i]+=U[i][j]*v[j];
   for(int i=n-1;i>=0;i--){
     ll z=mid(t[i]); err+=ab(z);
     for(int j=0;j<=i;j++)t[j]+=(j==i?D:mu[i][j])*z;
     for(int j=0;j<N;j++)off[j]+=4*z*B[i][j];
   }
   return err;
 }
 void preflight(ll err,ll cap){
   ll M[n],acc=err;
   for(int i=n-1;i>=0;i--){
     I ce=ab(t[i]);
     for(int j=i+1;j<n;j++)ce+=I(ab(mu[j][i]))*M[j];
     // q=floor((d_i/D)*(u/D)^2*D), rem<=cap*D.
     long double radius=(long double)D*sqrt((cap+1.0L)/((long double)d[i]/D));
     ll rad=llround(radius)+4; assert(I(d[i])*rad*rad > I(cap*D+1)*D*D);
     I bd=ce+acc+rad+2*D; assert(bd<(I(1)<<58));
     M[i]=(ll)(bd/D); acc+=M[i];
   }
 }
};
Row SA={0,1,0,0,1,3,3,1,0,3,0,0,0,3,0,2,0,2,1,1,0,0,3,0,0,0,0,0,1,0,0,0,3,0,0,2,3,1,3,2,0,0,0,1,0,0,0};
Row SB={0,0,0,1,0,3,1,1,1,3,0,2,0,0,0,2,0,0,3,1,0,0,0,1,3,0,0,0,3,1,2,0,1,1,3,0,0,1,1,0,1,0,3,0,1,0,0};
struct Mod4 {
 Row a[N],b[N]; vector<pair<int,int>> piv;
 Mod4(bool Bfirst){
   Row A=Bfirst?SB:SA, B=Bfirst?SA:SB;
   for(int i=0;i<N;i++)for(int j=0;j<N;j++){a[i][j]=A[(N+j-i)%N];b[i][j]=B[(N+j-i)%N];}
   int pos=0;
   for(int v:{1,2}) for(int j=0;j<N;j++){
     int k=pos;
     while(k<N&&!(v==1 ? (a[k][j]&1) : a[k][j]==2))k++;
     if(k==N)continue;
     swap(a[k],a[pos]);swap(b[k],b[pos]);
     if(v==1 && a[pos][j]==3)for(int c=0;c<N;c++){a[pos][c]=(-a[pos][c])&3;b[pos][c]=(-b[pos][c])&3;}
     for(int i=pos+1;i<N;i++){
       int d=a[i][j]/v;
       for(int c=0;c<N;c++){a[i][c]=(a[i][c]-d*a[pos][c])&3;b[i][c]=(b[i][c]-d*b[pos][c])&3;}
     }
     piv.push_back({j,v});pos++;
   }
   assert(piv.size()==46);
 }
 V offset(Row x,const Row &r2) {
   Row z={};
   for(int i=0;i<n;i++){
     auto [j,v]=piv[i]; assert(x[j]%v==0);
     int c=x[j]/v;
     for(int k=0;k<N;k++){x[k]=(x[k]-c*a[i][k])&3;z[k]=(z[k]+c*b[i][k])&3;}
   }
   for(int v:x)assert(v==0);
   V y; ll s=0;
   for(int i=0;i<N;i++){ll a=(-(r2[i]+2*z[i])+4)&7;a-=4;y[i]=a;s+=a;}
   assert(s%8==0);
   // Rebalance sum with the least costly +/-8 changes, by sorting.
   if(s){
     vector<int> order(N);iota(order.begin(),order.end(),0);
     sort(order.begin(),order.end(),[&](int i,int j){return s>0?y[i]>y[j]:y[i]<y[j];});
     for(int j=0;j<ab(s)/8;j++)y[order[j]]+=s>0?-8:8;
   }
   for(ll &a:y)a*=47;
   assert(accumulate(y.begin(),y.end(),0LL)==0);
   return y;
 }
};
int q[V{}.size()]; Row offset_pat(bool B){
  Row out;bool qr[N]={};for(int i=1;i<N;i++)qr[i*i%N]=1;
  for(int i=0;i<N;i++)out[i]=!i?(B?4:1):(B?6:(qr[i]?4:5));
  return out;
}
bool representative(const V &y){
  int m=1;
  for(int u=1;u<23;u++){
   m=m*7%N;
   for(int j=1;j<N;j++){
     if(y[j]<y[j*m%N])break;
     if(y[j]>y[j*m%N])return false;
   }
  }
  return true;
}
ll norm(V y){ll e=0;for(ll a:y)e+=a*a;return e;}
void info(LL&s,LL&g,ll h,ll c,ll done,int deepest){
  cerr<<"short "<<h<<" orbits "<<c<<" complement "<<done<<" min observed energy "<<deepest<<" nodes: "<<s.cnt[12]<<","<<s.cnt[20]<<" complement-nodes "<<g.cnt[12]<<","<<g.cnt[20]<<endl;
}
int main(int argc,char **argv){
  assert(argc>=4);
  bool bs=(argv[3][0]=='B');
  LL s(argv[1],false),g(argv[2],true);Mod4 code(bs);
  Row r1=offset_pat(bs),r2=offset_pat(!bs);
  ll hits=0,orb=0,checks=0,maxo=(argc>4?atoll(argv[4]):INT_MAX), min_small=INT_MAX;int min_total=INT_MAX;
  assert(argc==10);
  maxo=INT_MAX;
  sh=atoi(argv[4]); nsh=atoi(argv[5]); cut=atoi(argv[6]);
  assert(0<=sh&&sh<nsh&&cut>=0&&cut<45);
  checkpoint=argv[7]; cap_nodes=strtoull(argv[8],nullptr,10);
  hashfile(argv[1]); hashfile(argv[2]); hinput=(hinput^argv[3][0])*1099511628211ULL;
  loaded();
  signal(SIGTERM,stop_now);signal(SIGINT,stop_now);
  stamp=chrono::steady_clock::now();
  s.preflight(1,846);
  auto short_step=[&](){
    V y=s.reconstruct(2); ll e=norm(y);
    if(e>3384)return false;
    assert((e%376)==0);
    for(ll a:y)cout<<a<<" ";cout<<endl;
    ++hits;min_small=min(min_small,e);
    if(!representative(y))return false;
    ++orb; 
    if(!(orb%500))info(s,g,hits,orb,checks,min_total);
    if(orb>maxo){info(s,g,hits,orb,checks,min_total);cerr<<"LIMIT"<<endl;exit(3);}
    Row x;for(int i=0;i<N;i++){assert((y[i]-r1[i])%2==0);x[i]=((y[i]-r1[i])/2)&3;}
    V orig=code.offset(x,r2);
    ll err=g.origin(orig);g.preflight(err,7144/16+1);
    auto comp_step=[&](){
      V z=g.reconstruct(4);
      ll e2=norm(z);
      if(e+e2>7144)return false;
      assert(e2%376==0);
      if(e+e2==6392 && e>3008)return false; // the other block will cover this split
      min_total=min(min_total,(int)(e+e2));
      cout<<"BLOCKER total "<<e+e2<<" short "<<e<<" side "<<argv[3]<<endl;
      for(ll a:y)cout<<a<<" ";cout<<endl;for(ll a:z)cout<<a<<" ";cout<<endl;
      return true;
    };
    checks++;
    return g.dfs(n-1,(7144-e)*D/16,err,comp_step);
  };
  const bool found=outer(s,n-1,atoll(argv[9])*D,1,short_step);
  saved(found?"FOUND":"EXHAUSTED",45,s.x);
  info(s,g,hits,orb,checks,min_total);
  cerr<<(found?"FOUND":"EXHAUSTED")<<" small minimum "<<min_small<<endl;
}
