from pathlib import Path
import hashlib
import sys
base=Path(sys.argv[1]); run=Path(sys.argv[2]); mask=(1<<64)-1
def fnv(raw,h=14695981039346656037):
 for c in raw:h=((h^c)*1099511628211)&mask
 return h
def parse(p,tag,sh,h):
 r=p.read_text().split()
 assert r[0]==tag and r[2:6]==[str(h),str(sh),'4','39']
 assert int(r[6])>=1
 i=int(r[8])
 if r[1]=='ACTIVE':
  assert -1<=i<=39
  x=list(map(int,r[9:9+(45-i)]));assert len(x)==45-i
  if len(x)>=6: assert fnv(b''.join(v.to_bytes(8,'little',signed=True) for v in x[:6]))%4==sh
  return r[1],x,r[9+45-i:]
 assert r[1] in ['FOUND','EXHAUSTED'] and i==45
 return r[1],[],r[9:]
def check_result(stem):
 assert not (run/f'{stem}.out').read_bytes()
 assert 'EXHAUSTED small minimum' in (run/f'{stem}.log').read_text()
# Refuse duplicate or missing refinements, or relabelled roots.
tasks={}
for l in (run/'tasks.csv').read_text().splitlines():
 side,s,u,n=l.split()
 key=(side,int(s));u,n=int(u),int(n)
 assert side in 'AB' and int(s) in range(4) and 0<=u<n
 tasks.setdefault(key,[]).append((u,n))
receipts={}
r=run/'run_split.receipts'
if r.exists():
 for l in r.read_text().splitlines():
  k,v=l.split();receipts[k]=v
all_proved=True
for side in 'AB':
 h=fnv((base/(side+'.in')).read_bytes()+(base/(side+'d.in')).read_bytes()+side.encode())
 for sh in range(4):
  key=(side,sh);stem=f'{side}.{sh}'; root=run/'seed'/f'{stem}.cover'
  status,x,rest=parse(root,'mw92-cover-v1',sh,h)
  assert not rest
  if status=='EXHAUSTED':
   assert key not in tasks
   check_result(stem)
   print(stem,'EXHAUSTED root')
   continue
  assert status=='ACTIVE' and key in tasks
  plans=tasks[key]; ns=plans[0][1]
  assert sorted(plans)==[(u,ns) for u in range(ns)]
  ph=fnv(root.read_bytes(),h)
  for u in range(ns):
   ch=f'{stem}.{u}.of{ns}'; path=run/f'{ch}.cover'
   if not path.exists():
    print(ch,'NOT STARTED');all_proved=False;continue
   status,x,meta=parse(path,'mw92-cover-v2',sh,h)
   assert meta==[str(u),str(ns),str(ph)]
   if status=='ACTIVE':
    print(ch,'ACTIVE');all_proved=False;continue
   assert status=='EXHAUSTED' and receipts[ch]=='exit:0'
   check_result(ch); print(ch,'EXHAUSTED')
print('PASS exact full shard cover' if all_proved else 'INCOMPLETE shard cover')
sys.exit(0 if all_proved else 2)

