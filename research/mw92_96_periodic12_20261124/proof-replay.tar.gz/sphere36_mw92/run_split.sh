#!/usr/bin/env bash
set -u
prev=/tmp/sphere35_mw92
deadline=$(date -u -d '2026-11-24 21:17:50' +%s)
export prev deadline
python3 -B - <<'PY' > tasks.csv
from pathlib import Path
import ast,re
config=[]
for l in Path('seed/prefix-stats.log').read_text().splitlines():
    s,t,*_=l.split(); n=int(t)
    sub=ast.literal_eval(l.split('rem subshards ')[1]); weight=sum(sub.values())
    if Path(f'seed/{s}.{n}.cover').read_text().split()[1]=='EXHAUSTED': continue
    if n>=2 and weight<8: config.append((weight,s,n,0,1))
    else:
        for g,w in sub.items():config.append((w,s,n,g,4))
for w,s,n,g,G in sorted(config,reverse=True):print(s,n,g,G)
PY
run_one(){
  local side="$1" sh="$2" sub="$3" nsub="$4" p lft
  p="$side.$sh.$sub.of$nsub"
  lft="$((deadline-$(date +%s)))"
  if ((lft<=0)); then return 0; fi
  timeout -k 20s "$lft" ./split "$prev/$side.in" "$prev/${side}d.in" "$side" "$sh" 4 39 "$p.cover" 0 "seed/$side.$sh.cover" "$sub" "$nsub" >> "$p.out" 2>> "$p.log"
  printf '%s exit:%d\n' "$p" "$?" >> run_split.receipts
  return 0
}
export -f run_one
xargs -n4 -P8 bash -c 'run_one "$@"' -- < tasks.csv
