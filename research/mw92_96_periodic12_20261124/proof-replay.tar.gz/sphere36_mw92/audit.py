from pathlib import Path
from fractions import Fraction as F
from sympy import Matrix
from math import floor
import hashlib
import numpy as np
import sys
sys.path.insert(0,'/tmp/sphere35_mw92')
from basis import seedA,seedB
from collections import Counter
p=47;n=46;D=2**24
base=Path(sys.argv[1])
for s,seed in [('A',seedA),('B',seedB)]:
 H={}
 for i in range(p):
  v=sum((seed[(j-i)%p]&1)<<j for j in range(p))
  while v:
   b=v.bit_length()-1
   if b in H:v^=H[b]
   else:H[b]=v;break
 assert len(H)==23
 def check_bin(v):
  o=sum((x&1)<<j for j,x in enumerate(v))
  while o:
   b=o.bit_length()-1
   assert b in H, (s,b)
   o ^= H[b]
 for ext in ['', 'd']:
  name=s+ext+'.in'; raw=(base/name).read_bytes()
  values=iter(map(int,raw.split()))
  assert next(values)==n; rad=next(values)
  d=[next(values) for _ in range(n)]
  t=[next(values) for _ in range(n)]
  mu=[[next(values) for _ in range(n)] for _ in range(n)]
  o=[next(values) for _ in range(p)]
  B=[[next(values) for _ in range(p)] for _ in range(n)]
  if ext: U=[[next(values) for _ in range(p)] for _ in range(n)]
  assert all(not x for x in values) # may be empty; no nonzero trailing values
  for row in B:
   assert sum(row)==0; check_bin(row)
   assert all(sum(c*pow(j,k,p) for j,c in enumerate(row))%p==0 for k in range(27))
  assert abs(int(Matrix([row[:-1] for row in B]).det(method='domain-ge')))==p**26*2**23
  if not ext:
   qr={j*j%p for j in range(1,p)}
   pat=([1]+[4 if j in qr else 5 for j in range(1,p)]) if s=='A' else ([4]+[6]*46)
   assert sum(o)==0 and all((x-y)%2==0 for x,y in zip(o,pat))
   check_bin([(x-y)//2 for x,y in zip(o,pat)])
   assert all(sum(c*pow(j,k,p) for j,c in enumerate(o))%p==0 for k in range(27))
  P=np.asarray(B,dtype='i8'); G=P@P.T
  gs=[[F(0)]*n for _ in range(n)]; dd=[]
  for i in range(n):
   for j in range(i):
    gs[i][j]=(int(G[i,j])-sum(gs[i][k]*gs[j][k]*dd[k] for k in range(j)))/dd[j]
    assert floor(gs[i][j]*D)==mu[i][j]
   dd.append(F(int(G[i,i]))-sum(gs[i][k]**2*dd[k] for k in range(i)))
   assert dd[i]>0 and floor(dd[i]*D)==d[i]
  def gscoords(v):
   out=[]
   for i,bi in enumerate(B):
    out.append((sum(a*b for a,b in zip(v,bi))-sum(gs[i][j]*out[j]*dd[j] for j in range(i)))/dd[i])
   return out
  assert [floor(x*D) for x in gscoords([F(x,2) for x in o])]==t
  if ext:
   for j in range(p):
    cc=gscoords([F(i==j,4) for i in range(p)])
    assert [floor(x*D) for x in cc]==[u[j] for u in U]
  print(name,"PASS exact CRT index and rational Gram-Schmidt data",hashlib.sha256(raw).hexdigest(),flush=True)

