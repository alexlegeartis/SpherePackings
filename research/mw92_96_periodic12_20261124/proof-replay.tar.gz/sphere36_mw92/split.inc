#include <bits/stdc++.h>
using namespace std;
using ll=long long;
using I=__int128_t;
static volatile sig_atomic_t stopped=0;
extern "C" void stop_now(int){stopped=1;}
static int sh=0, nsh=1, sub=0, nsub=1; static string parent; static uint64_t parent_hash=0; static int cut=39;
static string checkpoint; static bool seeking=false;
static int resume_i; static ll resume_x[46];
static uint64_t visits=0, generation=0, prefix_jobs=0;
static uint64_t ticks=0;
static chrono::steady_clock::time_point stamp;
static uint64_t cap_nodes=0;
static uint64_t hinput=14695981039346656037ULL;
static void hashfile(const char *p){
  ifstream f(p,ios::binary); assert(f);
  for(char c; f.get(c); ) hinput=(hinput^(unsigned char)c)*1099511628211ULL;
}
static uint64_t fingerprint(const ll *x,int i){
  uint64_t h=14695981039346656037ULL;
  for(int j=45;j>i;j--) {uint64_t v=x[j];for(int k=0;k<8;k++){h=(h^(v&255))*1099511628211ULL;v>>=8;}}
  return h;
}
static void saved(const char *state,int i,const ll *x){
  if(checkpoint.empty())return;
  string tp=checkpoint+".new";
  ofstream f(tp);f<<"mw92-cover-v2 "<<state<<" "<<hinput<<" "<<sh<<" "<<nsh<<" "<<cut<<" "<<++generation<<" "<<prefix_jobs<<" "<<i;
  for(int j=45;j>i;j--)f<<" "<<x[j];
  f<<" "<<sub<<" "<<nsub<<" "<<parent_hash<<"\n";f.flush(); assert(f);f.close();assert(!rename(tp.c_str(),checkpoint.c_str()));
}
static void loaded(){
  ifstream f(checkpoint);
  const bool child=bool(f);
  if(!child){f.clear(); f.open(parent);}
  assert(f);
  string tag,state; uint64_t h; int a,b,c;
  f>>tag>>state>>h>>a>>b>>c>>generation>>prefix_jobs>>resume_i;
  assert(f&&tag==(child?"mw92-cover-v2":"mw92-cover-v1")&&h==hinput&&a==sh&&b==nsh&&c==cut);
  assert(state=="ACTIVE" || state=="EXHAUSTED"||state=="FOUND");
  if(state=="ACTIVE"){
    assert(resume_i>=-1&&resume_i<=cut);
    for(int j=45;j>resume_i;j--)f>>resume_x[j];assert(f);
  } else assert(resume_i==45);
  if(child){int ss,nn;uint64_t ph;f>>ss>>nn>>ph;assert(f&&ss==sub&&nn==nsub&&ph==parent_hash);}
  if(state=="EXHAUSTED"||state=="FOUND"){cerr<<"ALREADY "<<state<<endl;exit(state=="EXHAUSTED"?0:2);}
  if(!child){generation=0;prefix_jobs=0;}
  seeking=true;
}
template<class L,class F> bool outer(L &s,int i,ll rem,ll err,F &test){
  if(seeking && i==resume_i)seeking=false;
  if(i==cut){
    uint64_t h=fingerprint(s.x,i);
    if(h%nsh!=uint64_t(sh))return false;
    if((((h>>32)^h)>>2)%nsub!=uint64_t(sub)){
      if(seeking)seeking=false;
      return false;
    }
    if(!seeking)++prefix_jobs;
  }
  if(!seeking&&i<=cut){
    ++visits;
    if(!(++ticks&262143)||stopped||(cap_nodes&&visits>=cap_nodes)){
      auto now=chrono::steady_clock::now();
      if(stopped||(cap_nodes&&visits>=cap_nodes)||now-stamp>=chrono::seconds(30)){
        saved("ACTIVE",i,s.x);
        cerr<<"CHECKPOINT generation "<<generation<<" visits "<<visits<<" prefixes_entered "<<prefix_jobs<<" next_i "<<i<<endl;
        stamp=now;
        if(stopped||(cap_nodes&&visits>=cap_nodes))exit(4);
      }
    }
  }
  if(i<0){assert(!seeking);return test();}
  ++s.cnt[i];
  ll c=s.t[i];for(int j=i+1;j<46;j++)c+=s.mu[j][i]*s.x[j];
  const ll m=mid(c);
  for(ll a=0;;a++){
    bool any=false;
    for(ll sg=a?-1:1;sg<=1;sg+=2){
      ll xx=m+sg*a, u=max(0LL,ab(c+D*xx)-err);
      I e=I(s.d[i])*u*u/(I(D)*D);
      if(e>rem)continue;
      any=true;
      if(seeking&&xx!=resume_x[i])continue;
      s.x[i]=xx;
      if(outer(s,i-1,rem-(ll)e,err+ab(xx),test))return true;
    }
    if(!any){assert(!seeking);return false;}
  }
}
