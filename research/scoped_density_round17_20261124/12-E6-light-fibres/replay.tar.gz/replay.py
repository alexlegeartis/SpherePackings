from itertools import combinations,product
from math import isqrt
from collections import Counter
import json

G=[[0]*6 for _ in range(6)]
for i in range(6):G[i][i]=2
E=[(0,1),(1,2),(2,3),(3,4),(2,5)]
for i,j in E:G[i][j]=G[j][i]=-1
def Q(x):return 2*(sum(t*t for t in x)-sum(x[i]*x[j] for i,j in E))
L=list(product(range(3),repeat=6));I={p:i for i,p in enumerate(L)}
B=[isqrt(8*a//3) for a in [4,10,18,10,4,6]] # diag of G^-1 is [4,10,18,10,4,6]/3
F=[100]*729
for x in product(*(range(-a,a+1) for a in B)):
 n=Q(x)
 if n<=8:
  i=I[tuple(t%3 for t in x)];F[i]=min(F[i],n)
R=(2,1,0,2,1,0)
RR={I[tuple(k*x%3 for x in R)] for k in (1,2)}
assert {i for i,f in enumerate(F) if f>8}==RR
def depth(i,j):return F[I[tuple((a-b)%3 for a,b in zip(L[i],L[j]))]]
QQ={}
for i,p in enumerate(L):
 t=tuple(tuple((a+k*b)%3 for a,b in zip(p,R)) for k in range(3))
 q=Q(p)//2%3
 QQ[min(t)]=(q,min(F[I[x]] for x in t))
assert len(QQ)==243
assert all(d=={1:2,2:4,0:6}[q] if any(p) else d==0 for p,(q,d) in QQ.items())

data=json.load(open('data.json'))
A=data['anticode'];assert len(A)==15 and all(depth(i,j) in (2,4) for i,j in combinations(A,2))
S=set(data['seed']);assert len(S)==6 and all(depth(i,j)==2 for i,j in combinations(S,2))
def witness(v,row,S):
 assert v not in S and len(set(row))==4 and set(row)<=S
 assert all(depth(v,j)==2 for j in row)
 assert all(depth(i,j) in (2,4) for i,j in combinations(row,2))
for n,X in zip((36,240),data['rows']):
 for k,V in X.items():witness(int(k),V,S)
 S|={int(k) for k in X};assert len(S)==n
hist=Counter();hits=Counter()
for k,W in data['witnesses'].items():
 V=set()
 for w in W:
  witness(int(k),w,S)
  assert V.isdisjoint(w); V.update(w)
 hits.update(V)
 if W:hist[len(W)]+=1
assert sum(hist.values())==477
assert sum(sorted(hits.values(),reverse=True)[:20])==941
loss=0;budget=941
for k,n in sorted(hist.items()):
 hit=min(n,budget//k);loss+=hit;budget-=k*hit
assert loss==233
assert 20*36<729
assert 240+477-20-loss==464 > 9*(729//15)==432
print('PASS: at least 21 light actual vertical fibres without radical invariance.')
