#include<bits/stdc++.h>
using namespace std;constexpr int n=11,q=5,L=5,M=3125,N=48828125,N2=N/M;
using U=uint64_t;constexpr U mark=0x88888888888ull,add3=0x33333333333ull;
U sum(U a,U b){auto x=a+b,s=(x+add3)&mark;return x-((s>>1)|(s>>3));}
vector<int> decode_tbl;
struct Aut{vector<U>A,B;
 int apply(int x)const{
   U w=sum(A[x%M],B[x/M]);return decode_tbl[w&0xfffff]+M*decode_tbl[(w>>20)&0xfffff]+9765625*(w>>40);
 }
 Aut(array<U,n>const &a):A(M),B(N2){
  for(int u=1;u<M;u++){
   int s=u,d=0,p=1;while(s%q==0){s/=q;++d;p*=q;}
   A[u]=sum(A[u-p],a[d]);}
  for(int u=1;u<N2;u++){
   int s=u,d=L,p=1;while(s%q==0){s/=q;++d;p*=q;}
   B[u]=sum(B[u-p],a[d]);}
 }
};
vector<uint16_t> O(vector<Aut>const&C,vector<int>&rep,vector<int>&cnt){
 vector<uint16_t>idx(N,65535);vector<int>w;
 for(int x=0;x<N;x++)if(idx[x]==65535){
  int j=rep.size();assert(j<65535);rep.push_back(x); w.assign(1,x);idx[x]=j;
  for(size_t i=0;i<w.size();i++)for(auto&a:C){int y=a.apply(w[i]);if(idx[y]==65535){idx[y]=j;w.push_back(y);}else assert(idx[y]==j);}
  cnt.push_back(w.size());
 }
 return idx;
}

using I=long long;
using Wide=__int128_t;
I den,w[11],u[11],up[11][11]{};
I remmax; int X[11],par[11],step;
I floor_div(I p,I q){assert(q>0);return p/q-(p<0&&p%q);}
void cvp_rec(int i,I done){
  if(i<0){if(done<remmax)remmax=done;return;}
  I s=0;for(int j=i+1;j<n;j++)s+=up[i][j]*X[j];
  I stride=step*u[i],base=s+par[i]*u[i],anchor=floor_div(stride-2*base,2*stride);
  I t=base+stride*anchor;
  assert(abs(t)*2<=stride);
  int dir=t<=0?1:-1;
  for(int k=0;;k++){
    I off=((k+1)/2)*((k&1)?1:-1)*dir;
    I z=t+stride*off;
    I total=done+w[i]*z*z;
    if(total>=remmax)break;
    X[i]=par[i]+step*(anchor+off);
    cvp_rec(i-1,total);
  }
}
int norm(int x){
  for(int i=0;i<n;i++,x/=5)par[i]=x%5;
  step=5;remmax=1000*den;
  cvp_rec(n-1,0);
  assert(remmax%den==0&&remmax<1000*den);
  return remmax/den;
}
int scale(int x){
  int k=0,p=1;
  for(;x;x/=5,p*=5)k+=(2*(x%5)%5)*p;
  return k;
}
Wide poww(int a,int e){Wide x=1;while(e--)x*=a;return x;}
struct Recipe {int rank,d; vector<I> w; I f0,minp=LLONG_MAX;int admissible=0;};
int main(){
 decode_tbl.assign(1<<20,-1);
 for(int x=0;x<M;x++){int t=0;for(int z=x,j=0;j<L;j++,z/=q)t|=(z%q)<<(4*j);decode_tbl[t]=x;}
 vector<Aut>A,B;array<U,n>x{},y{};
 for(int i=0;i<n;i++)x[i]=2ull<<(4*i);
 A.emplace_back(x);B.emplace_back(x);
 ifstream g("K11.aut");
 for(int z=0;z<4;z++){
   x.fill(0);y.fill(0);
   for(int i=0;i<n;i++)for(int j=0;j<n;j++){int v;g>>v;assert(g);v=(v%5+5)%5;x[i]|=U(v)<<(4*j);y[j]|=U(v)<<(4*i);}
   A.emplace_back(x);B.emplace_back(y);
 }
 int extra;assert(!(g>>extra));
 ifstream ld("K11.ldl");ld>>den;
 for(int i=0;i<n;i++){ld>>w[i]>>u[i];assert(w[i]>0&&u[i]>0);for(int j=i+1;j<n;j++)ld>>up[i][j];}
 assert(ld && !(ld>>extra));
 // The native minimum is exactly 4: enumerate all vectors strictly below 4
 // including equality-free zero; set leaf test to reject any nonzero.
 // This q=1 scan is supplied separately in short.cpp.  Its literal e_0 gives equality.
 vector<int>ra,ca,rb,cb;
 {auto pointOrbit=O(A,ra,ca);}
 auto b=O(B,rb,cb);
 assert(ra.size()==rb.size()&&ra.size()==714);
 assert(ra[0]==0&&rb[0]==0&&ca[0]==1&&cb[0]==1);
 int k=rb.size();
 vector<Recipe> recipes;
 ifstream f("weights.txt");
 for(int r=3;r<=10;r++){
   Recipe C;f>>C.rank>>C.d;
   assert(C.rank==r);
   // d is the first even norm that can improve on K11 at this rank.
   Wide sz=poww(5,r);
   assert(sz*sz*poww(C.d-2,n)<=poww(100,n)&&sz*sz*poww(C.d,n)>poww(100,n));
   assert(C.d%2==0);
   C.w.resize(k);C.f0=0;
   for(int j=1;j<k;j++){
     f>>C.w[j];assert(f&&0<=C.w[j]&&C.w[j]<=10000000000LL);
     C.f0+=C.w[j]*cb[j];
   }
   recipes.push_back(C);
 }
 assert(!(f>>extra));
 vector<int> hist(k);
 vector<vector<int>> where(5);
 int lo[M],hi[N2];
 int largest=0;
 for(int p=1;p<k;p++){
   int r=ra[p],d=min(norm(r),norm(scale(r)));largest=max(largest,d);
   int lowest=1000;for(auto &C:recipes)if(d>=C.d)lowest=min(lowest,C.d);
   if(lowest==1000)continue;
   array<int,n>D{};for(int s=r,j=0;j<n;j++,s/=q)D[j]=s%q;
   for(int low=0;low<M;low++){
     int y=0,j=0;for(int c=low;c;c/=q)y+=(c%q)*D[j++];lo[low]=y%q;
   }
   for(int h=0;h<N2;h++){
     int y=0,j=L;for(int c=h;c;c/=q)y+=(c%q)*D[j++];hi[h]=(q-y%q)%q;
   }
   for(int y=0;y<q;y++){where[y].clear();for(int i=0;i<M;i++)if(lo[i]==y)where[y].push_back(i);}
   fill(hist.begin(),hist.end(),0);
   for(int h=0,base=0;h<N2;h++,base+=M){
     auto &w=where[hi[h]];auto*id=&b[base];for(int low:w)hist[id[low]]++;
   }
   for(int j=0;j<k;j++){int z=5*hist[j]-cb[j];assert(z%4==0);hist[j]=z/4;}
   for(auto &C:recipes)if(d>=C.d){
     I val=0;for(int j=1;j<k;j++)val+=C.w[j]*hist[j];
     assert(val<0);C.minp=min(C.minp,-val);C.admissible++;
   }
 }
 assert(largest<56&&poww(5,4)*poww(54,n)<=poww(100,n)&&poww(5,2)*poww(74,n)<=poww(100,n));
 cout<<"Largest minimum along a nonzero projective line = "<<largest<<" (rank two threshold 56, rank one threshold 76).\n";
 for(auto &C:recipes){
   assert(C.admissible&&C.minp>0);
   I cap=1+C.f0/C.minp;
   assert(cap<poww(5,C.rank));
   cout<<"rank "<<C.rank<<" d "<<C.d<<" admissible orbits "<<C.admissible
       <<" cap "<<cap<<" (F0="<<C.f0<<", P="<<C.minp<<")\n";
 }
 cout<<"PASS: no improvement by any additive subgroup of (1/5)K11/K11.\n";
}
