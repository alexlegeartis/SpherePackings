#include <bits/stdc++.h>
using namespace std;
using L=long long;
const int N=11;
int D,K,d,k,x[N],img[N],LIM;
L den,w[N],u[N],v[N][N];
unsigned long long nodes[N+1]{},shorts[N]{};
vector<array<int,N>> c[N];
int MD(int j){return ((j%5)+5)%5;}
void en(int i,L t){
 if(i<0) {
  int j=N-1;while(j>=0&&!MD(x[j]))--j;if(j<0){for(int t:x) assert(t==0);return;}
 if(D==4) abort();
  array<int,N> a{};
  const int inv[]={0,1,3,2,4};
  for(int k=0;k<=j;k++)a[k]=MD(x[k]*inv[MD(x[j])]);
  c[j].push_back(a);return;
 }
 L s=0;for(int j=i+1;j<N;j++)s+=v[i][j]*x[j];
 L z0=u[i]-2*s,z1=2*u[i];
 L v0=z0/z1-(z0<0&&z0%z1);
 for(int dir:{0,1,-1})for(int k=(dir!=0);;k++){
  L m=v0+(L)dir*k;
  L inc=w[i]*(s+u[i]*m)*(s+u[i]*m);
  if(t+inc>=den*D)break;
  x[i]=m;en(i-1,t+inc);
  if(!dir)break;
 }
}
int P[6],lognext=0;
vector<vector<int>> prod;vector<int> sum; int countsol=0;
void dfs(int i,int r){
 ++nodes[i];
 if(i==LIM){if(++countsol<=5){for(int j=0;j<i;j++)cerr<<img[j]<<" ";cerr<<"rank "<<r<<"\n";}return;}
 int M=P[r];
 vector<bool> bad(M+(r<K),false);
 int nbad=0;
 for(auto &a:c[i]){
  int sc=0;
  for(int j=0;j<i;j++) if(a[j]&&img[j])
   sc=sum[sc*d+prod[5-a[j]][img[j]]];
  if(!bad[sc])++nbad,bad[sc]=1;
  if(nbad==M)break;
 }
 for(int j=0;j<M;j++)if(!bad[j]){img[i]=j;dfs(i+1,r);}
 if(r<K){img[i]=M;dfs(i+1,r+1);}
}
int main(int ac,char**av){
 D=atoi(av[1]);K=atoi(av[2]);LIM=atoi(av[3]);
 cin>>den;for(int i=0;i<N;i++){cin>>w[i]>>u[i];for(int j=i+1;j<N;j++)cin>>v[i][j];}
 en(N-1,0);
 for(int i=0;i<N;i++){auto &a=c[i];sort(a.begin(),a.end());a.erase(unique(a.begin(),a.end()),a.end());cerr<<a.size()<<" ";}cerr<<"\n";
 P[0]=1;for(int i=1;i<=K;i++)P[i]=5*P[i-1];d=P[K];prod.assign(5,vector<int>(d));sum.resize(d*d);
 for(int i=0;i<d;i++)for(int j=0;j<d;j++){
  int a=i,b=j,s=0; for(int h=0;h<K;h++,a/=5,b/=5)s+=MD(a%5+b%5)*P[h];sum[i*d+j]=s;
 }
 for(int a=0;a<5;a++)for(int j=0;j<d;j++)for(int h=0;h<K;h++)prod[a][j]+=MD(a*(j/P[h]%5))*P[h];
 dfs(0,0);for(int j=0;j<=LIM;j++)cerr<<nodes[j]<<" ";cerr<<"\n";
 assert(countsol==0 || D==4);
 cout<<"q5 d"<<D<<" codim"<<K<<" first "<<LIM<<" coords, maps "<<countsol<<"\n";
}
