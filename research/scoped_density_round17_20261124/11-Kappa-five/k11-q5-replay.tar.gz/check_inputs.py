"""Reconstruct the exact LDL encoding and check isometries; stdlib only."""
from fractions import Fraction as F
from pathlib import Path
from math import prod

n=11
def load(s):
    return [[int(x) for x in line.split()] for line in Path(s).read_text().splitlines()]
G=load('K11')
assert len(G)==n and all(len(r)==n for r in G)
assert all(G[i][i]%2==0 for i in range(n)) and G[0][0]==4
ld=load('K11.ldl');den=ld[0][0]
assert den==24 and len(ld)==n+1
R=[[F(0) for _ in range(n)] for _ in range(n)]
diag=[]
for i,(w,u,*v) in enumerate(ld[1:]):
    assert len(v)==n-i-1 and w>0 and u>0
    R[i][i:]=[F(u)]+list(map(F,v))
    diag.append(F(w,den))
assert [[sum(diag[k]*R[k][i]*R[k][j] for k in range(n)) for j in range(n)] for i in range(n)]==G
assert prod(diag[i]*R[i][i]**2 for i in range(n))==972

M=load('K11.aut');assert len(M)==4*n
assert all(len(row)==n for row in M)
for j in range(4):
    A=M[j*n:(j+1)*n]
    B=[[sum(A[i][k]*G[k][l] for k in range(n)) for l in range(n)] for i in range(n)]
    H=[[sum(B[i][k]*A[l][k] for k in range(n)) for l in range(n)] for i in range(n)]
    assert H==G
print('Exact Gram minimum encoding, determinant 972 and four integral isometries verified.')
