"""Exact orbital and affine row data for two-color universal-good constraints."""
from itertools import product, permutations
import numpy as np
from fractions import Fraction as F
def data(N,H):
    W=np.array(list(product(range(3),repeat=5)),dtype=np.int64)
    p=3**np.arange(4,-1,-1)
    E=((0,1),(1,2),(2,3),(1,4))
    # The suppressed coordinate is original simple-root coordinate 0.
    def tp(u):
        q=((u*u).sum(-1)-sum(u[...,i]*u[...,j] for i,j in E))%3
        return np.where(q,q,np.where((u==0).all(-1),0,3))
    T=tp(W)
    DF=(W[:,None]-W[None,:])%3
    P=np.empty((243,243,4),dtype=np.int64)
    P[:,:,0]=T[:,None]; P[:,:,1]=T[None,:]; P[:,:,2]=tp(DF); P[:,:,3]=((W[:,None]+W[None,:])%3==0).all(-1)
    op,id=np.unique(P.reshape((-1,4)),return_inverse=True,axis=0); id=id.reshape(243,243)
    n=len(op);assert n==40 and tuple(np.bincount(T))==(1,72,90,80)
    B=np.array([id==i for i in range(n)],dtype=np.int64)
    sz=np.sum(B,axis=(1,2))
    s3=list(permutations(range(3)))
    pm=[]
    for i in range(n):
        A=np.argwhere(id==i)
        X=np.zeros((len(A),3,5),dtype=np.int64)
        X[:,1:,:]=W[A]
        vals=[]
        for x,y,z in s3:
            v=id[((X[:,y]-X[:,x])%3)@p,((X[:,z]-X[:,x])%3)@p]
            assert (v==v[0]).all()
            vals.append(int(v[0]))
        pm.append(vals)
    g={(1,3),(2,2),(2,3),(3,1),(3,2),(3,3)}
    b={(0,1),(1,0),(1,1)}
    raw=[]
    for i,j in product(range(n),repeat=2):
        sh=list(zip(op[i,:3],op[j,:3]))
        if any(z!=(0,0) and z not in g and z not in b for z in sh) or all(z in b for z in sh): continue
        for rgb in product(range(2),repeat=3):
            if any((v==(0,0) and rgb[u]!=rgb[w]) or (v in b and (rgb[u] or rgb[w])) for (u,w),v in zip(((0,1),(0,2),(1,2)),sh)):continue
            k=min((*sorted((u,v)),*[rgb[t] for t in perm]) for u,v,perm in zip(pm[i],pm[j],s3))
            raw.append((i,j,*rgb,k))
    keys={k:i for i,k in enumerate(sorted({r[-1] for r in raw}))}
    m=len(keys); assert m==372
    tri=np.full((2,2,2,n,n),-1,dtype=np.int32)
    ap=np.full((2,2,16),-1,dtype=np.int32)
    esm=np.zeros((2,2,2,16,m),dtype=np.int64)
    for i,j,a,b,c,key in raw:
        k=keys[key]
        tri[a,b,c,i,j]=k
        if op[i,0]==op[j,0]==0:
            f=4*op[i,1]+op[j,1]
            assert a==b and ap[a,c,f] in (-1,k)
            ap[a,c,f]=k
        esm[a,b,c,4*op[i,0]+op[j,0],k]+=sz[i]*sz[j]
    q=[]
    rhs=[]
    count=[N-H,H]; shells=np.kron(np.bincount(T),np.bincount(T))
    for a in range(2):
        row=np.zeros(m,dtype=np.int64);row[ap[a,a,0]]=1
        q.append(row);rhs.append(F(count[a],N))
    for a,b,f in sorted(zip(*np.nonzero(ap>=0))):
        for c in range(2):
            row=esm[a,b,c,f].copy()
            row[ap[a,b,f]]-=count[c]*shells[f]
            if row.any(): q.append(row);rhs.append(F(0))
    ab=np.empty((2,2,n,n),dtype=np.int32)
    for i,j in product(range(n),repeat=2):
        ab[:,:,i,j]=ap[:,:,4*op[i,2]+op[j,2]]
    return B,tri,ab,np.array(q),rhs
def Hmatrix(u,B):
    assert len(u)==243 and int(abs(u).max())<=10000
    return np.einsum('ri,krs,sj->kij',u,B,u,optimize=True).astype(object)
def cut(L,J,g,v,tri,ab,m):
    d=L.shape[1];e=J.shape[1]
    A=np.array(v,dtype=object).reshape(2,d,e)
    l=[(L@x).reshape(len(L),-1) for x in A]
    r=[np.array([(x@j).ravel()for j in J],dtype=object) for x in A]
    z=np.zeros(m,dtype=object)
    def accum(w,ind):
        S=ind.ravel();idx=np.flatnonzero(S>=0);np.add.at(z,S[idx],w[idx])
    for a,b in product(range(2),repeat=2):
        q=(l[b]@r[a].T).ravel()
        if g<2:accum(q,tri[g,a,b])
        else:
            accum(q,ab[a,b]);accum(-q,tri[0,a,b]);accum(-q,tri[1,a,b])
    return list(map(int,z))
