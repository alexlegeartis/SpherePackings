"""Sharp additive full-packet cap and a maximal 27-label affine example."""
from itertools import product
import numpy as np

def rank(A,d):
    A=[list(row) for row in A];n=len(A);r=0
    for k in range(d):
        j=next((j for j in range(r,n) if A[j][k]%3),None)
        if j is None:continue
        A[r],A[j]=A[j],A[r]
        m=A[r][k]%3;A[r]=[m*x%3 for x in A[r]]
        for i in range(r+1,n):
            a=A[i][k]%3
            if a:A[i]=[(x-a*y)%3 for x,y in zip(A[i],A[r])]
        r+=1
    return r

# A rank-four subspace injectively projected to each 5D factor yields
# quadratic forms of rank at least 3. Up to binary discriminant there
# are four possible types for the first form. For three possibilities,
# no nonzero homogeneous quadratic vanishes on its type-1 vectors.
X=list(product(range(3),repeat=4))
ij=[(i,j) for i in range(4) for j in range(i,4)]
monos=[tuple(x[i]*x[j]%3 for i,j in ij) for x in X]
for coeff in [(1,1,2,0),(1,1,1,1),(1,1,1,2)]:
    R=[m for x,m in zip(X,monos) if sum(c*t*t for c,t in zip(coeff,x))%3==1]
    assert rank(R,10)==10
# For the fourth case, the space of such quadratics consists precisely
# of the three cross terms x0*x1,x0*x2,x1*x2; check all 27 forms there.
coeff=(1,1,1,0)
R=[m for x,m in zip(X,monos) if sum(c*t*t for c,t in zip(coeff,x))%3==1]
assert rank(R,10)==7
assert all(not any(m[ij.index(s)] for m in R)for s in [(0,1),(0,2),(1,2)])
def permitted(a,b):
    return not ((a==1 and b) or (b==1 and a))
for a,b,c in product(range(3),repeat=3):
    ok=all(permitted((x*x+y*y+z*z)%3,(a*x*y+b*x*z+c*y*z)%3)for x,y,z,w in X)
    assert ok==(a==b==c==0)

# Literal attaining example. Use E6 coordinates with first simple root zero.
V=np.array(list(product(range(3), repeat=5)),dtype=np.int64)
G=2*np.eye(5,dtype=np.int64)
for i,j in [(0,1),(1,2),(2,3),(1,4)]:G[i,j]=G[j,i]=-1
assert rank(G.tolist(),5)==5
Q=lambda A:(A*A).sum(axis=-1)-sum(A[...,i]*A[...,j]for i,j in [(0,1),(1,2),(2,3),(1,4)])
sq=Q(V)%3
u=np.array([0,0,1,2,0])
v=np.array([1,0,0,1,1])
assert ((u@G@v)%3)==0 and Q(u)%3==Q(v)%3==0
W=V[((V@G@u)%3==0)&((V@G@v)%3==0)]
assert len(W)==27 and set(Q(W)%3)=={0,2}
I=(3**np.arange(4,-1,-1))
P=(V[:,None]-W[None,:])%3
q=Q(P)%3
j=(P@I)==0
ty=np.where(q,q,np.where(j,0,3))
# A diagonal code (w,w) has 27 compatible labels; no other single point
# can be added, since its pair of projected differences must be good at
# each of the 27 anchors.
S=np.ones((243,243),dtype=bool)
for k in range(27):
    a,b=ty[:,k,None],ty[None,:,k]
    S &= (a>0)&(b>0)&(a+b>=4)
assert not S.any()
print('PASS: additive full-packet code has at most 27 labels; explicit diagonal 27-label code is maximal even nonlinearly.')
