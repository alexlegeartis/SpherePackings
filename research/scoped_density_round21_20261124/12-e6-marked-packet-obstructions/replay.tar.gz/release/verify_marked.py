"""Independent exact replay of marked three-point contradictions."""
from mark_data import *
import sys,json
from pathlib import Path
p=json.load(open(sys.argv[1]))
N,H=int(p['N']),int(p['H'])
assert 0<H<N<=243
B,T,A,E,R=data(N,H)
l=list(map(F,p['l']))
assert len(l)==len(E)
rhs=sum(t*q for t,q in zip(l,R))
assert rhs>0
z=[sum(t*int(q) for t,q in zip(l,row))for row in E.T]
U=p.get('U') or json.loads(Path(__file__).with_name('marked-basis.json').read_text())
used={i for row in p['rows'] for i in row[:2]}
M={int(i):Hmatrix(np.array(u,dtype=np.int64),B) for i,u in U.items() if int(i) in used}
for i,j,k,v,w in p['rows']:
    w=F(w)
    assert w>0 and k in (0,1,2)
    z=[a+w*b for a,b in zip(z,cut(M[i],M[j],k,v,T,A,len(z)))]
assert max(z)<0
print('PASS: target',N,'universal-good count',H,'with',len(p['rows']),'positive Rayleigh cuts,',len(z),'exact strictly negative coefficients')
