"""A census of all additive rank-three good codes and their common neighborhoods."""
from itertools import product
from collections import defaultdict,Counter
import numpy as np
F=np.array(list(product(range(3),repeat=5)),dtype=np.int64)
D=np.array(list(product(range(3),repeat=3)),dtype=np.int64)
G=2*np.eye(5,dtype=np.int64)
for i,j in [(0,1),(1,2),(2,3),(1,4)]:G[i,j]=G[j,i]=-1
Q=lambda A: (np.sum((A@G)*A,axis=-1)//2)%3
DP=F@G@F.T%3; q=Q(F)
mexp=list((i,j)for i in range(3)for j in range(i,3))
M=np.array([D[:,i]*D[:,j] for i,j in mexp]).T
coeffs=np.array(list(product(range(3),repeat=6)),dtype=np.int64)
qm=(coeffs@M.T)%3
def embed(c):
    # Coefficients off-diagonal are entries of the polar form.
    pol=np.zeros((3,3),dtype=int)
    diag=np.zeros(3,dtype=int)
    for i,(u,v) in enumerate(mexp):
        if u==v:diag[u]=c[i]
        else:pol[u,v]=pol[v,u]=c[i]
    for a in np.flatnonzero(q==diag[0]):
        if not a:continue
        for b in np.flatnonzero((q==diag[1])&(DP[a]==pol[0,1])):
            if np.array_equal(F[b],F[a]) or np.array_equal(F[b],(-F[a])%3) or not b:continue
            prohibited=(np.array(list(product(range(3),repeat=2)))@F[[a,b]]%3)@(3**np.arange(4,-1,-1))
            cc=np.flatnonzero((q==diag[2])&(DP[a]==pol[0,2])&(DP[b]==pol[1,2]))
            for x in cc:
                if x not in prohibited: return np.array([F[a],F[b],F[x]])
    return None
def nb(S):
    Y=(F[:,None]-S[None,:])%3
    x=Q(Y)
    return np.where(x!=0,x,np.where((Y==0).all(-1),0,3)).T
def code(e):
    return (D@e)%3
tcounter=Counter()
nmax=0; found=[]
for aa in [(1,0,0),(2,0,0),(1,1,0),(1,2,0),(1,1,1),(1,1,2)]:
    a=np.array([aa[u] if u==v else 0 for u,v in mexp])
    ea=embed(a)
    if ea is None:continue
    qa=(M@a)%3
    left=nb(code(ea))
    cand=np.where(((qm[:,qa==1]==0).all(1))&((qm[:,qa==2]!=1).all(1)))[0]
    for z in cand:
        b=coeffs[z]; eb=embed(b)
        if eb is None:continue
        right=nb(code(eb))
        S=np.ones((243,243),dtype=bool)
        for x,y in zip(left,right):
            S&=(x[:,None]>0)&(y[None,:]>0)&(x[:,None]+y[None,:]>=4)
        k=int(S.sum()); nmax=max(nmax,k)
        tcounter[aa,k]+=1
        found.append((aa,b.tolist(),k))
print(tcounter,'max',nmax,'validpairs',len(found))
print(sorted(found,key=lambda a:-a[-1])[:3])
assert embed(np.zeros(6,dtype=np.int64)) is None  # no 3D totally isotropic space
assert tcounter=={((2,0,0),0):25,((1,2,0),0):5}
assert nmax==0
print('PASS: all affine 27-label subspace codes in the good mask are already maximal.')
