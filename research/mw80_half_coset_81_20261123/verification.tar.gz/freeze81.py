import numpy as np,json,sys
from pathlib import Path
from flint import fmpz_mat as Z
from fractions import Fraction as F
from decimal import Decimal as D,localcontext
from math import factorial
A=np.load('geometry.npz');P=np.load('split_V2^21.npz');W=np.load('label_maps.npz')
G=A['G'];L=A['roots'];Q=Z(G.tolist());assert int(Q.det())==41**12
assert np.min(np.sum((L@G)*L,axis=1))==14
label=int(sys.argv[1])
assert any(z.startswith(f'RESULT {label} ') and z.endswith('EXACT_NO_VECTOR')for z in Path(sys.argv[2] if len(sys.argv)>2 else 'wide81.log').read_text().splitlines())
k,u,v=next(tuple(map(int,l.split()))for l in Path('newlabels.txt').read_text().splitlines()if int(l.split()[0])==label)
r=np.array([((u+2**64*v)>>j)&1 for j in range(80)],dtype='i8')
assert np.any(r) and int(r@G@r)%4==0
s=np.loadtxt('small_rep.txt',dtype=np.int64)
assert s.shape==(80,) and np.array_equal(r%2,s%2) and int(s@G@s)==40
r=s;N=int(r@G@r)
C=np.block([[4*G,(2*(G@r))[:,None]],[(2*(r@G))[None,:],np.array([[16+N]],dtype='i8')]])
assert int(Z(C.tolist()).det())==4**82*41**12
res={'dimension':81,'minimum_squared':'14','gram_determinant':str(4*41**12),'gram_scaled_by_4':C.tolist(),'shift_num':r.tolist(),'shift_den':2,'vertical_height_squared':'4','horizontal_depth_squared':'10','candidate':label}
Path('candidate81.json').write_text(json.dumps(res,separators=(',',':'))+'\n')
with localcontext() as c:
 c.prec=40
 de=D(7)**(D(81)/2)/(D(2)**(D(83)/2)*D(41)**6)
 ratio=de/D(2)**40
 pi=D('3.1415926535897932384626433832795028841971693993751058')
 vol=pi**40*D(4)**41*D(factorial(41))/D(factorial(82))
 print('center density',de,'gain pct',(ratio-1)*100,'packing fraction',de*vol)
