#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
python3 verify_parent.py
python3 ksetup.py
python3 setup_swap.py
g++ -O3 -std=c++17 wide81.cpp -o wide81
./wide81 0 85000000 5 1 | tee replay.log
python3 freeze81.py 5 replay.log
