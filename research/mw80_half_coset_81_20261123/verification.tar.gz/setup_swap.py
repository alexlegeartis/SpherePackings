import numpy as np
from flint import fmpq_mat as Q
A=np.load('split_V2^21.npz');P=np.load('geometry.npz');X=np.load('label_maps.npz');U=np.load('shared_involution_swap.npz')['U']
G=P['G'];U0=X['U0']@A['B'];U1=X['U1']@A['C'];G1=U1@G@U1.T;G0=U0@G@U0.T
I=np.eye(80,dtype=np.int64);T=A['T']
assert np.array_equal(U@T,-T@U) and np.array_equal(U@U,I) and np.array_equal(U@G@U.T,G)
Y=Q((U0@U@G@U1.T).tolist())*Q(G1.tolist()).inv()
assert all(z.denominator==1 for z in Y.entries())
D=np.array(Y.tolist(),dtype=np.int64)
assert np.array_equal(D@U1,U0@U) and np.array_equal(D@G1@D.T,G0)
assert abs(Y.det())==1
np.savetxt('swap41.txt',D,fmt='%d')
auto=[np.load('carrierA.npz')['A'],P['J'],U]
for M in auto:assert np.array_equal(M@G@M.T,G)
for M in auto[:2]:assert np.array_equal(M@T,T@M)
for k,M in enumerate(auto):
 with open(f'aut{k}.txt','w')as f:
  for r in M:
   x=sum((int(z)&1)<<j for j,z in enumerate(r))
   print(x%2**64,x//2**64,file=f)
