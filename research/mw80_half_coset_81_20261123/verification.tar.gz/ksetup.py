from pathlib import Path
import numpy as np
from flint import fmpz_mat as Z,fmpq_mat as Q,fmpq as F,nmod_mat as N
from math import isqrt
A=np.load('split_V2^21.npz');D=np.load('geometry.npz');gp=D['G'];T=A['T'];I80=np.eye(80,dtype='i8')
n=40;I=np.eye(n,dtype='i8');Uall={}
def write(G,B,f):
 Gq=Q(G.tolist());K=Gq.inv();d=[None]*n;U=[[F(int(i==j))for j in range(n)]for i in range(n)];S=1<<20
 for i in range(n):
  d[i]=Gq[i,i]-sum(U[i][p]*U[i][p]*d[p]for p in range(i));assert d[i]>0
  for j in range(i+1,n):
   U[j][i]=(Gq[j,i]-sum(U[j][p]*U[i][p]*d[p]for p in range(i)))/d[i]
 assert Q(U)*Q([[d[i]if j==i else F(0)for j in range(n)]for i in range(n)])*Q(U).transpose()==Gq
 with open(f,'w') as z:
  for x in (G.ravel(),B.ravel(),[int((S*x).floor())for x in d],[int((S*x).floor())for row in U for x in row],[isqrt(int((40*K[i,i]).floor()))for i in range(n)]):print(*x,file=z)
 assert np.max(abs(G))<10000
assert np.array_equal(T@T,I80)and np.array_equal(T@gp@T.T,gp)
assert not np.any(A['B']@gp@A['C'].T)
assert N(np.r_[A['B'],A['C']].tolist(),2).rank()==42
for h,(k,b) in enumerate([('S','B'),('H','C')]):
 G=A[k];B=A[b];assert np.array_equal(B@gp@B.T,G)
 F0=I80+(-1)**h*T;X=Q((F0@gp@B.T).tolist())*Q(G.tolist()).inv()
 assert all(z.denominator==1 for z in X.entries()) and X*Q(B.tolist())==Q(F0.tolist())
 assert np.array_equal(B@T,(-1)**h*B)
 assert N(B.tolist(),2).rank()==40
 R,j=N(G.tolist(),2).nullspace();assert j==38
 Z0=Z(np.r_[I*2,np.array(R.tolist(),dtype='i8')[:,:j].T].tolist())
 H=Z(Z0.hnf().tolist()[:40]);assert abs(H.det())==4
 assert N((H*Z(G.tolist())).tolist(),2).rank()==0
 S0=H*Z(G.tolist())*H.transpose()
 # exact LLL basis: physical Gram and embedding are carried by the same unimodular transform
 G1,R0=S0.lll(transform=True,delta=.9999,rep='gram',gram='approx')
 assert abs(R0.det())==1 and R0*S0*R0.transpose()==G1
 K0=R0*H
 G1=np.array(G1.tolist(),dtype='i8');K0=np.array(K0.tolist(),dtype='i8');B1=K0@B
 assert np.array_equal(B1@gp@B1.T,G1)
 assert np.all(G1%2==0) and np.all(G1.diagonal()%4==0)
 assert N(B1.tolist(),2).rank()==38
 write(G1,B1,f'jointK{h}.in')
 write(G,B,f'fixed{h}.in')
 Uall['U'+str(h)]=K0
 print(h,'shared parity index4 det verified min diagonal',min(G1.diagonal()),flush=True)
np.savez('label_maps.npz',**Uall)
